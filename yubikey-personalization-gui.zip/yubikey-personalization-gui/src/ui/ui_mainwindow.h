/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QWidget *deviceWidget;
    QFrame *line;
    QLabel *deviceImage;
    QLabel *versionLbl;
    QLabel *versionDescLbl;
    QLabel *statusLbl;
    QGroupBox *featureSupportBox;
    QLabel *multiConfigSupportDescLbl;
    QLabel *oathHotpSupportDescLbl;
    QLabel *chalRespSupportDescLbl;
    QLabel *multiConfigSupportLbl;
    QLabel *oathHotpSupportLbl;
    QLabel *chalRespSupportLbl;
    QLabel *staticPwdSupportLbl;
    QLabel *staticPwdSupportDescLbl;
    QLabel *otpSupportDescLbl;
    QLabel *otpSupportLbl;
    QLabel *scanCodeSupportLbl;
    QLabel *scanCodeSupportDescLbl;
    QLabel *updatableSupportDescLbl;
    QLabel *updatableSupportLbl;
    QLabel *ndefSupportDescLbl;
    QLabel *ndefSupportLbl;
    QLabel *u2fSupportDescLbl;
    QLabel *u2fSupportLbl;
    QLabel *logoImg;
    QGroupBox *serialNoBox;
    QPushButton *serialNoHexCopyBtn;
    QLabel *serialNoHexLbl;
    QLabel *serialNoDecLbl;
    QPushButton *serialNoDecCopyBtn;
    QLabel *serialNoModhexLbl;
    QPushButton *serialNoModhexCopyBtn;
    QLabel *decLbl;
    QLabel *hexLbl;
    QLabel *modhexLbl;
    QLabel *programDescLbl;
    QLabel *programLbl;
    QStackedWidget *pagesWidget;
    QFrame *menuSeparator;
    QWidget *menuWidget;
    QPushButton *otpMenuBtn;
    QPushButton *settingsMenuBtn;
    QPushButton *oathHotpMenuBtn;
    QPushButton *staticMenuBtn;
    QPushButton *chalRespMenuBtn;
    QPushButton *aboutMenuBtn;
    QPushButton *toolsMenuBtn;
    QPushButton *exitMenuBtn;
    QWidget *statusWidget;
    QLabel *statusIconLbl;
    QLabel *statusMsgLbl;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setWindowModality(Qt::ApplicationModal);
        MainWindow->setEnabled(true);
        MainWindow->resize(900, 700);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMaximumSize(QSize(900, 710));
        MainWindow->setSizeIncrement(QSize(0, 0));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/res/win/Yubico.ico"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setMaximumSize(QSize(900, 710));
        centralWidget->setBaseSize(QSize(300, 200));
        deviceWidget = new QWidget(centralWidget);
        deviceWidget->setObjectName(QString::fromUtf8("deviceWidget"));
        deviceWidget->setGeometry(QRect(730, 33, 170, 677));
        sizePolicy.setHeightForWidth(deviceWidget->sizePolicy().hasHeightForWidth());
        deviceWidget->setSizePolicy(sizePolicy);
        deviceWidget->setMaximumSize(QSize(170, 677));
        deviceWidget->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"background-color: rgb(255, 255, 255);"));
        line = new QFrame(deviceWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(0, 0, 3, 677));
        sizePolicy.setHeightForWidth(line->sizePolicy().hasHeightForWidth());
        line->setSizePolicy(sizePolicy);
        line->setMaximumSize(QSize(3, 677));
        line->setStyleSheet(QString::fromUtf8(""));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        deviceImage = new QLabel(deviceWidget);
        deviceImage->setObjectName(QString::fromUtf8("deviceImage"));
        deviceImage->setGeometry(QRect(20, 40, 128, 128));
        deviceImage->setContextMenuPolicy(Qt::ActionsContextMenu);
        deviceImage->setAlignment(Qt::AlignCenter);
        versionLbl = new QLabel(deviceWidget);
        versionLbl->setObjectName(QString::fromUtf8("versionLbl"));
        versionLbl->setGeometry(QRect(10, 260, 151, 16));
        versionDescLbl = new QLabel(deviceWidget);
        versionDescLbl->setObjectName(QString::fromUtf8("versionDescLbl"));
        versionDescLbl->setGeometry(QRect(10, 240, 151, 16));
        versionDescLbl->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        statusLbl = new QLabel(deviceWidget);
        statusLbl->setObjectName(QString::fromUtf8("statusLbl"));
        statusLbl->setGeometry(QRect(10, 5, 151, 30));
        statusLbl->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
"color: rgb(221, 97, 99);\n"
""));
        statusLbl->setAlignment(Qt::AlignCenter);
        featureSupportBox = new QGroupBox(deviceWidget);
        featureSupportBox->setObjectName(QString::fromUtf8("featureSupportBox"));
        featureSupportBox->setGeometry(QRect(8, 380, 155, 200));
        featureSupportBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
"background-color: rgb(255, 255, 255);"));
        featureSupportBox->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        featureSupportBox->setFlat(false);
        featureSupportBox->setCheckable(false);
        multiConfigSupportDescLbl = new QLabel(featureSupportBox);
        multiConfigSupportDescLbl->setObjectName(QString::fromUtf8("multiConfigSupportDescLbl"));
        multiConfigSupportDescLbl->setGeometry(QRect(5, 45, 121, 16));
        multiConfigSupportDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        multiConfigSupportDescLbl->setLineWidth(2);
        oathHotpSupportDescLbl = new QLabel(featureSupportBox);
        oathHotpSupportDescLbl->setObjectName(QString::fromUtf8("oathHotpSupportDescLbl"));
        oathHotpSupportDescLbl->setGeometry(QRect(5, 65, 121, 16));
        oathHotpSupportDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        oathHotpSupportDescLbl->setLineWidth(2);
        chalRespSupportDescLbl = new QLabel(featureSupportBox);
        chalRespSupportDescLbl->setObjectName(QString::fromUtf8("chalRespSupportDescLbl"));
        chalRespSupportDescLbl->setGeometry(QRect(5, 125, 121, 16));
        chalRespSupportDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        chalRespSupportDescLbl->setLineWidth(2);
        multiConfigSupportLbl = new QLabel(featureSupportBox);
        multiConfigSupportLbl->setObjectName(QString::fromUtf8("multiConfigSupportLbl"));
        multiConfigSupportLbl->setGeometry(QRect(128, 45, 21, 16));
        multiConfigSupportLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        multiConfigSupportLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        oathHotpSupportLbl = new QLabel(featureSupportBox);
        oathHotpSupportLbl->setObjectName(QString::fromUtf8("oathHotpSupportLbl"));
        oathHotpSupportLbl->setGeometry(QRect(128, 65, 21, 16));
        oathHotpSupportLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        oathHotpSupportLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        chalRespSupportLbl = new QLabel(featureSupportBox);
        chalRespSupportLbl->setObjectName(QString::fromUtf8("chalRespSupportLbl"));
        chalRespSupportLbl->setGeometry(QRect(128, 125, 21, 16));
        chalRespSupportLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        chalRespSupportLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        staticPwdSupportLbl = new QLabel(featureSupportBox);
        staticPwdSupportLbl->setObjectName(QString::fromUtf8("staticPwdSupportLbl"));
        staticPwdSupportLbl->setGeometry(QRect(128, 85, 21, 16));
        staticPwdSupportLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        staticPwdSupportLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        staticPwdSupportDescLbl = new QLabel(featureSupportBox);
        staticPwdSupportDescLbl->setObjectName(QString::fromUtf8("staticPwdSupportDescLbl"));
        staticPwdSupportDescLbl->setGeometry(QRect(5, 85, 121, 16));
        staticPwdSupportDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
""));
        staticPwdSupportDescLbl->setLineWidth(2);
        otpSupportDescLbl = new QLabel(featureSupportBox);
        otpSupportDescLbl->setObjectName(QString::fromUtf8("otpSupportDescLbl"));
        otpSupportDescLbl->setGeometry(QRect(5, 25, 121, 16));
        otpSupportDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        otpSupportDescLbl->setLineWidth(2);
        otpSupportLbl = new QLabel(featureSupportBox);
        otpSupportLbl->setObjectName(QString::fromUtf8("otpSupportLbl"));
        otpSupportLbl->setGeometry(QRect(128, 25, 21, 16));
        otpSupportLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        otpSupportLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        scanCodeSupportLbl = new QLabel(featureSupportBox);
        scanCodeSupportLbl->setObjectName(QString::fromUtf8("scanCodeSupportLbl"));
        scanCodeSupportLbl->setGeometry(QRect(128, 105, 21, 16));
        scanCodeSupportLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        scanCodeSupportLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        scanCodeSupportDescLbl = new QLabel(featureSupportBox);
        scanCodeSupportDescLbl->setObjectName(QString::fromUtf8("scanCodeSupportDescLbl"));
        scanCodeSupportDescLbl->setGeometry(QRect(5, 105, 121, 16));
        scanCodeSupportDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
""));
        scanCodeSupportDescLbl->setLineWidth(2);
        updatableSupportDescLbl = new QLabel(featureSupportBox);
        updatableSupportDescLbl->setObjectName(QString::fromUtf8("updatableSupportDescLbl"));
        updatableSupportDescLbl->setGeometry(QRect(5, 145, 121, 16));
        updatableSupportDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        updatableSupportDescLbl->setLineWidth(2);
        updatableSupportLbl = new QLabel(featureSupportBox);
        updatableSupportLbl->setObjectName(QString::fromUtf8("updatableSupportLbl"));
        updatableSupportLbl->setGeometry(QRect(128, 145, 21, 16));
        updatableSupportLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        updatableSupportLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ndefSupportDescLbl = new QLabel(featureSupportBox);
        ndefSupportDescLbl->setObjectName(QString::fromUtf8("ndefSupportDescLbl"));
        ndefSupportDescLbl->setGeometry(QRect(5, 165, 121, 16));
        ndefSupportDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        ndefSupportDescLbl->setLineWidth(2);
        ndefSupportLbl = new QLabel(featureSupportBox);
        ndefSupportLbl->setObjectName(QString::fromUtf8("ndefSupportLbl"));
        ndefSupportLbl->setGeometry(QRect(128, 165, 21, 16));
        ndefSupportLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        ndefSupportLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        u2fSupportDescLbl = new QLabel(featureSupportBox);
        u2fSupportDescLbl->setObjectName(QString::fromUtf8("u2fSupportDescLbl"));
        u2fSupportDescLbl->setGeometry(QRect(5, 185, 121, 16));
        u2fSupportDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        u2fSupportDescLbl->setLineWidth(2);
        u2fSupportLbl = new QLabel(featureSupportBox);
        u2fSupportLbl->setObjectName(QString::fromUtf8("u2fSupportLbl"));
        u2fSupportLbl->setGeometry(QRect(128, 185, 21, 16));
        u2fSupportLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        u2fSupportLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        logoImg = new QLabel(deviceWidget);
        logoImg->setObjectName(QString::fromUtf8("logoImg"));
        logoImg->setGeometry(QRect(5, 600, 160, 60));
        logoImg->setContextMenuPolicy(Qt::ActionsContextMenu);
        logoImg->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        logoImg->setPixmap(QPixmap(QString::fromUtf8(":/res/images/logo.png")));
        logoImg->setScaledContents(false);
        logoImg->setAlignment(Qt::AlignCenter);
        logoImg->setIndent(0);
        serialNoBox = new QGroupBox(deviceWidget);
        serialNoBox->setObjectName(QString::fromUtf8("serialNoBox"));
        serialNoBox->setGeometry(QRect(8, 275, 155, 105));
        serialNoBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
"background-color: rgb(255, 255, 255);"));
        serialNoBox->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        serialNoBox->setFlat(false);
        serialNoBox->setCheckable(false);
        serialNoHexCopyBtn = new QPushButton(serialNoBox);
        serialNoHexCopyBtn->setObjectName(QString::fromUtf8("serialNoHexCopyBtn"));
        serialNoHexCopyBtn->setGeometry(QRect(128, 50, 20, 20));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(serialNoHexCopyBtn->sizePolicy().hasHeightForWidth());
        serialNoHexCopyBtn->setSizePolicy(sizePolicy1);
        serialNoHexCopyBtn->setCursor(QCursor(Qt::PointingHandCursor));
        serialNoHexCopyBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        serialNoHexCopyBtn->setLayoutDirection(Qt::LeftToRight);
        serialNoHexCopyBtn->setAutoFillBackground(false);
        serialNoHexCopyBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/blank.png);\n"
"border-radius: 2px;"));
        serialNoHexCopyBtn->setAutoDefault(false);
        serialNoHexLbl = new QLabel(serialNoBox);
        serialNoHexLbl->setObjectName(QString::fromUtf8("serialNoHexLbl"));
        serialNoHexLbl->setGeometry(QRect(55, 50, 70, 20));
        serialNoHexLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        serialNoHexLbl->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        serialNoDecLbl = new QLabel(serialNoBox);
        serialNoDecLbl->setObjectName(QString::fromUtf8("serialNoDecLbl"));
        serialNoDecLbl->setGeometry(QRect(55, 25, 70, 20));
        serialNoDecLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        serialNoDecLbl->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        serialNoDecCopyBtn = new QPushButton(serialNoBox);
        serialNoDecCopyBtn->setObjectName(QString::fromUtf8("serialNoDecCopyBtn"));
        serialNoDecCopyBtn->setGeometry(QRect(128, 25, 20, 20));
        sizePolicy1.setHeightForWidth(serialNoDecCopyBtn->sizePolicy().hasHeightForWidth());
        serialNoDecCopyBtn->setSizePolicy(sizePolicy1);
        serialNoDecCopyBtn->setCursor(QCursor(Qt::PointingHandCursor));
        serialNoDecCopyBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        serialNoDecCopyBtn->setAcceptDrops(false);
        serialNoDecCopyBtn->setLayoutDirection(Qt::LeftToRight);
        serialNoDecCopyBtn->setAutoFillBackground(false);
        serialNoDecCopyBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/blank.png);\n"
"border-radius: 2px;"));
        serialNoDecCopyBtn->setAutoDefault(false);
        serialNoDecCopyBtn->setFlat(false);
        serialNoModhexLbl = new QLabel(serialNoBox);
        serialNoModhexLbl->setObjectName(QString::fromUtf8("serialNoModhexLbl"));
        serialNoModhexLbl->setGeometry(QRect(55, 75, 70, 20));
        serialNoModhexLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        serialNoModhexLbl->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        serialNoModhexCopyBtn = new QPushButton(serialNoBox);
        serialNoModhexCopyBtn->setObjectName(QString::fromUtf8("serialNoModhexCopyBtn"));
        serialNoModhexCopyBtn->setGeometry(QRect(128, 75, 20, 20));
        sizePolicy1.setHeightForWidth(serialNoModhexCopyBtn->sizePolicy().hasHeightForWidth());
        serialNoModhexCopyBtn->setSizePolicy(sizePolicy1);
        serialNoModhexCopyBtn->setCursor(QCursor(Qt::PointingHandCursor));
        serialNoModhexCopyBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        serialNoModhexCopyBtn->setLayoutDirection(Qt::LeftToRight);
        serialNoModhexCopyBtn->setAutoFillBackground(false);
        serialNoModhexCopyBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/blank.png);\n"
"border-radius: 2px;"));
        serialNoModhexCopyBtn->setAutoDefault(false);
        decLbl = new QLabel(serialNoBox);
        decLbl->setObjectName(QString::fromUtf8("decLbl"));
        decLbl->setGeometry(QRect(5, 25, 50, 20));
        decLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        hexLbl = new QLabel(serialNoBox);
        hexLbl->setObjectName(QString::fromUtf8("hexLbl"));
        hexLbl->setGeometry(QRect(5, 50, 50, 20));
        hexLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        modhexLbl = new QLabel(serialNoBox);
        modhexLbl->setObjectName(QString::fromUtf8("modhexLbl"));
        modhexLbl->setGeometry(QRect(5, 75, 50, 20));
        modhexLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        programDescLbl = new QLabel(deviceWidget);
        programDescLbl->setObjectName(QString::fromUtf8("programDescLbl"));
        programDescLbl->setGeometry(QRect(10, 200, 151, 16));
        programDescLbl->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        programLbl = new QLabel(deviceWidget);
        programLbl->setObjectName(QString::fromUtf8("programLbl"));
        programLbl->setGeometry(QRect(10, 220, 151, 16));
        pagesWidget = new QStackedWidget(centralWidget);
        pagesWidget->setObjectName(QString::fromUtf8("pagesWidget"));
        pagesWidget->setGeometry(QRect(0, 60, 725, 650));
        sizePolicy.setHeightForWidth(pagesWidget->sizePolicy().hasHeightForWidth());
        pagesWidget->setSizePolicy(sizePolicy);
        pagesWidget->setMaximumSize(QSize(730, 650));
        menuSeparator = new QFrame(centralWidget);
        menuSeparator->setObjectName(QString::fromUtf8("menuSeparator"));
        menuSeparator->setGeometry(QRect(0, 30, 900, 3));
        sizePolicy.setHeightForWidth(menuSeparator->sizePolicy().hasHeightForWidth());
        menuSeparator->setSizePolicy(sizePolicy);
        menuSeparator->setMaximumSize(QSize(900, 3));
        menuSeparator->setAutoFillBackground(false);
        menuSeparator->setStyleSheet(QString::fromUtf8("background-color: rgb(140, 192, 65);"));
        menuSeparator->setFrameShadow(QFrame::Sunken);
        menuSeparator->setLineWidth(1);
        menuSeparator->setFrameShape(QFrame::HLine);
        menuWidget = new QWidget(centralWidget);
        menuWidget->setObjectName(QString::fromUtf8("menuWidget"));
        menuWidget->setGeometry(QRect(0, 0, 900, 30));
        menuWidget->setMaximumSize(QSize(900, 30));
        menuWidget->setStyleSheet(QString::fromUtf8("font: 13px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);\n"
"background-color: rgb(255, 255, 255);\n"
"border-color: rgb(140, 192, 65);\n"
"selection-color: rgb(0, 0, 0);"));
        otpMenuBtn = new QPushButton(menuWidget);
        otpMenuBtn->setObjectName(QString::fromUtf8("otpMenuBtn"));
        otpMenuBtn->setGeometry(QRect(10, 4, 95, 23));
        otpMenuBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 2px groove rgb(255, 255, 255);\n"
"border-radius: 5px;"));
        otpMenuBtn->setCheckable(true);
        otpMenuBtn->setChecked(false);
        otpMenuBtn->setFlat(false);
        settingsMenuBtn = new QPushButton(menuWidget);
        settingsMenuBtn->setObjectName(QString::fromUtf8("settingsMenuBtn"));
        settingsMenuBtn->setGeometry(QRect(535, 4, 75, 23));
        settingsMenuBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 2px groove rgb(255, 255, 255);\n"
"border-radius: 5px;"));
        settingsMenuBtn->setCheckable(false);
        settingsMenuBtn->setChecked(false);
        settingsMenuBtn->setFlat(false);
        oathHotpMenuBtn = new QPushButton(menuWidget);
        oathHotpMenuBtn->setObjectName(QString::fromUtf8("oathHotpMenuBtn"));
        oathHotpMenuBtn->setGeometry(QRect(115, 4, 100, 23));
        oathHotpMenuBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 2px groove rgb(255, 255, 255);\n"
"border-radius: 5px;"));
        oathHotpMenuBtn->setCheckable(true);
        oathHotpMenuBtn->setChecked(false);
        oathHotpMenuBtn->setFlat(false);
        staticMenuBtn = new QPushButton(menuWidget);
        staticMenuBtn->setObjectName(QString::fromUtf8("staticMenuBtn"));
        staticMenuBtn->setGeometry(QRect(225, 4, 130, 23));
        staticMenuBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 2px groove rgb(255, 255, 255);\n"
"border-radius: 5px;"));
        staticMenuBtn->setCheckable(true);
        staticMenuBtn->setChecked(false);
        staticMenuBtn->setFlat(false);
        chalRespMenuBtn = new QPushButton(menuWidget);
        chalRespMenuBtn->setObjectName(QString::fromUtf8("chalRespMenuBtn"));
        chalRespMenuBtn->setGeometry(QRect(365, 4, 160, 23));
        chalRespMenuBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 2px groove rgb(255, 255, 255);\n"
"border-radius: 5px;"));
        chalRespMenuBtn->setCheckable(true);
        chalRespMenuBtn->setChecked(false);
        chalRespMenuBtn->setFlat(false);
        aboutMenuBtn = new QPushButton(menuWidget);
        aboutMenuBtn->setObjectName(QString::fromUtf8("aboutMenuBtn"));
        aboutMenuBtn->setGeometry(QRect(680, 4, 60, 23));
        aboutMenuBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 2px groove rgb(255, 255, 255);\n"
"border-radius: 5px;"));
        aboutMenuBtn->setCheckable(false);
        aboutMenuBtn->setChecked(false);
        aboutMenuBtn->setFlat(false);
        toolsMenuBtn = new QPushButton(menuWidget);
        toolsMenuBtn->setObjectName(QString::fromUtf8("toolsMenuBtn"));
        toolsMenuBtn->setGeometry(QRect(620, 4, 50, 23));
        toolsMenuBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 2px groove rgb(255, 255, 255);\n"
"border-radius: 5px;"));
        toolsMenuBtn->setCheckable(false);
        toolsMenuBtn->setChecked(false);
        toolsMenuBtn->setFlat(false);
        exitMenuBtn = new QPushButton(menuWidget);
        exitMenuBtn->setObjectName(QString::fromUtf8("exitMenuBtn"));
        exitMenuBtn->setGeometry(QRect(750, 4, 45, 23));
        exitMenuBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 2px groove rgb(255, 255, 255);\n"
"border-radius: 5px;"));
        exitMenuBtn->setCheckable(false);
        exitMenuBtn->setChecked(false);
        exitMenuBtn->setFlat(false);
        statusWidget = new QWidget(centralWidget);
        statusWidget->setObjectName(QString::fromUtf8("statusWidget"));
        statusWidget->setGeometry(QRect(0, 33, 725, 27));
        statusIconLbl = new QLabel(statusWidget);
        statusIconLbl->setObjectName(QString::fromUtf8("statusIconLbl"));
        statusIconLbl->setGeometry(QRect(10, 5, 16, 16));
        statusIconLbl->setMaximumSize(QSize(16, 16));
        statusIconLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        statusMsgLbl = new QLabel(statusWidget);
        statusMsgLbl->setObjectName(QString::fromUtf8("statusMsgLbl"));
        statusMsgLbl->setGeometry(QRect(30, 5, 691, 16));
        statusMsgLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        MainWindow->setCentralWidget(centralWidget);
        QWidget::setTabOrder(otpMenuBtn, oathHotpMenuBtn);
        QWidget::setTabOrder(oathHotpMenuBtn, staticMenuBtn);
        QWidget::setTabOrder(staticMenuBtn, chalRespMenuBtn);
        QWidget::setTabOrder(chalRespMenuBtn, settingsMenuBtn);
        QWidget::setTabOrder(settingsMenuBtn, toolsMenuBtn);
        QWidget::setTabOrder(toolsMenuBtn, aboutMenuBtn);
        QWidget::setTabOrder(aboutMenuBtn, serialNoDecCopyBtn);
        QWidget::setTabOrder(serialNoDecCopyBtn, serialNoHexCopyBtn);
        QWidget::setTabOrder(serialNoHexCopyBtn, serialNoModhexCopyBtn);

        retranslateUi(MainWindow);

        serialNoHexCopyBtn->setDefault(false);
        serialNoDecCopyBtn->setDefault(false);
        serialNoModhexCopyBtn->setDefault(false);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "YubiKey Personalization Tool", nullptr));
        versionDescLbl->setText(QApplication::translate("MainWindow", "Firmware Version:", nullptr));
        statusLbl->setText(QString());
        featureSupportBox->setTitle(QApplication::translate("MainWindow", "Features Supported", nullptr));
        multiConfigSupportDescLbl->setText(QApplication::translate("MainWindow", "2 Configurations", nullptr));
        oathHotpSupportDescLbl->setText(QApplication::translate("MainWindow", "OATH-HOTP", nullptr));
        chalRespSupportDescLbl->setText(QApplication::translate("MainWindow", "Challenge-Response", nullptr));
        multiConfigSupportLbl->setText(QApplication::translate("MainWindow", "N/A", nullptr));
        oathHotpSupportLbl->setText(QApplication::translate("MainWindow", "N/A", nullptr));
        chalRespSupportLbl->setText(QApplication::translate("MainWindow", "N/A", nullptr));
        staticPwdSupportLbl->setText(QApplication::translate("MainWindow", "N/A", nullptr));
        staticPwdSupportDescLbl->setText(QApplication::translate("MainWindow", "Static Password", nullptr));
        otpSupportDescLbl->setText(QApplication::translate("MainWindow", "Yubico OTP", nullptr));
        otpSupportLbl->setText(QApplication::translate("MainWindow", "N/A", nullptr));
        scanCodeSupportLbl->setText(QApplication::translate("MainWindow", "N/A", nullptr));
        scanCodeSupportDescLbl->setText(QApplication::translate("MainWindow", "Scan Code Mode", nullptr));
        updatableSupportDescLbl->setText(QApplication::translate("MainWindow", "Updatable", nullptr));
        updatableSupportLbl->setText(QApplication::translate("MainWindow", "N/A", nullptr));
        ndefSupportDescLbl->setText(QApplication::translate("MainWindow", "Ndef ", nullptr));
        ndefSupportLbl->setText(QApplication::translate("MainWindow", "N/A", nullptr));
        u2fSupportDescLbl->setText(QApplication::translate("MainWindow", "Universal 2nd Factor ", nullptr));
        u2fSupportLbl->setText(QApplication::translate("MainWindow", "N/A", nullptr));
        logoImg->setText(QString());
        serialNoBox->setTitle(QApplication::translate("MainWindow", "Serial Number", nullptr));
        serialNoHexCopyBtn->setText(QString());
        serialNoHexLbl->setText(QString());
        serialNoDecLbl->setText(QString());
        serialNoDecCopyBtn->setText(QString());
        serialNoModhexLbl->setText(QString());
        serialNoModhexCopyBtn->setText(QString());
        decLbl->setText(QApplication::translate("MainWindow", "Dec:", nullptr));
        hexLbl->setText(QApplication::translate("MainWindow", "Hex:", nullptr));
        modhexLbl->setText(QApplication::translate("MainWindow", "Modhex:", nullptr));
        programDescLbl->setText(QApplication::translate("MainWindow", "Programming status:", nullptr));
        otpMenuBtn->setText(QApplication::translate("MainWindow", "Yubico OTP", nullptr));
        settingsMenuBtn->setText(QApplication::translate("MainWindow", "Settings", nullptr));
        oathHotpMenuBtn->setText(QApplication::translate("MainWindow", "OATH-HOTP", nullptr));
        staticMenuBtn->setText(QApplication::translate("MainWindow", "Static Password", nullptr));
        chalRespMenuBtn->setText(QApplication::translate("MainWindow", "Challenge-Response", nullptr));
        aboutMenuBtn->setText(QApplication::translate("MainWindow", "About", nullptr));
        toolsMenuBtn->setText(QApplication::translate("MainWindow", "Tools", nullptr));
        exitMenuBtn->setText(QApplication::translate("MainWindow", "Exit", nullptr));
        statusIconLbl->setText(QString());
        statusMsgLbl->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
