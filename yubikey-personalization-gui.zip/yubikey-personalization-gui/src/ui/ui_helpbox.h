/********************************************************************************
** Form generated from reading UI file 'helpbox.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HELPBOX_H
#define UI_HELPBOX_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_HelpBox
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QTextBrowser *helpTxtBrowser;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *HelpBox)
    {
        if (HelpBox->objectName().isEmpty())
            HelpBox->setObjectName(QString::fromUtf8("HelpBox"));
        HelpBox->setWindowModality(Qt::NonModal);
        HelpBox->resize(500, 260);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(HelpBox->sizePolicy().hasHeightForWidth());
        HelpBox->setSizePolicy(sizePolicy);
        HelpBox->setMinimumSize(QSize(500, 100));
        HelpBox->setMaximumSize(QSize(500, 260));
        HelpBox->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        HelpBox->setSizeGripEnabled(false);
        verticalLayoutWidget = new QWidget(HelpBox);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(10, 10, 481, 241));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        helpTxtBrowser = new QTextBrowser(verticalLayoutWidget);
        helpTxtBrowser->setObjectName(QString::fromUtf8("helpTxtBrowser"));
        helpTxtBrowser->setAutoFillBackground(false);
        helpTxtBrowser->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";"));
        helpTxtBrowser->setFrameShape(QFrame::NoFrame);
        helpTxtBrowser->setFrameShadow(QFrame::Plain);
        helpTxtBrowser->setAutoFormatting(QTextEdit::AutoBulletList);
        helpTxtBrowser->setUndoRedoEnabled(false);
        helpTxtBrowser->setOpenExternalLinks(true);

        verticalLayout->addWidget(helpTxtBrowser);

        buttonBox = new QDialogButtonBox(verticalLayoutWidget);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Close);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(HelpBox);
        QObject::connect(buttonBox, SIGNAL(rejected()), HelpBox, SLOT(reject()));
        QObject::connect(buttonBox, SIGNAL(accepted()), HelpBox, SLOT(accept()));

        QMetaObject::connectSlotsByName(HelpBox);
    } // setupUi

    void retranslateUi(QDialog *HelpBox)
    {
        HelpBox->setWindowTitle(QApplication::translate("HelpBox", "Help - YubiKey ", nullptr));
        helpTxtBrowser->setHtml(QApplication::translate("HelpBox", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Verdana'; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class HelpBox: public Ui_HelpBox {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HELPBOX_H
