/********************************************************************************
** Form generated from reading UI file 'settingpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGPAGE_H
#define UI_SETTINGPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>
#include "yubiaccbox.h"

QT_BEGIN_NAMESPACE

class Ui_SettingPage
{
public:
    QWidget *basePage;
    QLabel *baseHeadingLabel;
    QGroupBox *generalBox;
    QCheckBox *custPrefixCheck;
    QLineEdit *custPrefixDecTxt;
    QLabel *custPrefixDecLabel;
    QLabel *custPrefixModhexLabel;
    QLineEdit *custPrefixModhexTxt;
    QLabel *custPrefixHexLabel;
    QLineEdit *custPrefixHexTxt;
    QGroupBox *loggingBox;
    QCheckBox *logOutputCheck;
    QComboBox *logFormatCombo;
    QLineEdit *logFormatEdit;
    QPushButton *logFormatEditHelpBtn;
    QGroupBox *actionsBox;
    QLabel *actionsDescLbl;
    QPushButton *restoreBtn;
    QPushButton *updateBtn;
    QLabel *updateDescLbl;
    QGroupBox *outputBox;
    QGroupBox *outFormatBox;
    QPushButton *tabFirstBtn;
    QPushButton *appendTab1Btn;
    QPushButton *appendTab2Btn;
    QLabel *pubIdLbl;
    QLabel *otpLbl;
    QPushButton *appendCRBtn;
    QPushButton *outFormatHelpBtn;
    QGroupBox *outSpeedBox;
    QPushButton *outSpeedHelpBtn;
    QComboBox *outCharRateCombo;
    QLabel *outCharRateLbl;
    QCheckBox *appendDelay1Check;
    QCheckBox *appendDelay2Check;
    QGroupBox *srVisibilityBox;
    QCheckBox *srBtnVisibleCheck;
    QCheckBox *srUsbVisibleCheck;
    QCheckBox *srApiVisibleCheck;
    QPushButton *srVisibilityHelpBtn;
    QGroupBox *staticBox;
    QCheckBox *manUpdateCheck;
    QPushButton *manUpdateHelpBtn;
    QGroupBox *UpdateBox;
    QCheckBox *updateCheck;
    QPushButton *updateHelpBtn;
    QGroupBox *ExtendedBox;
    QCheckBox *useNumericKeypadCheck;
    QCheckBox *fastTrigCheck;
    QCheckBox *ledInvertCheck;
    QGroupBox *applicationBox;
    QCheckBox *exportCheck;
    QWidget *updatePage;
    QLabel *updateHeadingLabel;
    QGroupBox *updateActionsBox;
    QPushButton *doUpdateBtn;
    QPushButton *updateBackBtn;
    QPushButton *swapBtn;
    QPushButton *swapHelpBtn;
    QGroupBox *slotGroupBox;
    QLabel *updateSlotLabel;
    QRadioButton *updateSlot1Radio;
    QRadioButton *updateSlot2Radio;
    QGroupBox *dormantGroupBox;
    QLabel *updateDormantLabel;
    QCheckBox *updateDormantCheck;
    YubiAccBox *configProtectionBox;

    void setupUi(QStackedWidget *SettingPage)
    {
        if (SettingPage->objectName().isEmpty())
            SettingPage->setObjectName(QString::fromUtf8("SettingPage"));
        SettingPage->resize(730, 650);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SettingPage->sizePolicy().hasHeightForWidth());
        SettingPage->setSizePolicy(sizePolicy);
        SettingPage->setMaximumSize(QSize(730, 650));
        SettingPage->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        basePage = new QWidget();
        basePage->setObjectName(QString::fromUtf8("basePage"));
        sizePolicy.setHeightForWidth(basePage->sizePolicy().hasHeightForWidth());
        basePage->setSizePolicy(sizePolicy);
        basePage->setMaximumSize(QSize(730, 650));
        basePage->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        baseHeadingLabel = new QLabel(basePage);
        baseHeadingLabel->setObjectName(QString::fromUtf8("baseHeadingLabel"));
        baseHeadingLabel->setGeometry(QRect(10, 0, 710, 22));
        baseHeadingLabel->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        baseHeadingLabel->setAlignment(Qt::AlignCenter);
        generalBox = new QGroupBox(basePage);
        generalBox->setObjectName(QString::fromUtf8("generalBox"));
        generalBox->setGeometry(QRect(10, 35, 711, 70));
        generalBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        custPrefixCheck = new QCheckBox(generalBox);
        custPrefixCheck->setObjectName(QString::fromUtf8("custPrefixCheck"));
        custPrefixCheck->setGeometry(QRect(10, 40, 231, 17));
        custPrefixCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        custPrefixDecTxt = new QLineEdit(generalBox);
        custPrefixDecTxt->setObjectName(QString::fromUtf8("custPrefixDecTxt"));
        custPrefixDecTxt->setEnabled(true);
        custPrefixDecTxt->setGeometry(QRect(240, 40, 61, 20));
        custPrefixDecTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        custPrefixDecTxt->setMaxLength(5);
        custPrefixDecTxt->setCursorPosition(0);
        custPrefixDecLabel = new QLabel(generalBox);
        custPrefixDecLabel->setObjectName(QString::fromUtf8("custPrefixDecLabel"));
        custPrefixDecLabel->setGeometry(QRect(240, 20, 61, 18));
        custPrefixDecLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"       color: rgb(118, 116, 108);"));
        custPrefixDecLabel->setAlignment(Qt::AlignCenter);
        custPrefixModhexLabel = new QLabel(generalBox);
        custPrefixModhexLabel->setObjectName(QString::fromUtf8("custPrefixModhexLabel"));
        custPrefixModhexLabel->setGeometry(QRect(340, 20, 61, 18));
        custPrefixModhexLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"       color: rgb(118, 116, 108);"));
        custPrefixModhexLabel->setAlignment(Qt::AlignCenter);
        custPrefixModhexTxt = new QLineEdit(generalBox);
        custPrefixModhexTxt->setObjectName(QString::fromUtf8("custPrefixModhexTxt"));
        custPrefixModhexTxt->setEnabled(true);
        custPrefixModhexTxt->setGeometry(QRect(340, 40, 61, 20));
        custPrefixModhexTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        custPrefixModhexTxt->setMaxLength(32767);
        custPrefixModhexTxt->setCursorPosition(0);
        custPrefixHexLabel = new QLabel(generalBox);
        custPrefixHexLabel->setObjectName(QString::fromUtf8("custPrefixHexLabel"));
        custPrefixHexLabel->setGeometry(QRect(440, 20, 61, 18));
        custPrefixHexLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"       color: rgb(118, 116, 108);"));
        custPrefixHexLabel->setAlignment(Qt::AlignCenter);
        custPrefixHexTxt = new QLineEdit(generalBox);
        custPrefixHexTxt->setObjectName(QString::fromUtf8("custPrefixHexTxt"));
        custPrefixHexTxt->setEnabled(true);
        custPrefixHexTxt->setGeometry(QRect(440, 40, 61, 20));
        custPrefixHexTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        custPrefixHexTxt->setMaxLength(4);
        custPrefixHexTxt->setCursorPosition(0);
        loggingBox = new QGroupBox(basePage);
        loggingBox->setObjectName(QString::fromUtf8("loggingBox"));
        loggingBox->setGeometry(QRect(10, 450, 711, 50));
        loggingBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        logOutputCheck = new QCheckBox(loggingBox);
        logOutputCheck->setObjectName(QString::fromUtf8("logOutputCheck"));
        logOutputCheck->setGeometry(QRect(10, 25, 171, 19));
        logOutputCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        logFormatCombo = new QComboBox(loggingBox);
        logFormatCombo->addItem(QString());
        logFormatCombo->addItem(QString());
        logFormatCombo->addItem(QString());
        logFormatCombo->addItem(QString());
        logFormatCombo->setObjectName(QString::fromUtf8("logFormatCombo"));
        logFormatCombo->setGeometry(QRect(200, 25, 125, 22));
        sizePolicy.setHeightForWidth(logFormatCombo->sizePolicy().hasHeightForWidth());
        logFormatCombo->setSizePolicy(sizePolicy);
        logFormatCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        logFormatEdit = new QLineEdit(loggingBox);
        logFormatEdit->setObjectName(QString::fromUtf8("logFormatEdit"));
        logFormatEdit->setEnabled(false);
        logFormatEdit->setGeometry(QRect(350, 25, 325, 20));
        logFormatEdit->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        logFormatEditHelpBtn = new QPushButton(loggingBox);
        logFormatEditHelpBtn->setObjectName(QString::fromUtf8("logFormatEditHelpBtn"));
        logFormatEditHelpBtn->setGeometry(QRect(680, 25, 16, 16));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(logFormatEditHelpBtn->sizePolicy().hasHeightForWidth());
        logFormatEditHelpBtn->setSizePolicy(sizePolicy1);
        logFormatEditHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        logFormatEditHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        logFormatEditHelpBtn->setLayoutDirection(Qt::LeftToRight);
        logFormatEditHelpBtn->setAutoFillBackground(false);
        logFormatEditHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        logFormatEditHelpBtn->setAutoDefault(false);
        actionsBox = new QGroupBox(basePage);
        actionsBox->setObjectName(QString::fromUtf8("actionsBox"));
        actionsBox->setGeometry(QRect(10, 550, 711, 80));
        actionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        actionsDescLbl = new QLabel(actionsBox);
        actionsDescLbl->setObjectName(QString::fromUtf8("actionsDescLbl"));
        actionsDescLbl->setGeometry(QRect(10, 25, 200, 16));
        actionsDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        restoreBtn = new QPushButton(actionsBox);
        restoreBtn->setObjectName(QString::fromUtf8("restoreBtn"));
        restoreBtn->setEnabled(true);
        restoreBtn->setGeometry(QRect(10, 45, 171, 25));
        restoreBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        restoreBtn->setAutoExclusive(false);
        restoreBtn->setFlat(false);
        updateBtn = new QPushButton(actionsBox);
        updateBtn->setObjectName(QString::fromUtf8("updateBtn"));
        updateBtn->setEnabled(false);
        updateBtn->setGeometry(QRect(480, 45, 171, 27));
        updateDescLbl = new QLabel(actionsBox);
        updateDescLbl->setObjectName(QString::fromUtf8("updateDescLbl"));
        updateDescLbl->setGeometry(QRect(405, 25, 275, 16));
        updateDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        outputBox = new QGroupBox(basePage);
        outputBox->setObjectName(QString::fromUtf8("outputBox"));
        outputBox->setGeometry(QRect(10, 105, 711, 165));
        outputBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        outFormatBox = new QGroupBox(outputBox);
        outFormatBox->setObjectName(QString::fromUtf8("outFormatBox"));
        outFormatBox->setGeometry(QRect(10, 25, 691, 58));
        outFormatBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        outFormatBox->setCheckable(false);
        tabFirstBtn = new QPushButton(outFormatBox);
        tabFirstBtn->setObjectName(QString::fromUtf8("tabFirstBtn"));
        tabFirstBtn->setGeometry(QRect(10, 25, 68, 25));
        tabFirstBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        tabFirstBtn->setCheckable(true);
        tabFirstBtn->setAutoExclusive(false);
        tabFirstBtn->setFlat(false);
        appendTab1Btn = new QPushButton(outFormatBox);
        appendTab1Btn->setObjectName(QString::fromUtf8("appendTab1Btn"));
        appendTab1Btn->setGeometry(QRect(170, 25, 68, 25));
        appendTab1Btn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        appendTab1Btn->setCheckable(true);
        appendTab1Btn->setAutoExclusive(false);
        appendTab1Btn->setFlat(false);
        appendTab2Btn = new QPushButton(outFormatBox);
        appendTab2Btn->setObjectName(QString::fromUtf8("appendTab2Btn"));
        appendTab2Btn->setGeometry(QRect(310, 25, 68, 25));
        appendTab2Btn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        appendTab2Btn->setCheckable(true);
        appendTab2Btn->setAutoExclusive(false);
        appendTab2Btn->setFlat(false);
        pubIdLbl = new QLabel(outFormatBox);
        pubIdLbl->setObjectName(QString::fromUtf8("pubIdLbl"));
        pubIdLbl->setGeometry(QRect(98, 25, 52, 25));
        pubIdLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        otpLbl = new QLabel(outFormatBox);
        otpLbl->setObjectName(QString::fromUtf8("otpLbl"));
        otpLbl->setGeometry(QRect(258, 25, 32, 25));
        otpLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        appendCRBtn = new QPushButton(outFormatBox);
        appendCRBtn->setObjectName(QString::fromUtf8("appendCRBtn"));
        appendCRBtn->setGeometry(QRect(398, 25, 68, 25));
        appendCRBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        appendCRBtn->setCheckable(true);
        appendCRBtn->setChecked(true);
        appendCRBtn->setAutoExclusive(false);
        appendCRBtn->setFlat(false);
        outFormatHelpBtn = new QPushButton(outFormatBox);
        outFormatHelpBtn->setObjectName(QString::fromUtf8("outFormatHelpBtn"));
        outFormatHelpBtn->setGeometry(QRect(665, 0, 16, 16));
        sizePolicy1.setHeightForWidth(outFormatHelpBtn->sizePolicy().hasHeightForWidth());
        outFormatHelpBtn->setSizePolicy(sizePolicy1);
        outFormatHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        outFormatHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        outFormatHelpBtn->setLayoutDirection(Qt::LeftToRight);
        outFormatHelpBtn->setAutoFillBackground(false);
        outFormatHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        outFormatHelpBtn->setAutoDefault(false);
        outSpeedBox = new QGroupBox(outputBox);
        outSpeedBox->setObjectName(QString::fromUtf8("outSpeedBox"));
        outSpeedBox->setGeometry(QRect(10, 85, 691, 70));
        outSpeedBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        outSpeedHelpBtn = new QPushButton(outSpeedBox);
        outSpeedHelpBtn->setObjectName(QString::fromUtf8("outSpeedHelpBtn"));
        outSpeedHelpBtn->setGeometry(QRect(665, 0, 16, 16));
        sizePolicy1.setHeightForWidth(outSpeedHelpBtn->sizePolicy().hasHeightForWidth());
        outSpeedHelpBtn->setSizePolicy(sizePolicy1);
        outSpeedHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        outSpeedHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        outSpeedHelpBtn->setLayoutDirection(Qt::LeftToRight);
        outSpeedHelpBtn->setAutoFillBackground(false);
        outSpeedHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        outSpeedHelpBtn->setAutoDefault(false);
        outCharRateCombo = new QComboBox(outSpeedBox);
        outCharRateCombo->addItem(QString());
        outCharRateCombo->addItem(QString());
        outCharRateCombo->addItem(QString());
        outCharRateCombo->addItem(QString());
        outCharRateCombo->setObjectName(QString::fromUtf8("outCharRateCombo"));
        outCharRateCombo->setGeometry(QRect(170, 24, 171, 22));
        sizePolicy.setHeightForWidth(outCharRateCombo->sizePolicy().hasHeightForWidth());
        outCharRateCombo->setSizePolicy(sizePolicy);
        outCharRateCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        outCharRateLbl = new QLabel(outSpeedBox);
        outCharRateLbl->setObjectName(QString::fromUtf8("outCharRateLbl"));
        outCharRateLbl->setGeometry(QRect(10, 25, 151, 20));
        outCharRateLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        appendDelay1Check = new QCheckBox(outSpeedBox);
        appendDelay1Check->setObjectName(QString::fromUtf8("appendDelay1Check"));
        appendDelay1Check->setGeometry(QRect(10, 50, 281, 17));
        appendDelay1Check->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        appendDelay2Check = new QCheckBox(outSpeedBox);
        appendDelay2Check->setObjectName(QString::fromUtf8("appendDelay2Check"));
        appendDelay2Check->setGeometry(QRect(360, 50, 271, 17));
        appendDelay2Check->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        srVisibilityBox = new QGroupBox(basePage);
        srVisibilityBox->setObjectName(QString::fromUtf8("srVisibilityBox"));
        srVisibilityBox->setGeometry(QRect(10, 275, 350, 100));
        srVisibilityBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        srBtnVisibleCheck = new QCheckBox(srVisibilityBox);
        srBtnVisibleCheck->setObjectName(QString::fromUtf8("srBtnVisibleCheck"));
        srBtnVisibleCheck->setGeometry(QRect(10, 25, 221, 17));
        srBtnVisibleCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        srUsbVisibleCheck = new QCheckBox(srVisibilityBox);
        srUsbVisibleCheck->setObjectName(QString::fromUtf8("srUsbVisibleCheck"));
        srUsbVisibleCheck->setGeometry(QRect(10, 50, 221, 17));
        srUsbVisibleCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        srApiVisibleCheck = new QCheckBox(srVisibilityBox);
        srApiVisibleCheck->setObjectName(QString::fromUtf8("srApiVisibleCheck"));
        srApiVisibleCheck->setGeometry(QRect(10, 75, 221, 17));
        srApiVisibleCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        srVisibilityHelpBtn = new QPushButton(srVisibilityBox);
        srVisibilityHelpBtn->setObjectName(QString::fromUtf8("srVisibilityHelpBtn"));
        srVisibilityHelpBtn->setGeometry(QRect(315, 0, 16, 16));
        sizePolicy1.setHeightForWidth(srVisibilityHelpBtn->sizePolicy().hasHeightForWidth());
        srVisibilityHelpBtn->setSizePolicy(sizePolicy1);
        srVisibilityHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        srVisibilityHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        srVisibilityHelpBtn->setLayoutDirection(Qt::LeftToRight);
        srVisibilityHelpBtn->setAutoFillBackground(false);
        srVisibilityHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        srVisibilityHelpBtn->setAutoDefault(false);
        staticBox = new QGroupBox(basePage);
        staticBox->setObjectName(QString::fromUtf8("staticBox"));
        staticBox->setGeometry(QRect(370, 275, 350, 50));
        staticBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        manUpdateCheck = new QCheckBox(staticBox);
        manUpdateCheck->setObjectName(QString::fromUtf8("manUpdateCheck"));
        manUpdateCheck->setGeometry(QRect(10, 25, 331, 17));
        manUpdateCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        manUpdateHelpBtn = new QPushButton(staticBox);
        manUpdateHelpBtn->setObjectName(QString::fromUtf8("manUpdateHelpBtn"));
        manUpdateHelpBtn->setGeometry(QRect(315, 0, 16, 16));
        sizePolicy1.setHeightForWidth(manUpdateHelpBtn->sizePolicy().hasHeightForWidth());
        manUpdateHelpBtn->setSizePolicy(sizePolicy1);
        manUpdateHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        manUpdateHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        manUpdateHelpBtn->setLayoutDirection(Qt::LeftToRight);
        manUpdateHelpBtn->setAutoFillBackground(false);
        manUpdateHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        manUpdateHelpBtn->setAutoDefault(false);
        UpdateBox = new QGroupBox(basePage);
        UpdateBox->setObjectName(QString::fromUtf8("UpdateBox"));
        UpdateBox->setGeometry(QRect(10, 390, 350, 50));
        UpdateBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        updateCheck = new QCheckBox(UpdateBox);
        updateCheck->setObjectName(QString::fromUtf8("updateCheck"));
        updateCheck->setGeometry(QRect(10, 25, 331, 17));
        updateCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        updateHelpBtn = new QPushButton(UpdateBox);
        updateHelpBtn->setObjectName(QString::fromUtf8("updateHelpBtn"));
        updateHelpBtn->setGeometry(QRect(315, 0, 16, 16));
        sizePolicy1.setHeightForWidth(updateHelpBtn->sizePolicy().hasHeightForWidth());
        updateHelpBtn->setSizePolicy(sizePolicy1);
        updateHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        updateHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        updateHelpBtn->setLayoutDirection(Qt::LeftToRight);
        updateHelpBtn->setAutoFillBackground(false);
        updateHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        updateHelpBtn->setAutoDefault(false);
        ExtendedBox = new QGroupBox(basePage);
        ExtendedBox->setObjectName(QString::fromUtf8("ExtendedBox"));
        ExtendedBox->setGeometry(QRect(370, 340, 350, 100));
        ExtendedBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        useNumericKeypadCheck = new QCheckBox(ExtendedBox);
        useNumericKeypadCheck->setObjectName(QString::fromUtf8("useNumericKeypadCheck"));
        useNumericKeypadCheck->setGeometry(QRect(10, 25, 331, 17));
        useNumericKeypadCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        fastTrigCheck = new QCheckBox(ExtendedBox);
        fastTrigCheck->setObjectName(QString::fromUtf8("fastTrigCheck"));
        fastTrigCheck->setGeometry(QRect(10, 50, 340, 17));
        fastTrigCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        ledInvertCheck = new QCheckBox(ExtendedBox);
        ledInvertCheck->setObjectName(QString::fromUtf8("ledInvertCheck"));
        ledInvertCheck->setGeometry(QRect(10, 75, 331, 17));
        ledInvertCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        applicationBox = new QGroupBox(basePage);
        applicationBox->setObjectName(QString::fromUtf8("applicationBox"));
        applicationBox->setGeometry(QRect(10, 500, 711, 50));
        applicationBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        exportCheck = new QCheckBox(applicationBox);
        exportCheck->setObjectName(QString::fromUtf8("exportCheck"));
        exportCheck->setGeometry(QRect(10, 25, 350, 19));
        exportCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        SettingPage->addWidget(basePage);
        updatePage = new QWidget();
        updatePage->setObjectName(QString::fromUtf8("updatePage"));
        sizePolicy.setHeightForWidth(updatePage->sizePolicy().hasHeightForWidth());
        updatePage->setSizePolicy(sizePolicy);
        updateHeadingLabel = new QLabel(updatePage);
        updateHeadingLabel->setObjectName(QString::fromUtf8("updateHeadingLabel"));
        updateHeadingLabel->setGeometry(QRect(10, 0, 710, 22));
        updateHeadingLabel->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        updateHeadingLabel->setAlignment(Qt::AlignCenter);
        updateActionsBox = new QGroupBox(updatePage);
        updateActionsBox->setObjectName(QString::fromUtf8("updateActionsBox"));
        updateActionsBox->setGeometry(QRect(10, 210, 711, 50));
        updateActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        doUpdateBtn = new QPushButton(updateActionsBox);
        doUpdateBtn->setObjectName(QString::fromUtf8("doUpdateBtn"));
        doUpdateBtn->setGeometry(QRect(10, 10, 85, 25));
        doUpdateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        doUpdateBtn->setAutoExclusive(false);
        doUpdateBtn->setFlat(false);
        updateBackBtn = new QPushButton(updateActionsBox);
        updateBackBtn->setObjectName(QString::fromUtf8("updateBackBtn"));
        updateBackBtn->setEnabled(true);
        updateBackBtn->setGeometry(QRect(110, 10, 85, 25));
        updateBackBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        updateBackBtn->setAutoExclusive(false);
        updateBackBtn->setFlat(false);
        swapBtn = new QPushButton(updateActionsBox);
        swapBtn->setObjectName(QString::fromUtf8("swapBtn"));
        swapBtn->setGeometry(QRect(370, 10, 85, 25));
        swapBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        swapBtn->setAutoExclusive(false);
        swapBtn->setFlat(false);
        swapHelpBtn = new QPushButton(updateActionsBox);
        swapHelpBtn->setObjectName(QString::fromUtf8("swapHelpBtn"));
        swapHelpBtn->setGeometry(QRect(465, 14, 16, 16));
        sizePolicy1.setHeightForWidth(swapHelpBtn->sizePolicy().hasHeightForWidth());
        swapHelpBtn->setSizePolicy(sizePolicy1);
        swapHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        swapHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        swapHelpBtn->setLayoutDirection(Qt::LeftToRight);
        swapHelpBtn->setAutoFillBackground(false);
        swapHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        swapHelpBtn->setAutoDefault(false);
        slotGroupBox = new QGroupBox(updatePage);
        slotGroupBox->setObjectName(QString::fromUtf8("slotGroupBox"));
        slotGroupBox->setGeometry(QRect(10, 50, 350, 65));
        slotGroupBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        updateSlotLabel = new QLabel(slotGroupBox);
        updateSlotLabel->setObjectName(QString::fromUtf8("updateSlotLabel"));
        updateSlotLabel->setGeometry(QRect(10, 20, 321, 16));
        updateSlotLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        updateSlot1Radio = new QRadioButton(slotGroupBox);
        updateSlot1Radio->setObjectName(QString::fromUtf8("updateSlot1Radio"));
        updateSlot1Radio->setGeometry(QRect(10, 40, 151, 19));
        updateSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        updateSlot1Radio->setCheckable(true);
        updateSlot1Radio->setChecked(false);
        updateSlot2Radio = new QRadioButton(slotGroupBox);
        updateSlot2Radio->setObjectName(QString::fromUtf8("updateSlot2Radio"));
        updateSlot2Radio->setGeometry(QRect(200, 40, 151, 19));
        updateSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        dormantGroupBox = new QGroupBox(updatePage);
        dormantGroupBox->setObjectName(QString::fromUtf8("dormantGroupBox"));
        dormantGroupBox->setGeometry(QRect(10, 125, 350, 55));
        updateDormantLabel = new QLabel(dormantGroupBox);
        updateDormantLabel->setObjectName(QString::fromUtf8("updateDormantLabel"));
        updateDormantLabel->setGeometry(QRect(10, 10, 321, 16));
        updateDormantLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        updateDormantCheck = new QCheckBox(dormantGroupBox);
        updateDormantCheck->setObjectName(QString::fromUtf8("updateDormantCheck"));
        updateDormantCheck->setGeometry(QRect(10, 30, 151, 17));
        updateDormantCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        configProtectionBox = new YubiAccBox(updatePage);
        configProtectionBox->setObjectName(QString::fromUtf8("configProtectionBox"));
        configProtectionBox->setGeometry(QRect(370, 50, 350, 117));
        SettingPage->addWidget(updatePage);
        QWidget::setTabOrder(custPrefixCheck, custPrefixDecTxt);
        QWidget::setTabOrder(custPrefixDecTxt, custPrefixModhexTxt);
        QWidget::setTabOrder(custPrefixModhexTxt, custPrefixHexTxt);
        QWidget::setTabOrder(custPrefixHexTxt, tabFirstBtn);
        QWidget::setTabOrder(tabFirstBtn, appendTab1Btn);
        QWidget::setTabOrder(appendTab1Btn, appendTab2Btn);
        QWidget::setTabOrder(appendTab2Btn, appendCRBtn);
        QWidget::setTabOrder(appendCRBtn, outCharRateCombo);
        QWidget::setTabOrder(outCharRateCombo, appendDelay1Check);
        QWidget::setTabOrder(appendDelay1Check, appendDelay2Check);
        QWidget::setTabOrder(appendDelay2Check, srBtnVisibleCheck);
        QWidget::setTabOrder(srBtnVisibleCheck, srUsbVisibleCheck);
        QWidget::setTabOrder(srUsbVisibleCheck, srApiVisibleCheck);
        QWidget::setTabOrder(srApiVisibleCheck, manUpdateCheck);
        QWidget::setTabOrder(manUpdateCheck, logOutputCheck);
        QWidget::setTabOrder(logOutputCheck, restoreBtn);
        QWidget::setTabOrder(restoreBtn, outFormatHelpBtn);
        QWidget::setTabOrder(outFormatHelpBtn, outSpeedHelpBtn);
        QWidget::setTabOrder(outSpeedHelpBtn, srVisibilityHelpBtn);

        retranslateUi(SettingPage);

        SettingPage->setCurrentIndex(0);
        logFormatEditHelpBtn->setDefault(false);
        restoreBtn->setDefault(false);
        tabFirstBtn->setDefault(false);
        appendTab1Btn->setDefault(false);
        appendTab2Btn->setDefault(false);
        appendCRBtn->setDefault(false);
        outFormatHelpBtn->setDefault(false);
        outSpeedHelpBtn->setDefault(false);
        srVisibilityHelpBtn->setDefault(false);
        manUpdateHelpBtn->setDefault(false);
        updateHelpBtn->setDefault(false);
        doUpdateBtn->setDefault(false);
        updateBackBtn->setDefault(false);
        swapBtn->setDefault(false);
        swapHelpBtn->setDefault(false);


        QMetaObject::connectSlotsByName(SettingPage);
    } // setupUi

    void retranslateUi(QStackedWidget *SettingPage)
    {
        SettingPage->setWindowTitle(QApplication::translate("SettingPage", "StackedWidget", nullptr));
        basePage->setWindowTitle(QApplication::translate("SettingPage", "Form", nullptr));
        baseHeadingLabel->setText(QApplication::translate("SettingPage", "Settings", nullptr));
        generalBox->setTitle(QApplication::translate("SettingPage", "General Settings", nullptr));
        custPrefixCheck->setText(QApplication::translate("SettingPage", "Use and enforce customer prefix", nullptr));
        custPrefixDecTxt->setText(QString());
        custPrefixDecLabel->setText(QApplication::translate("SettingPage", "Decimal", nullptr));
        custPrefixModhexLabel->setText(QApplication::translate("SettingPage", "ModHex", nullptr));
        custPrefixModhexTxt->setInputMask(QString());
        custPrefixModhexTxt->setText(QString());
        custPrefixHexLabel->setText(QApplication::translate("SettingPage", "Hex", nullptr));
        custPrefixHexTxt->setText(QString());
        loggingBox->setTitle(QApplication::translate("SettingPage", "Logging Settings", nullptr));
        logOutputCheck->setText(QApplication::translate("SettingPage", "Log configuration output", nullptr));
        logFormatCombo->setItemText(0, QApplication::translate("SettingPage", "Traditional format", nullptr));
        logFormatCombo->setItemText(1, QApplication::translate("SettingPage", "Yubico format", nullptr));
        logFormatCombo->setItemText(2, QApplication::translate("SettingPage", "Flexible format", nullptr));
        logFormatCombo->setItemText(3, QApplication::translate("SettingPage", "PSKC format", nullptr));

        logFormatEditHelpBtn->setText(QString());
        actionsBox->setTitle(QApplication::translate("SettingPage", "Actions", nullptr));
        actionsDescLbl->setText(QApplication::translate("SettingPage", "Settings are saved automatically", nullptr));
#ifndef QT_NO_WHATSTHIS
        restoreBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        restoreBtn->setText(QApplication::translate("SettingPage", "Restore Defaults", nullptr));
        updateBtn->setText(QApplication::translate("SettingPage", "Update Settings...", nullptr));
        updateDescLbl->setText(QApplication::translate("SettingPage", "Update is available for YubiKey 2.3 and later", nullptr));
        outputBox->setTitle(QApplication::translate("SettingPage", "Output Settings", nullptr));
        outFormatBox->setTitle(QApplication::translate("SettingPage", "Output Format", nullptr));
        tabFirstBtn->setText(QApplication::translate("SettingPage", "Tab", nullptr));
        appendTab1Btn->setText(QApplication::translate("SettingPage", "Tab", nullptr));
        appendTab2Btn->setText(QApplication::translate("SettingPage", "Tab", nullptr));
        pubIdLbl->setText(QApplication::translate("SettingPage", "Public ID", nullptr));
        otpLbl->setText(QApplication::translate("SettingPage", "OTP", nullptr));
        appendCRBtn->setText(QApplication::translate("SettingPage", "Enter", nullptr));
        outFormatHelpBtn->setText(QString());
        outSpeedBox->setTitle(QApplication::translate("SettingPage", "Output Speed Throttling", nullptr));
        outSpeedHelpBtn->setText(QString());
        outCharRateCombo->setItemText(0, QApplication::translate("SettingPage", "Standard", nullptr));
        outCharRateCombo->setItemText(1, QApplication::translate("SettingPage", "Slow down by 20 ms", nullptr));
        outCharRateCombo->setItemText(2, QApplication::translate("SettingPage", "Slow down by 40 ms", nullptr));
        outCharRateCombo->setItemText(3, QApplication::translate("SettingPage", "Slow down by 60 ms", nullptr));

        outCharRateLbl->setText(QApplication::translate("SettingPage", "Output Character Rate", nullptr));
        appendDelay1Check->setText(QApplication::translate("SettingPage", "Add a short delay before sending OTP part", nullptr));
        appendDelay2Check->setText(QApplication::translate("SettingPage", "Add a short delay after sending OTP part", nullptr));
        srVisibilityBox->setTitle(QApplication::translate("SettingPage", "Serial # Visibility Settings", nullptr));
        srBtnVisibleCheck->setText(QApplication::translate("SettingPage", "Button at startup (2.2+)", nullptr));
        srUsbVisibleCheck->setText(QApplication::translate("SettingPage", "USB descriptor (2.2+/3.2+)", nullptr));
        srApiVisibleCheck->setText(QApplication::translate("SettingPage", "API call (2.2+/3.0+)", nullptr));
        srVisibilityHelpBtn->setText(QString());
        staticBox->setTitle(QApplication::translate("SettingPage", "Static Password Settings", nullptr));
        manUpdateCheck->setText(QApplication::translate("SettingPage", "Enable manual update using the button (2.0+)", nullptr));
        manUpdateHelpBtn->setText(QString());
        UpdateBox->setTitle(QApplication::translate("SettingPage", "Update Settings", nullptr));
        updateCheck->setText(QApplication::translate("SettingPage", "Enable updating of YubiKey configuration (2.3+/3.0+)", nullptr));
        updateHelpBtn->setText(QString());
        ExtendedBox->setTitle(QApplication::translate("SettingPage", "Extended Settings", nullptr));
        useNumericKeypadCheck->setText(QApplication::translate("SettingPage", "Use numeric keypad for digits (2.3+)", nullptr));
        fastTrigCheck->setText(QApplication::translate("SettingPage", "Use fast triggering if only slot 1 is programmed (2.3+)", nullptr));
        ledInvertCheck->setText(QApplication::translate("SettingPage", "Invert led behaviour (2.4+/3.1+)", nullptr));
        applicationBox->setTitle(QApplication::translate("SettingPage", "Application Settings", nullptr));
        exportCheck->setText(QApplication::translate("SettingPage", "Enable configuration export and import (experimental)", nullptr));
        updateHeadingLabel->setText(QApplication::translate("SettingPage", "Update YubiKey Settings", nullptr));
        updateActionsBox->setTitle(QString());
        doUpdateBtn->setText(QApplication::translate("SettingPage", "Update", nullptr));
#ifndef QT_NO_WHATSTHIS
        updateBackBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        updateBackBtn->setText(QApplication::translate("SettingPage", "Back", nullptr));
        swapBtn->setText(QApplication::translate("SettingPage", "Swap", nullptr));
        swapHelpBtn->setText(QString());
        slotGroupBox->setTitle(QApplication::translate("SettingPage", "Configuration Slot", nullptr));
        updateSlotLabel->setText(QApplication::translate("SettingPage", "Select the configuration slot to be updated", nullptr));
        updateSlot1Radio->setText(QApplication::translate("SettingPage", "Configuration Slot 1", nullptr));
        updateSlot2Radio->setText(QApplication::translate("SettingPage", "Configuration Slot 2", nullptr));
        updateDormantLabel->setText(QApplication::translate("SettingPage", "Select to make the configuration dormant", nullptr));
        updateDormantCheck->setText(QApplication::translate("SettingPage", "Dormant", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SettingPage: public Ui_SettingPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGPAGE_H
