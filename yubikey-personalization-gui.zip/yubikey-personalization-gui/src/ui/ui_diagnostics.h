/********************************************************************************
** Form generated from reading UI file 'diagnostics.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIAGNOSTICS_H
#define UI_DIAGNOSTICS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Diagnostics
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QTextBrowser *txtBrowser;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *Diagnostics)
    {
        if (Diagnostics->objectName().isEmpty())
            Diagnostics->setObjectName(QString::fromUtf8("Diagnostics"));
        Diagnostics->setWindowModality(Qt::NonModal);
        Diagnostics->resize(500, 260);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Diagnostics->sizePolicy().hasHeightForWidth());
        Diagnostics->setSizePolicy(sizePolicy);
        Diagnostics->setMinimumSize(QSize(500, 100));
        Diagnostics->setMaximumSize(QSize(500, 260));
        Diagnostics->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        Diagnostics->setSizeGripEnabled(false);
        verticalLayoutWidget = new QWidget(Diagnostics);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(10, 10, 481, 241));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        txtBrowser = new QTextBrowser(verticalLayoutWidget);
        txtBrowser->setObjectName(QString::fromUtf8("txtBrowser"));
        txtBrowser->setAutoFillBackground(false);
        txtBrowser->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";"));
        txtBrowser->setFrameShape(QFrame::NoFrame);
        txtBrowser->setFrameShadow(QFrame::Plain);
        txtBrowser->setAutoFormatting(QTextEdit::AutoBulletList);
        txtBrowser->setUndoRedoEnabled(false);
        txtBrowser->setOpenExternalLinks(true);

        verticalLayout->addWidget(txtBrowser);

        buttonBox = new QDialogButtonBox(verticalLayoutWidget);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Close|QDialogButtonBox::Reset);
        buttonBox->setCenterButtons(true);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(Diagnostics);
        QObject::connect(buttonBox, SIGNAL(rejected()), Diagnostics, SLOT(reject()));
        QObject::connect(buttonBox, SIGNAL(accepted()), Diagnostics, SLOT(accept()));

        QMetaObject::connectSlotsByName(Diagnostics);
    } // setupUi

    void retranslateUi(QDialog *Diagnostics)
    {
        Diagnostics->setWindowTitle(QApplication::translate("Diagnostics", "YubiKey Diagnostics", nullptr));
        txtBrowser->setHtml(QApplication::translate("Diagnostics", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Verdana'; font-size:11px; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Diagnostics: public Ui_Diagnostics {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIAGNOSTICS_H
