/********************************************************************************
** Form generated from reading UI file 'otppage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OTPPAGE_H
#define UI_OTPPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>
#include "yubiaccbox.h"

QT_BEGIN_NAMESPACE

class Ui_OtpPage
{
public:
    QWidget *basePage;
    QLabel *baseHeadingLbl;
    QGroupBox *baseActionsBox;
    QPushButton *quickBtn;
    QPushButton *advBtn;
    QLabel *quickDescLbl;
    QLabel *advancedDescLbl;
    QWidget *quickPage;
    QLabel *quickHeadingLbl;
    QGroupBox *quickConfigBox;
    QLabel *quickConfigDescLbl;
    QRadioButton *quickConfigSlot1Radio;
    QRadioButton *quickConfigSlot2Radio;
    QPushButton *quickConfigHelpBtn;
    QGroupBox *quickKeyParamsBox;
    QPushButton *quickPubIdHelpBtn;
    QPushButton *quickPvtIdHelpBtn;
    QPushButton *quickSecretKeyHelpBtn;
    QLineEdit *quickPubIdTxt;
    QLineEdit *quickPvtIdTxt;
    QLineEdit *quickSecretKeyTxt;
    QCheckBox *quickHideParams;
    QLabel *quickPubIdLbl;
    QLabel *quickPvtIdLbl;
    QLabel *quickSecretKeyLbl;
    QGroupBox *quickActionsBox;
    QPushButton *quickWriteConfigBtn;
    QPushButton *quickBackBtn;
    QPushButton *quickUploadBtn;
    QLabel *quickActionsDescLbl;
    QPushButton *quickResetBtn;
    QWidget *advPage;
    QLabel *advHeadingLbl;
    QGroupBox *advConfigBox;
    QLabel *advConfigDescLbl;
    QRadioButton *advConfigSlot1Radio;
    QRadioButton *advConfigSlot2Radio;
    QPushButton *advConfigHelpBtn;
    QGroupBox *advKeyParamsBox;
    QPushButton *advSecretKeyHelpBtn;
    QLineEdit *advSecretKeyTxt;
    QPushButton *advSecretKeyGenerateBtn;
    QLineEdit *advPubIdTxt;
    QLineEdit *advPvtIdTxt;
    QPushButton *advPubIdGenerateBtn;
    QPushButton *advPvtIdGenerateBtn;
    QPushButton *advPubIdHelpBtn;
    QPushButton *advPvtIdHelpBtn;
    QCheckBox *advPubIdCheck;
    QCheckBox *advPvtIdCheck;
    QLabel *advPubIdLenLbl;
    QLabel *advSecretKeyLbl;
    QSpinBox *advPubIdLenBox;
    QLabel *advStaticLenDescLbl;
    QGroupBox *advActionsBox;
    QPushButton *advWriteConfigBtn;
    QPushButton *advStopBtn;
    QLabel *advActionsDescLbl;
    QPushButton *advBackBtn;
    QPushButton *advResetBtn;
    QPushButton *advExportConfigBtn;
    QGroupBox *advProgramMulKeysBox;
    QCheckBox *advAutoProgramKeysCheck;
    QLabel *advParamGenSchemeLbl;
    QComboBox *advConfigParamsCombo;
    QPushButton *advParamGenSchemeHelpBtn;
    QGroupBox *advResultsBox;
    QTableWidget *advResultsWidget;
    YubiAccBox *advConfigProtectionBox;

    void setupUi(QStackedWidget *OtpPage)
    {
        if (OtpPage->objectName().isEmpty())
            OtpPage->setObjectName(QString::fromUtf8("OtpPage"));
        OtpPage->resize(730, 650);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(OtpPage->sizePolicy().hasHeightForWidth());
        OtpPage->setSizePolicy(sizePolicy);
        OtpPage->setMaximumSize(QSize(730, 650));
        OtpPage->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        basePage = new QWidget();
        basePage->setObjectName(QString::fromUtf8("basePage"));
        baseHeadingLbl = new QLabel(basePage);
        baseHeadingLbl->setObjectName(QString::fromUtf8("baseHeadingLbl"));
        baseHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        baseHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        baseHeadingLbl->setAlignment(Qt::AlignCenter);
        baseActionsBox = new QGroupBox(basePage);
        baseActionsBox->setObjectName(QString::fromUtf8("baseActionsBox"));
        baseActionsBox->setGeometry(QRect(10, 50, 710, 171));
        baseActionsBox->setStyleSheet(QString::fromUtf8("border-color: rgb(0, 0, 0);"));
        baseActionsBox->setAlignment(Qt::AlignCenter);
        quickBtn = new QPushButton(baseActionsBox);
        quickBtn->setObjectName(QString::fromUtf8("quickBtn"));
        quickBtn->setGeometry(QRect(20, 20, 110, 25));
        sizePolicy.setHeightForWidth(quickBtn->sizePolicy().hasHeightForWidth());
        quickBtn->setSizePolicy(sizePolicy);
        quickBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickBtn->setAutoExclusive(false);
        quickBtn->setFlat(false);
        advBtn = new QPushButton(baseActionsBox);
        advBtn->setObjectName(QString::fromUtf8("advBtn"));
        advBtn->setGeometry(QRect(20, 100, 110, 25));
        advBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advBtn->setCheckable(false);
        advBtn->setChecked(false);
        quickDescLbl = new QLabel(baseActionsBox);
        quickDescLbl->setObjectName(QString::fromUtf8("quickDescLbl"));
        quickDescLbl->setGeometry(QRect(20, 45, 671, 20));
        quickDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        advancedDescLbl = new QLabel(baseActionsBox);
        advancedDescLbl->setObjectName(QString::fromUtf8("advancedDescLbl"));
        advancedDescLbl->setGeometry(QRect(20, 125, 671, 30));
        advancedDescLbl->setStyleSheet(QString::fromUtf8(""));
        advancedDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        OtpPage->addWidget(basePage);
        quickPage = new QWidget();
        quickPage->setObjectName(QString::fromUtf8("quickPage"));
        quickHeadingLbl = new QLabel(quickPage);
        quickHeadingLbl->setObjectName(QString::fromUtf8("quickHeadingLbl"));
        quickHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        quickHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        quickHeadingLbl->setAlignment(Qt::AlignCenter);
        quickConfigBox = new QGroupBox(quickPage);
        quickConfigBox->setObjectName(QString::fromUtf8("quickConfigBox"));
        quickConfigBox->setGeometry(QRect(10, 50, 711, 72));
        quickConfigBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickConfigDescLbl = new QLabel(quickConfigBox);
        quickConfigDescLbl->setObjectName(QString::fromUtf8("quickConfigDescLbl"));
        quickConfigDescLbl->setGeometry(QRect(10, 25, 691, 16));
        quickConfigDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)"));
        quickConfigSlot1Radio = new QRadioButton(quickConfigBox);
        quickConfigSlot1Radio->setObjectName(QString::fromUtf8("quickConfigSlot1Radio"));
        quickConfigSlot1Radio->setGeometry(QRect(10, 45, 151, 19));
        quickConfigSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickConfigSlot2Radio = new QRadioButton(quickConfigBox);
        quickConfigSlot2Radio->setObjectName(QString::fromUtf8("quickConfigSlot2Radio"));
        quickConfigSlot2Radio->setGeometry(QRect(240, 45, 151, 19));
        quickConfigSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickConfigHelpBtn = new QPushButton(quickConfigBox);
        quickConfigHelpBtn->setObjectName(QString::fromUtf8("quickConfigHelpBtn"));
        quickConfigHelpBtn->setGeometry(QRect(685, 45, 16, 16));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(quickConfigHelpBtn->sizePolicy().hasHeightForWidth());
        quickConfigHelpBtn->setSizePolicy(sizePolicy1);
        quickConfigHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickConfigHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickConfigHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickConfigHelpBtn->setAutoFillBackground(false);
        quickConfigHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickConfigHelpBtn->setAutoDefault(false);
        quickKeyParamsBox = new QGroupBox(quickPage);
        quickKeyParamsBox->setObjectName(QString::fromUtf8("quickKeyParamsBox"));
        quickKeyParamsBox->setGeometry(QRect(10, 132, 711, 130));
        quickKeyParamsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickKeyParamsBox->setCheckable(false);
        quickKeyParamsBox->setChecked(false);
        quickPubIdHelpBtn = new QPushButton(quickKeyParamsBox);
        quickPubIdHelpBtn->setObjectName(QString::fromUtf8("quickPubIdHelpBtn"));
        quickPubIdHelpBtn->setGeometry(QRect(685, 27, 16, 16));
        sizePolicy1.setHeightForWidth(quickPubIdHelpBtn->sizePolicy().hasHeightForWidth());
        quickPubIdHelpBtn->setSizePolicy(sizePolicy1);
        quickPubIdHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickPubIdHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickPubIdHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickPubIdHelpBtn->setAutoFillBackground(false);
        quickPubIdHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickPubIdHelpBtn->setAutoDefault(false);
        quickPvtIdHelpBtn = new QPushButton(quickKeyParamsBox);
        quickPvtIdHelpBtn->setObjectName(QString::fromUtf8("quickPvtIdHelpBtn"));
        quickPvtIdHelpBtn->setGeometry(QRect(685, 77, 16, 16));
        sizePolicy1.setHeightForWidth(quickPvtIdHelpBtn->sizePolicy().hasHeightForWidth());
        quickPvtIdHelpBtn->setSizePolicy(sizePolicy1);
        quickPvtIdHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickPvtIdHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickPvtIdHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickPvtIdHelpBtn->setAutoFillBackground(false);
        quickPvtIdHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickPvtIdHelpBtn->setAutoDefault(false);
        quickSecretKeyHelpBtn = new QPushButton(quickKeyParamsBox);
        quickSecretKeyHelpBtn->setObjectName(QString::fromUtf8("quickSecretKeyHelpBtn"));
        quickSecretKeyHelpBtn->setGeometry(QRect(685, 102, 16, 16));
        sizePolicy1.setHeightForWidth(quickSecretKeyHelpBtn->sizePolicy().hasHeightForWidth());
        quickSecretKeyHelpBtn->setSizePolicy(sizePolicy1);
        quickSecretKeyHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickSecretKeyHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickSecretKeyHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickSecretKeyHelpBtn->setAutoFillBackground(false);
        quickSecretKeyHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickSecretKeyHelpBtn->setAutoDefault(false);
        quickPubIdTxt = new QLineEdit(quickKeyParamsBox);
        quickPubIdTxt->setObjectName(QString::fromUtf8("quickPubIdTxt"));
        quickPubIdTxt->setEnabled(true);
        quickPubIdTxt->setGeometry(QRect(240, 25, 341, 20));
        sizePolicy.setHeightForWidth(quickPubIdTxt->sizePolicy().hasHeightForWidth());
        quickPubIdTxt->setSizePolicy(sizePolicy);
        quickPubIdTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickPubIdTxt->setEchoMode(QLineEdit::Normal);
        quickPubIdTxt->setReadOnly(true);
        quickPvtIdTxt = new QLineEdit(quickKeyParamsBox);
        quickPvtIdTxt->setObjectName(QString::fromUtf8("quickPvtIdTxt"));
        quickPvtIdTxt->setEnabled(true);
        quickPvtIdTxt->setGeometry(QRect(240, 75, 341, 20));
        quickPvtIdTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickPvtIdTxt->setEchoMode(QLineEdit::Password);
        quickPvtIdTxt->setCursorPosition(17);
        quickPvtIdTxt->setReadOnly(true);
        quickSecretKeyTxt = new QLineEdit(quickKeyParamsBox);
        quickSecretKeyTxt->setObjectName(QString::fromUtf8("quickSecretKeyTxt"));
        quickSecretKeyTxt->setEnabled(true);
        quickSecretKeyTxt->setGeometry(QRect(240, 100, 341, 20));
        quickSecretKeyTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickSecretKeyTxt->setEchoMode(QLineEdit::Password);
        quickSecretKeyTxt->setCursorPosition(47);
        quickSecretKeyTxt->setReadOnly(true);
        quickHideParams = new QCheckBox(quickKeyParamsBox);
        quickHideParams->setObjectName(QString::fromUtf8("quickHideParams"));
        quickHideParams->setGeometry(QRect(10, 50, 221, 18));
        quickHideParams->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickHideParams->setChecked(true);
        quickPubIdLbl = new QLabel(quickKeyParamsBox);
        quickPubIdLbl->setObjectName(QString::fromUtf8("quickPubIdLbl"));
        quickPubIdLbl->setGeometry(QRect(10, 25, 221, 20));
        quickPubIdLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickPvtIdLbl = new QLabel(quickKeyParamsBox);
        quickPvtIdLbl->setObjectName(QString::fromUtf8("quickPvtIdLbl"));
        quickPvtIdLbl->setGeometry(QRect(10, 75, 221, 20));
        quickPvtIdLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickSecretKeyLbl = new QLabel(quickKeyParamsBox);
        quickSecretKeyLbl->setObjectName(QString::fromUtf8("quickSecretKeyLbl"));
        quickSecretKeyLbl->setGeometry(QRect(10, 100, 221, 20));
        quickSecretKeyLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickActionsBox = new QGroupBox(quickPage);
        quickActionsBox->setObjectName(QString::fromUtf8("quickActionsBox"));
        quickActionsBox->setGeometry(QRect(10, 272, 711, 80));
        quickActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickWriteConfigBtn = new QPushButton(quickActionsBox);
        quickWriteConfigBtn->setObjectName(QString::fromUtf8("quickWriteConfigBtn"));
        quickWriteConfigBtn->setGeometry(QRect(10, 45, 175, 25));
        quickWriteConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickWriteConfigBtn->setAutoExclusive(false);
        quickWriteConfigBtn->setFlat(false);
        quickBackBtn = new QPushButton(quickActionsBox);
        quickBackBtn->setObjectName(QString::fromUtf8("quickBackBtn"));
        quickBackBtn->setGeometry(QRect(505, 45, 85, 25));
        quickBackBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickBackBtn->setAutoExclusive(false);
        quickBackBtn->setFlat(false);
        quickUploadBtn = new QPushButton(quickActionsBox);
        quickUploadBtn->setObjectName(QString::fromUtf8("quickUploadBtn"));
        quickUploadBtn->setEnabled(false);
        quickUploadBtn->setGeometry(QRect(200, 45, 155, 25));
        quickUploadBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickUploadBtn->setAutoExclusive(false);
        quickUploadBtn->setFlat(false);
        quickActionsDescLbl = new QLabel(quickActionsBox);
        quickActionsDescLbl->setObjectName(QString::fromUtf8("quickActionsDescLbl"));
        quickActionsDescLbl->setGeometry(QRect(10, 25, 691, 16));
        quickActionsDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        quickResetBtn = new QPushButton(quickActionsBox);
        quickResetBtn->setObjectName(QString::fromUtf8("quickResetBtn"));
        quickResetBtn->setEnabled(true);
        quickResetBtn->setGeometry(QRect(370, 45, 120, 25));
        quickResetBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickResetBtn->setAutoExclusive(false);
        quickResetBtn->setFlat(false);
        OtpPage->addWidget(quickPage);
        advPage = new QWidget();
        advPage->setObjectName(QString::fromUtf8("advPage"));
        advHeadingLbl = new QLabel(advPage);
        advHeadingLbl->setObjectName(QString::fromUtf8("advHeadingLbl"));
        advHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        advHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        advHeadingLbl->setAlignment(Qt::AlignCenter);
        advConfigBox = new QGroupBox(advPage);
        advConfigBox->setObjectName(QString::fromUtf8("advConfigBox"));
        advConfigBox->setGeometry(QRect(10, 50, 711, 72));
        advConfigBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advConfigDescLbl = new QLabel(advConfigBox);
        advConfigDescLbl->setObjectName(QString::fromUtf8("advConfigDescLbl"));
        advConfigDescLbl->setGeometry(QRect(10, 25, 691, 16));
        advConfigDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        advConfigSlot1Radio = new QRadioButton(advConfigBox);
        advConfigSlot1Radio->setObjectName(QString::fromUtf8("advConfigSlot1Radio"));
        advConfigSlot1Radio->setGeometry(QRect(10, 45, 151, 19));
        advConfigSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advConfigSlot1Radio->setCheckable(true);
        advConfigSlot1Radio->setChecked(false);
        advConfigSlot2Radio = new QRadioButton(advConfigBox);
        advConfigSlot2Radio->setObjectName(QString::fromUtf8("advConfigSlot2Radio"));
        advConfigSlot2Radio->setGeometry(QRect(240, 45, 151, 19));
        advConfigSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advConfigHelpBtn = new QPushButton(advConfigBox);
        advConfigHelpBtn->setObjectName(QString::fromUtf8("advConfigHelpBtn"));
        advConfigHelpBtn->setGeometry(QRect(685, 45, 16, 16));
        sizePolicy1.setHeightForWidth(advConfigHelpBtn->sizePolicy().hasHeightForWidth());
        advConfigHelpBtn->setSizePolicy(sizePolicy1);
        advConfigHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advConfigHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advConfigHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advConfigHelpBtn->setAutoFillBackground(false);
        advConfigHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advConfigHelpBtn->setAutoDefault(false);
        advKeyParamsBox = new QGroupBox(advPage);
        advKeyParamsBox->setObjectName(QString::fromUtf8("advKeyParamsBox"));
        advKeyParamsBox->setGeometry(QRect(10, 249, 711, 132));
        advKeyParamsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advSecretKeyHelpBtn = new QPushButton(advKeyParamsBox);
        advSecretKeyHelpBtn->setObjectName(QString::fromUtf8("advSecretKeyHelpBtn"));
        advSecretKeyHelpBtn->setGeometry(QRect(685, 102, 16, 16));
        sizePolicy1.setHeightForWidth(advSecretKeyHelpBtn->sizePolicy().hasHeightForWidth());
        advSecretKeyHelpBtn->setSizePolicy(sizePolicy1);
        advSecretKeyHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advSecretKeyHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advSecretKeyHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advSecretKeyHelpBtn->setAutoFillBackground(false);
        advSecretKeyHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advSecretKeyHelpBtn->setAutoDefault(false);
        advSecretKeyTxt = new QLineEdit(advKeyParamsBox);
        advSecretKeyTxt->setObjectName(QString::fromUtf8("advSecretKeyTxt"));
        advSecretKeyTxt->setGeometry(QRect(240, 100, 330, 20));
        sizePolicy.setHeightForWidth(advSecretKeyTxt->sizePolicy().hasHeightForWidth());
        advSecretKeyTxt->setSizePolicy(sizePolicy);
        advSecretKeyTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advSecretKeyTxt->setMaxLength(47);
        advSecretKeyTxt->setCursorPosition(47);
        advSecretKeyGenerateBtn = new QPushButton(advKeyParamsBox);
        advSecretKeyGenerateBtn->setObjectName(QString::fromUtf8("advSecretKeyGenerateBtn"));
        advSecretKeyGenerateBtn->setGeometry(QRect(580, 98, 100, 24));
        advSecretKeyGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advSecretKeyGenerateBtn->setAutoExclusive(false);
        advSecretKeyGenerateBtn->setFlat(false);
        advPubIdTxt = new QLineEdit(advKeyParamsBox);
        advPubIdTxt->setObjectName(QString::fromUtf8("advPubIdTxt"));
        advPubIdTxt->setGeometry(QRect(239, 25, 331, 20));
        sizePolicy.setHeightForWidth(advPubIdTxt->sizePolicy().hasHeightForWidth());
        advPubIdTxt->setSizePolicy(sizePolicy);
        advPubIdTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advPubIdTxt->setMaxLength(47);
        advPubIdTxt->setCursorPosition(47);
        advPvtIdTxt = new QLineEdit(advKeyParamsBox);
        advPvtIdTxt->setObjectName(QString::fromUtf8("advPvtIdTxt"));
        advPvtIdTxt->setGeometry(QRect(240, 75, 330, 20));
        sizePolicy.setHeightForWidth(advPvtIdTxt->sizePolicy().hasHeightForWidth());
        advPvtIdTxt->setSizePolicy(sizePolicy);
        advPvtIdTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advPvtIdTxt->setMaxLength(17);
        advPvtIdTxt->setCursorPosition(17);
        advPubIdGenerateBtn = new QPushButton(advKeyParamsBox);
        advPubIdGenerateBtn->setObjectName(QString::fromUtf8("advPubIdGenerateBtn"));
        advPubIdGenerateBtn->setGeometry(QRect(580, 23, 100, 24));
        advPubIdGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advPubIdGenerateBtn->setAutoExclusive(false);
        advPubIdGenerateBtn->setFlat(false);
        advPvtIdGenerateBtn = new QPushButton(advKeyParamsBox);
        advPvtIdGenerateBtn->setObjectName(QString::fromUtf8("advPvtIdGenerateBtn"));
        advPvtIdGenerateBtn->setGeometry(QRect(580, 73, 100, 24));
        advPvtIdGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advPvtIdGenerateBtn->setAutoExclusive(false);
        advPvtIdGenerateBtn->setFlat(false);
        advPubIdHelpBtn = new QPushButton(advKeyParamsBox);
        advPubIdHelpBtn->setObjectName(QString::fromUtf8("advPubIdHelpBtn"));
        advPubIdHelpBtn->setGeometry(QRect(685, 27, 16, 16));
        sizePolicy1.setHeightForWidth(advPubIdHelpBtn->sizePolicy().hasHeightForWidth());
        advPubIdHelpBtn->setSizePolicy(sizePolicy1);
        advPubIdHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advPubIdHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advPubIdHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advPubIdHelpBtn->setAutoFillBackground(false);
        advPubIdHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advPubIdHelpBtn->setAutoDefault(false);
        advPvtIdHelpBtn = new QPushButton(advKeyParamsBox);
        advPvtIdHelpBtn->setObjectName(QString::fromUtf8("advPvtIdHelpBtn"));
        advPvtIdHelpBtn->setGeometry(QRect(685, 77, 16, 16));
        sizePolicy1.setHeightForWidth(advPvtIdHelpBtn->sizePolicy().hasHeightForWidth());
        advPvtIdHelpBtn->setSizePolicy(sizePolicy1);
        advPvtIdHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advPvtIdHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advPvtIdHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advPvtIdHelpBtn->setAutoFillBackground(false);
        advPvtIdHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advPvtIdHelpBtn->setAutoDefault(false);
        advPubIdCheck = new QCheckBox(advKeyParamsBox);
        advPubIdCheck->setObjectName(QString::fromUtf8("advPubIdCheck"));
        advPubIdCheck->setGeometry(QRect(10, 25, 225, 17));
        advPubIdCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advPvtIdCheck = new QCheckBox(advKeyParamsBox);
        advPvtIdCheck->setObjectName(QString::fromUtf8("advPvtIdCheck"));
        advPvtIdCheck->setGeometry(QRect(10, 75, 221, 17));
        advPvtIdCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advPubIdLenLbl = new QLabel(advKeyParamsBox);
        advPubIdLenLbl->setObjectName(QString::fromUtf8("advPubIdLenLbl"));
        advPubIdLenLbl->setGeometry(QRect(10, 50, 221, 20));
        advPubIdLenLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advSecretKeyLbl = new QLabel(advKeyParamsBox);
        advSecretKeyLbl->setObjectName(QString::fromUtf8("advSecretKeyLbl"));
        advSecretKeyLbl->setGeometry(QRect(10, 100, 221, 20));
        advSecretKeyLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advPubIdLenBox = new QSpinBox(advKeyParamsBox);
        advPubIdLenBox->setObjectName(QString::fromUtf8("advPubIdLenBox"));
        advPubIdLenBox->setGeometry(QRect(240, 50, 42, 20));
        advPubIdLenBox->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advPubIdLenBox->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        advPubIdLenBox->setCorrectionMode(QAbstractSpinBox::CorrectToNearestValue);
        advPubIdLenBox->setMinimum(1);
        advPubIdLenBox->setMaximum(16);
        advPubIdLenBox->setSingleStep(1);
        advPubIdLenBox->setValue(6);
        advStaticLenDescLbl = new QLabel(advKeyParamsBox);
        advStaticLenDescLbl->setObjectName(QString::fromUtf8("advStaticLenDescLbl"));
        advStaticLenDescLbl->setGeometry(QRect(290, 50, 411, 20));
        advStaticLenDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)"));
        advActionsBox = new QGroupBox(advPage);
        advActionsBox->setObjectName(QString::fromUtf8("advActionsBox"));
        advActionsBox->setGeometry(QRect(10, 391, 711, 80));
        advActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        advWriteConfigBtn = new QPushButton(advActionsBox);
        advWriteConfigBtn->setObjectName(QString::fromUtf8("advWriteConfigBtn"));
        advWriteConfigBtn->setGeometry(QRect(10, 45, 175, 25));
        advWriteConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advWriteConfigBtn->setAutoExclusive(false);
        advWriteConfigBtn->setFlat(false);
        advStopBtn = new QPushButton(advActionsBox);
        advStopBtn->setObjectName(QString::fromUtf8("advStopBtn"));
        advStopBtn->setEnabled(false);
        advStopBtn->setGeometry(QRect(200, 45, 85, 25));
        advStopBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advStopBtn->setAutoExclusive(false);
        advStopBtn->setFlat(false);
        advActionsDescLbl = new QLabel(advActionsBox);
        advActionsDescLbl->setObjectName(QString::fromUtf8("advActionsDescLbl"));
        advActionsDescLbl->setGeometry(QRect(20, 20, 691, 16));
        advActionsDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        advBackBtn = new QPushButton(advActionsBox);
        advBackBtn->setObjectName(QString::fromUtf8("advBackBtn"));
        advBackBtn->setGeometry(QRect(400, 45, 85, 25));
        advBackBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advBackBtn->setAutoExclusive(false);
        advBackBtn->setFlat(false);
        advResetBtn = new QPushButton(advActionsBox);
        advResetBtn->setObjectName(QString::fromUtf8("advResetBtn"));
        advResetBtn->setEnabled(true);
        advResetBtn->setGeometry(QRect(300, 45, 85, 25));
        advResetBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advResetBtn->setAutoExclusive(false);
        advResetBtn->setFlat(false);
        advExportConfigBtn = new QPushButton(advActionsBox);
        advExportConfigBtn->setObjectName(QString::fromUtf8("advExportConfigBtn"));
        advExportConfigBtn->setGeometry(QRect(580, 45, 100, 25));
        advExportConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advExportConfigBtn->setAutoExclusive(false);
        advExportConfigBtn->setFlat(false);
        advProgramMulKeysBox = new QGroupBox(advPage);
        advProgramMulKeysBox->setObjectName(QString::fromUtf8("advProgramMulKeysBox"));
        advProgramMulKeysBox->setGeometry(QRect(10, 132, 350, 107));
        advProgramMulKeysBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advProgramMulKeysBox->setCheckable(true);
        advProgramMulKeysBox->setChecked(false);
        advAutoProgramKeysCheck = new QCheckBox(advProgramMulKeysBox);
        advAutoProgramKeysCheck->setObjectName(QString::fromUtf8("advAutoProgramKeysCheck"));
        advAutoProgramKeysCheck->setGeometry(QRect(10, 25, 331, 17));
        advAutoProgramKeysCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advParamGenSchemeLbl = new QLabel(advProgramMulKeysBox);
        advParamGenSchemeLbl->setObjectName(QString::fromUtf8("advParamGenSchemeLbl"));
        advParamGenSchemeLbl->setGeometry(QRect(10, 52, 191, 20));
        advParamGenSchemeLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advParamGenSchemeLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        advConfigParamsCombo = new QComboBox(advProgramMulKeysBox);
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->setObjectName(QString::fromUtf8("advConfigParamsCombo"));
        advConfigParamsCombo->setGeometry(QRect(10, 75, 331, 22));
        sizePolicy.setHeightForWidth(advConfigParamsCombo->sizePolicy().hasHeightForWidth());
        advConfigParamsCombo->setSizePolicy(sizePolicy);
        advConfigParamsCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advParamGenSchemeHelpBtn = new QPushButton(advProgramMulKeysBox);
        advParamGenSchemeHelpBtn->setObjectName(QString::fromUtf8("advParamGenSchemeHelpBtn"));
        advParamGenSchemeHelpBtn->setGeometry(QRect(325, 52, 16, 16));
        sizePolicy1.setHeightForWidth(advParamGenSchemeHelpBtn->sizePolicy().hasHeightForWidth());
        advParamGenSchemeHelpBtn->setSizePolicy(sizePolicy1);
        advParamGenSchemeHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advParamGenSchemeHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advParamGenSchemeHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advParamGenSchemeHelpBtn->setAutoFillBackground(false);
        advParamGenSchemeHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advParamGenSchemeHelpBtn->setAutoDefault(false);
        advResultsBox = new QGroupBox(advPage);
        advResultsBox->setObjectName(QString::fromUtf8("advResultsBox"));
        advResultsBox->setGeometry(QRect(10, 481, 711, 130));
        advResultsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        advResultsWidget = new QTableWidget(advResultsBox);
        if (advResultsWidget->columnCount() < 4)
            advResultsWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        advResultsWidget->setObjectName(QString::fromUtf8("advResultsWidget"));
        advResultsWidget->setGeometry(QRect(12, 20, 688, 100));
        advResultsWidget->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        advResultsWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        advResultsWidget->setAlternatingRowColors(true);
        advResultsWidget->setShowGrid(false);
        advResultsWidget->setGridStyle(Qt::SolidLine);
        advResultsWidget->setWordWrap(true);
        advResultsWidget->setRowCount(0);
        advResultsWidget->setColumnCount(4);
        advResultsWidget->horizontalHeader()->setMinimumSectionSize(50);
        advResultsWidget->verticalHeader()->setVisible(false);
        advResultsWidget->verticalHeader()->setDefaultSectionSize(20);
        advConfigProtectionBox = new YubiAccBox(advPage);
        advConfigProtectionBox->setObjectName(QString::fromUtf8("advConfigProtectionBox"));
        advConfigProtectionBox->setGeometry(QRect(370, 132, 350, 117));
        OtpPage->addWidget(advPage);
        QWidget::setTabOrder(quickBtn, advBtn);
        QWidget::setTabOrder(advBtn, quickConfigSlot1Radio);
        QWidget::setTabOrder(quickConfigSlot1Radio, quickConfigSlot2Radio);
        QWidget::setTabOrder(quickConfigSlot2Radio, quickPubIdTxt);
        QWidget::setTabOrder(quickPubIdTxt, quickHideParams);
        QWidget::setTabOrder(quickHideParams, quickPvtIdTxt);
        QWidget::setTabOrder(quickPvtIdTxt, quickSecretKeyTxt);
        QWidget::setTabOrder(quickSecretKeyTxt, quickWriteConfigBtn);
        QWidget::setTabOrder(quickWriteConfigBtn, quickUploadBtn);
        QWidget::setTabOrder(quickUploadBtn, quickResetBtn);
        QWidget::setTabOrder(quickResetBtn, quickBackBtn);
        QWidget::setTabOrder(quickBackBtn, quickConfigHelpBtn);
        QWidget::setTabOrder(quickConfigHelpBtn, quickPubIdHelpBtn);
        QWidget::setTabOrder(quickPubIdHelpBtn, quickPvtIdHelpBtn);
        QWidget::setTabOrder(quickPvtIdHelpBtn, quickSecretKeyHelpBtn);
        QWidget::setTabOrder(quickSecretKeyHelpBtn, advConfigSlot1Radio);
        QWidget::setTabOrder(advConfigSlot1Radio, advConfigSlot2Radio);
        QWidget::setTabOrder(advConfigSlot2Radio, advProgramMulKeysBox);
        QWidget::setTabOrder(advProgramMulKeysBox, advAutoProgramKeysCheck);
        QWidget::setTabOrder(advAutoProgramKeysCheck, advConfigParamsCombo);
        QWidget::setTabOrder(advConfigParamsCombo, advPubIdCheck);
        QWidget::setTabOrder(advPubIdCheck, advPubIdTxt);
        QWidget::setTabOrder(advPubIdTxt, advPubIdGenerateBtn);
        QWidget::setTabOrder(advPubIdGenerateBtn, advPubIdLenBox);
        QWidget::setTabOrder(advPubIdLenBox, advPvtIdCheck);
        QWidget::setTabOrder(advPvtIdCheck, advPvtIdTxt);
        QWidget::setTabOrder(advPvtIdTxt, advPvtIdGenerateBtn);
        QWidget::setTabOrder(advPvtIdGenerateBtn, advSecretKeyTxt);
        QWidget::setTabOrder(advSecretKeyTxt, advSecretKeyGenerateBtn);
        QWidget::setTabOrder(advSecretKeyGenerateBtn, advWriteConfigBtn);
        QWidget::setTabOrder(advWriteConfigBtn, advStopBtn);
        QWidget::setTabOrder(advStopBtn, advResetBtn);
        QWidget::setTabOrder(advResetBtn, advBackBtn);
        QWidget::setTabOrder(advBackBtn, advResultsWidget);
        QWidget::setTabOrder(advResultsWidget, advConfigHelpBtn);
        QWidget::setTabOrder(advConfigHelpBtn, advPubIdHelpBtn);
        QWidget::setTabOrder(advPubIdHelpBtn, advPvtIdHelpBtn);
        QWidget::setTabOrder(advPvtIdHelpBtn, advSecretKeyHelpBtn);
        QWidget::setTabOrder(advSecretKeyHelpBtn, advParamGenSchemeHelpBtn);

        retranslateUi(OtpPage);

        OtpPage->setCurrentIndex(2);
        quickBtn->setDefault(false);
        advBtn->setDefault(false);
        quickConfigHelpBtn->setDefault(false);
        quickPubIdHelpBtn->setDefault(false);
        quickPvtIdHelpBtn->setDefault(false);
        quickSecretKeyHelpBtn->setDefault(false);
        quickWriteConfigBtn->setDefault(false);
        quickBackBtn->setDefault(false);
        quickUploadBtn->setDefault(false);
        quickResetBtn->setDefault(false);
        advConfigHelpBtn->setDefault(false);
        advSecretKeyHelpBtn->setDefault(false);
        advSecretKeyGenerateBtn->setDefault(false);
        advPubIdGenerateBtn->setDefault(false);
        advPvtIdGenerateBtn->setDefault(false);
        advPubIdHelpBtn->setDefault(false);
        advPvtIdHelpBtn->setDefault(false);
        advWriteConfigBtn->setDefault(false);
        advStopBtn->setDefault(false);
        advBackBtn->setDefault(false);
        advResetBtn->setDefault(false);
        advExportConfigBtn->setDefault(false);
        advParamGenSchemeHelpBtn->setDefault(false);


        QMetaObject::connectSlotsByName(OtpPage);
    } // setupUi

    void retranslateUi(QStackedWidget *OtpPage)
    {
        OtpPage->setWindowTitle(QApplication::translate("OtpPage", "StackedWidget", nullptr));
        baseHeadingLbl->setText(QApplication::translate("OtpPage", "Program in Yubico OTP mode", nullptr));
        baseActionsBox->setTitle(QString());
        quickBtn->setText(QApplication::translate("OtpPage", "Quick", nullptr));
        advBtn->setText(QApplication::translate("OtpPage", "Advanced", nullptr));
        quickDescLbl->setText(QApplication::translate("OtpPage", "Quickly program a YubiKey for use with Yubico Validation Server", nullptr));
        advancedDescLbl->setText(QApplication::translate("OtpPage", "Allows you to program one or more YubiKeys with greater control over the configuration values", nullptr));
        quickHeadingLbl->setText(QApplication::translate("OtpPage", "Program in Yubico OTP mode - Quick", nullptr));
        quickConfigBox->setTitle(QApplication::translate("OtpPage", "Configuration Slot", nullptr));
        quickConfigDescLbl->setText(QApplication::translate("OtpPage", "Select the configuration slot to be programmed", nullptr));
        quickConfigSlot1Radio->setText(QApplication::translate("OtpPage", "Configuration Slot 1", nullptr));
        quickConfigSlot2Radio->setText(QApplication::translate("OtpPage", "Configuration Slot 2", nullptr));
        quickConfigHelpBtn->setText(QString());
        quickKeyParamsBox->setTitle(QApplication::translate("OtpPage", "Yubico OTP Parameters (auto generated)", nullptr));
        quickPubIdHelpBtn->setText(QString());
        quickPvtIdHelpBtn->setText(QString());
        quickSecretKeyHelpBtn->setText(QString());
        quickPubIdTxt->setInputMask(QApplication::translate("OtpPage", "nn nn nn nn nn nn; ", nullptr));
        quickPvtIdTxt->setInputMask(QApplication::translate("OtpPage", "hh hh hh hh hh hh; ", nullptr));
        quickPvtIdTxt->setText(QString());
        quickSecretKeyTxt->setInputMask(QApplication::translate("OtpPage", "hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh; ", nullptr));
        quickSecretKeyTxt->setText(QString());
        quickHideParams->setText(QApplication::translate("OtpPage", "Hide values", nullptr));
        quickPubIdLbl->setText(QApplication::translate("OtpPage", "Public Identity (6 bytes Modhex)", nullptr));
        quickPvtIdLbl->setText(QApplication::translate("OtpPage", "Private Identity (6 bytes Hex)", nullptr));
        quickSecretKeyLbl->setText(QApplication::translate("OtpPage", "Secret Key (16 bytes Hex)", nullptr));
        quickActionsBox->setTitle(QApplication::translate("OtpPage", "Actions", nullptr));
        quickWriteConfigBtn->setText(QApplication::translate("OtpPage", "Write Configuration", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickBackBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickBackBtn->setText(QApplication::translate("OtpPage", "Back", nullptr));
        quickUploadBtn->setText(QApplication::translate("OtpPage", "Upload to Yubico", nullptr));
        quickActionsDescLbl->setText(QApplication::translate("OtpPage", "Press Write Configuration button to program your YubiKey's selected configuration slot", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickResetBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickResetBtn->setText(QApplication::translate("OtpPage", "Regenerate", nullptr));
        advHeadingLbl->setText(QApplication::translate("OtpPage", "Program in Yubico OTP mode - Advanced", nullptr));
        advConfigBox->setTitle(QApplication::translate("OtpPage", "Configuration Slot", nullptr));
        advConfigDescLbl->setText(QApplication::translate("OtpPage", "Select the configuration slot to be programmed", nullptr));
        advConfigSlot1Radio->setText(QApplication::translate("OtpPage", "Configuration Slot 1", nullptr));
        advConfigSlot2Radio->setText(QApplication::translate("OtpPage", "Configuration Slot 2", nullptr));
        advConfigHelpBtn->setText(QString());
        advKeyParamsBox->setTitle(QApplication::translate("OtpPage", "Yubico OTP Parameters", nullptr));
        advSecretKeyHelpBtn->setText(QString());
        advSecretKeyTxt->setInputMask(QApplication::translate("OtpPage", "hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh; ", nullptr));
        advSecretKeyTxt->setText(QApplication::translate("OtpPage", "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00", nullptr));
#ifndef QT_NO_WHATSTHIS
        advSecretKeyGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advSecretKeyGenerateBtn->setText(QApplication::translate("OtpPage", "Generate", nullptr));
        advPubIdTxt->setInputMask(QApplication::translate("OtpPage", "nn nn nn nn nn nn nn nn nn nn nn nn nn nn nn nn; ", nullptr));
        advPubIdTxt->setText(QApplication::translate("OtpPage", "00 00 00 00 00 00          ", nullptr));
        advPvtIdTxt->setInputMask(QApplication::translate("OtpPage", "hh hh hh hh hh hh; ", nullptr));
        advPvtIdTxt->setText(QApplication::translate("OtpPage", "00 00 00 00 00 00", nullptr));
#ifndef QT_NO_WHATSTHIS
        advPubIdGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advPubIdGenerateBtn->setText(QApplication::translate("OtpPage", "Generate", nullptr));
#ifndef QT_NO_WHATSTHIS
        advPvtIdGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advPvtIdGenerateBtn->setText(QApplication::translate("OtpPage", "Generate", nullptr));
        advPubIdHelpBtn->setText(QString());
        advPvtIdHelpBtn->setText(QString());
        advPubIdCheck->setText(QApplication::translate("OtpPage", "Public Identity (1-16 bytes Modhex)", nullptr));
        advPvtIdCheck->setText(QApplication::translate("OtpPage", "Private Identity (6 bytes Hex)", nullptr));
        advPubIdLenLbl->setText(QApplication::translate("OtpPage", "Public Identity Length", nullptr));
        advSecretKeyLbl->setText(QApplication::translate("OtpPage", "Secret Key (16 bytes Hex)", nullptr));
        advPubIdLenBox->setSuffix(QString());
        advPubIdLenBox->setPrefix(QString());
        advStaticLenDescLbl->setText(QApplication::translate("OtpPage", "(6 bytes is default length as required by Yubico OTP validation server)", nullptr));
        advActionsBox->setTitle(QApplication::translate("OtpPage", "Actions", nullptr));
        advWriteConfigBtn->setText(QApplication::translate("OtpPage", "Write Configuration", nullptr));
#ifndef QT_NO_WHATSTHIS
        advStopBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advStopBtn->setText(QApplication::translate("OtpPage", "Stop", nullptr));
        advActionsDescLbl->setText(QApplication::translate("OtpPage", "Press Write Configuration button to program your YubiKey's selected configuration slot", nullptr));
#ifndef QT_NO_WHATSTHIS
        advBackBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advBackBtn->setText(QApplication::translate("OtpPage", "Back", nullptr));
#ifndef QT_NO_WHATSTHIS
        advResetBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advResetBtn->setText(QApplication::translate("OtpPage", "Reset", nullptr));
#ifndef QT_NO_WHATSTHIS
        advExportConfigBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advExportConfigBtn->setText(QApplication::translate("OtpPage", "Export", nullptr));
        advProgramMulKeysBox->setTitle(QApplication::translate("OtpPage", "Program Multiple YubiKeys", nullptr));
        advAutoProgramKeysCheck->setText(QApplication::translate("OtpPage", "Automatically program YubiKeys when inserted", nullptr));
        advParamGenSchemeLbl->setText(QApplication::translate("OtpPage", "Parameter Generation Scheme", nullptr));
        advConfigParamsCombo->setItemText(0, QApplication::translate("OtpPage", "Increment Identity; Randomize Secrets", nullptr));
        advConfigParamsCombo->setItemText(1, QApplication::translate("OtpPage", "Randomize all parameters", nullptr));
        advConfigParamsCombo->setItemText(2, QApplication::translate("OtpPage", "Identity from serial; Randomize Secrets", nullptr));

        advParamGenSchemeHelpBtn->setText(QString());
        advResultsBox->setTitle(QApplication::translate("OtpPage", "Results", nullptr));
        QTableWidgetItem *___qtablewidgetitem = advResultsWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("OtpPage", "#", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = advResultsWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("OtpPage", "Public Identity (Modhex)", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = advResultsWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("OtpPage", "Status", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = advResultsWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("OtpPage", "Timestamp", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OtpPage: public Ui_OtpPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OTPPAGE_H
