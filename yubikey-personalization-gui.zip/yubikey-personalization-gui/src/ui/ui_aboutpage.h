/********************************************************************************
** Form generated from reading UI file 'aboutpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUTPAGE_H
#define UI_ABOUTPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AboutPage
{
public:
    QFrame *frame;
    QPushButton *otpBtn;
    QPushButton *chalRespBtn;
    QPushButton *staticBtn;
    QPushButton *oathBtn;
    QLabel *appVersionLbl;
    QLabel *copyrightLbl;
    QFrame *headerLine;
    QLabel *baseHeadingLabel;
    QFrame *bottomLine;
    QLabel *personalizeLbl;
    QLabel *right1;
    QLabel *right2;
    QLabel *right3;
    QLabel *right4;
    QLabel *supportLbl;
    QPushButton *supportBtn;
    QLabel *right5;
    QPushButton *settingsBtn;
    QLabel *libVersionLbl;

    void setupUi(QWidget *AboutPage)
    {
        if (AboutPage->objectName().isEmpty())
            AboutPage->setObjectName(QString::fromUtf8("AboutPage"));
        AboutPage->resize(730, 650);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(AboutPage->sizePolicy().hasHeightForWidth());
        AboutPage->setSizePolicy(sizePolicy);
        AboutPage->setMaximumSize(QSize(730, 650));
        AboutPage->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";"));
        frame = new QFrame(AboutPage);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(30, 80, 671, 450));
        frame->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(0, 0, 0);\n"
"border-radius: 5px;"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Sunken);
        frame->setLineWidth(0);
        otpBtn = new QPushButton(frame);
        otpBtn->setObjectName(QString::fromUtf8("otpBtn"));
        otpBtn->setGeometry(QRect(71, 121, 168, 23));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(otpBtn->sizePolicy().hasHeightForWidth());
        otpBtn->setSizePolicy(sizePolicy1);
        otpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        otpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        otpBtn->setLayoutDirection(Qt::LeftToRight);
        otpBtn->setAutoFillBackground(false);
        otpBtn->setStyleSheet(QString::fromUtf8("font: 12px \"Verdana\";\n"
"text-decoration: underline;\n"
"text-align: left;\n"
"color: rgb(5, 67, 168);"));
        otpBtn->setCheckable(false);
        otpBtn->setAutoDefault(false);
        otpBtn->setFlat(true);
        chalRespBtn = new QPushButton(frame);
        chalRespBtn->setObjectName(QString::fromUtf8("chalRespBtn"));
        chalRespBtn->setGeometry(QRect(70, 211, 168, 23));
        sizePolicy1.setHeightForWidth(chalRespBtn->sizePolicy().hasHeightForWidth());
        chalRespBtn->setSizePolicy(sizePolicy1);
        chalRespBtn->setCursor(QCursor(Qt::PointingHandCursor));
        chalRespBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        chalRespBtn->setLayoutDirection(Qt::LeftToRight);
        chalRespBtn->setAutoFillBackground(false);
        chalRespBtn->setStyleSheet(QString::fromUtf8("font: 12px \"Verdana\";\n"
"text-decoration: underline;\n"
"text-align: left;\n"
"color: rgb(5, 67, 168);"));
        chalRespBtn->setAutoDefault(false);
        chalRespBtn->setFlat(true);
        staticBtn = new QPushButton(frame);
        staticBtn->setObjectName(QString::fromUtf8("staticBtn"));
        staticBtn->setGeometry(QRect(70, 181, 168, 23));
        sizePolicy1.setHeightForWidth(staticBtn->sizePolicy().hasHeightForWidth());
        staticBtn->setSizePolicy(sizePolicy1);
        staticBtn->setCursor(QCursor(Qt::PointingHandCursor));
        staticBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        staticBtn->setLayoutDirection(Qt::LeftToRight);
        staticBtn->setAutoFillBackground(false);
        staticBtn->setStyleSheet(QString::fromUtf8("font: 12px \"Verdana\";\n"
"text-decoration: underline;\n"
"text-align: left;\n"
"color: rgb(5, 67, 168);"));
        staticBtn->setAutoDefault(false);
        staticBtn->setFlat(true);
        oathBtn = new QPushButton(frame);
        oathBtn->setObjectName(QString::fromUtf8("oathBtn"));
        oathBtn->setGeometry(QRect(71, 151, 168, 23));
        sizePolicy1.setHeightForWidth(oathBtn->sizePolicy().hasHeightForWidth());
        oathBtn->setSizePolicy(sizePolicy1);
        oathBtn->setCursor(QCursor(Qt::PointingHandCursor));
        oathBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        oathBtn->setLayoutDirection(Qt::LeftToRight);
        oathBtn->setAutoFillBackground(false);
        oathBtn->setStyleSheet(QString::fromUtf8("font: 12px \"Verdana\";\n"
"text-decoration: underline;\n"
"text-align: left;\n"
"color: rgb(5, 67, 168);"));
        oathBtn->setAutoDefault(false);
        oathBtn->setFlat(true);
        appVersionLbl = new QLabel(frame);
        appVersionLbl->setObjectName(QString::fromUtf8("appVersionLbl"));
        appVersionLbl->setGeometry(QRect(410, 355, 240, 20));
        appVersionLbl->setStyleSheet(QString::fromUtf8(""));
        appVersionLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        copyrightLbl = new QLabel(frame);
        copyrightLbl->setObjectName(QString::fromUtf8("copyrightLbl"));
        copyrightLbl->setGeometry(QRect(20, 420, 631, 20));
        copyrightLbl->setTextFormat(Qt::RichText);
        copyrightLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        headerLine = new QFrame(frame);
        headerLine->setObjectName(QString::fromUtf8("headerLine"));
        headerLine->setGeometry(QRect(0, 73, 671, 2));
        headerLine->setStyleSheet(QString::fromUtf8("background-color: rgb(140, 192, 65);"));
        headerLine->setLineWidth(1);
        headerLine->setFrameShape(QFrame::HLine);
        headerLine->setFrameShadow(QFrame::Sunken);
        baseHeadingLabel = new QLabel(frame);
        baseHeadingLabel->setObjectName(QString::fromUtf8("baseHeadingLabel"));
        baseHeadingLabel->setGeometry(QRect(143, 25, 384, 22));
        baseHeadingLabel->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        baseHeadingLabel->setAlignment(Qt::AlignCenter);
        bottomLine = new QFrame(frame);
        bottomLine->setObjectName(QString::fromUtf8("bottomLine"));
        bottomLine->setGeometry(QRect(0, 410, 671, 1));
        bottomLine->setStyleSheet(QString::fromUtf8("background-color: rgb(140, 192, 65);"));
        bottomLine->setLineWidth(1);
        bottomLine->setFrameShape(QFrame::HLine);
        bottomLine->setFrameShadow(QFrame::Sunken);
        personalizeLbl = new QLabel(frame);
        personalizeLbl->setObjectName(QString::fromUtf8("personalizeLbl"));
        personalizeLbl->setGeometry(QRect(20, 96, 271, 20));
        personalizeLbl->setStyleSheet(QString::fromUtf8("font: 12px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(118, 116, 108);"));
        right1 = new QLabel(frame);
        right1->setObjectName(QString::fromUtf8("right1"));
        right1->setGeometry(QRect(33, 121, 24, 24));
        right1->setPixmap(QPixmap(QString::fromUtf8(":/res/images/right.png")));
        right1->setAlignment(Qt::AlignCenter);
        right2 = new QLabel(frame);
        right2->setObjectName(QString::fromUtf8("right2"));
        right2->setGeometry(QRect(33, 151, 24, 24));
        right2->setPixmap(QPixmap(QString::fromUtf8(":/res/images/right.png")));
        right2->setAlignment(Qt::AlignCenter);
        right3 = new QLabel(frame);
        right3->setObjectName(QString::fromUtf8("right3"));
        right3->setGeometry(QRect(33, 181, 24, 24));
        right3->setPixmap(QPixmap(QString::fromUtf8(":/res/images/right.png")));
        right3->setAlignment(Qt::AlignCenter);
        right4 = new QLabel(frame);
        right4->setObjectName(QString::fromUtf8("right4"));
        right4->setGeometry(QRect(33, 211, 24, 24));
        right4->setPixmap(QPixmap(QString::fromUtf8(":/res/images/right.png")));
        right4->setAlignment(Qt::AlignCenter);
        supportLbl = new QLabel(frame);
        supportLbl->setObjectName(QString::fromUtf8("supportLbl"));
        supportLbl->setGeometry(QRect(20, 290, 191, 20));
        supportBtn = new QPushButton(frame);
        supportBtn->setObjectName(QString::fromUtf8("supportBtn"));
        supportBtn->setGeometry(QRect(20, 310, 131, 20));
        sizePolicy1.setHeightForWidth(supportBtn->sizePolicy().hasHeightForWidth());
        supportBtn->setSizePolicy(sizePolicy1);
        supportBtn->setCursor(QCursor(Qt::PointingHandCursor));
        supportBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        supportBtn->setLayoutDirection(Qt::LeftToRight);
        supportBtn->setAutoFillBackground(false);
        supportBtn->setStyleSheet(QString::fromUtf8("font: 12px \"Verdana\";\n"
"text-decoration: underline;\n"
"color: rgb(5, 67, 168);"));
        supportBtn->setAutoDefault(false);
        supportBtn->setFlat(true);
        right5 = new QLabel(frame);
        right5->setObjectName(QString::fromUtf8("right5"));
        right5->setGeometry(QRect(33, 241, 24, 24));
        right5->setPixmap(QPixmap(QString::fromUtf8(":/res/images/right.png")));
        right5->setAlignment(Qt::AlignCenter);
        settingsBtn = new QPushButton(frame);
        settingsBtn->setObjectName(QString::fromUtf8("settingsBtn"));
        settingsBtn->setGeometry(QRect(70, 241, 168, 23));
        sizePolicy1.setHeightForWidth(settingsBtn->sizePolicy().hasHeightForWidth());
        settingsBtn->setSizePolicy(sizePolicy1);
        settingsBtn->setCursor(QCursor(Qt::PointingHandCursor));
        settingsBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        settingsBtn->setLayoutDirection(Qt::LeftToRight);
        settingsBtn->setAutoFillBackground(false);
        settingsBtn->setStyleSheet(QString::fromUtf8("font: 12px \"Verdana\";\n"
"text-decoration: underline;\n"
"text-align: left;\n"
"color: rgb(5, 67, 168);"));
        settingsBtn->setAutoDefault(false);
        settingsBtn->setFlat(true);
        libVersionLbl = new QLabel(frame);
        libVersionLbl->setObjectName(QString::fromUtf8("libVersionLbl"));
        libVersionLbl->setGeometry(QRect(410, 380, 240, 20));
        libVersionLbl->setStyleSheet(QString::fromUtf8(""));
        libVersionLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        QWidget::setTabOrder(otpBtn, oathBtn);
        QWidget::setTabOrder(oathBtn, staticBtn);
        QWidget::setTabOrder(staticBtn, chalRespBtn);
        QWidget::setTabOrder(chalRespBtn, settingsBtn);

        retranslateUi(AboutPage);

        otpBtn->setDefault(false);
        chalRespBtn->setDefault(false);
        staticBtn->setDefault(false);
        oathBtn->setDefault(false);
        supportBtn->setDefault(false);
        settingsBtn->setDefault(false);


        QMetaObject::connectSlotsByName(AboutPage);
    } // setupUi

    void retranslateUi(QWidget *AboutPage)
    {
        AboutPage->setWindowTitle(QApplication::translate("AboutPage", "Form", nullptr));
        otpBtn->setText(QApplication::translate("AboutPage", "Yubico OTP Mode", nullptr));
        chalRespBtn->setText(QApplication::translate("AboutPage", "Challenge-Response Mode", nullptr));
        staticBtn->setText(QApplication::translate("AboutPage", "Static Password Mode", nullptr));
        oathBtn->setText(QApplication::translate("AboutPage", "OATH-HOTP Mode", nullptr));
        appVersionLbl->setText(QApplication::translate("AboutPage", "Application Version:", nullptr));
        copyrightLbl->setText(QString());
        baseHeadingLabel->setText(QApplication::translate("AboutPage", "YubiKey Personalization Tool", nullptr));
        personalizeLbl->setText(QApplication::translate("AboutPage", "Personalize your YubiKey in:", nullptr));
        right1->setText(QString());
        right2->setText(QString());
        right3->setText(QString());
        right4->setText(QString());
        supportLbl->setText(QApplication::translate("AboutPage", "For help and discussion, head to", nullptr));
        supportBtn->setText(QApplication::translate("AboutPage", "https://yubi.co/forum", nullptr));
        right5->setText(QString());
        settingsBtn->setText(QApplication::translate("AboutPage", "Update Settings", nullptr));
        libVersionLbl->setText(QApplication::translate("AboutPage", "Library Version:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AboutPage: public Ui_AboutPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUTPAGE_H
