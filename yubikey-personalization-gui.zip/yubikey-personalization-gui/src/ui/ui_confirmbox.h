/********************************************************************************
** Form generated from reading UI file 'confirmbox.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONFIRMBOX_H
#define UI_CONFIRMBOX_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ConfirmBox
{
public:
    QGridLayout *gridLayout;
    QLabel *iconLbl;
    QVBoxLayout *verticalLayout;
    QLabel *msgLbl;
    QCheckBox *dontaskCheck;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *ConfirmBox)
    {
        if (ConfirmBox->objectName().isEmpty())
            ConfirmBox->setObjectName(QString::fromUtf8("ConfirmBox"));
        ConfirmBox->setWindowModality(Qt::ApplicationModal);
        ConfirmBox->resize(530, 190);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ConfirmBox->sizePolicy().hasHeightForWidth());
        ConfirmBox->setSizePolicy(sizePolicy);
        ConfirmBox->setMinimumSize(QSize(530, 190));
        ConfirmBox->setMaximumSize(QSize(530, 190));
        ConfirmBox->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        gridLayout = new QGridLayout(ConfirmBox);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetMinimumSize);
        iconLbl = new QLabel(ConfirmBox);
        iconLbl->setObjectName(QString::fromUtf8("iconLbl"));
        iconLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        iconLbl->setScaledContents(false);
        iconLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        iconLbl->setIndent(0);

        gridLayout->addWidget(iconLbl, 0, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        msgLbl = new QLabel(ConfirmBox);
        msgLbl->setObjectName(QString::fromUtf8("msgLbl"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(msgLbl->sizePolicy().hasHeightForWidth());
        msgLbl->setSizePolicy(sizePolicy1);
        msgLbl->setMinimumSize(QSize(430, 0));
        msgLbl->setMaximumSize(QSize(430, 500));
        msgLbl->setLayoutDirection(Qt::LeftToRight);
        msgLbl->setAutoFillBackground(true);
        msgLbl->setTextFormat(Qt::PlainText);
        msgLbl->setScaledContents(false);
        msgLbl->setAlignment(Qt::AlignJustify|Qt::AlignTop);
        msgLbl->setWordWrap(true);
        msgLbl->setIndent(0);

        verticalLayout->addWidget(msgLbl);

        dontaskCheck = new QCheckBox(ConfirmBox);
        dontaskCheck->setObjectName(QString::fromUtf8("dontaskCheck"));
        dontaskCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));

        verticalLayout->addWidget(dontaskCheck);

        buttonBox = new QDialogButtonBox(ConfirmBox);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(buttonBox->sizePolicy().hasHeightForWidth());
        buttonBox->setSizePolicy(sizePolicy2);
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::No|QDialogButtonBox::Yes);
        buttonBox->setCenterButtons(true);

        verticalLayout->addWidget(buttonBox);


        gridLayout->addLayout(verticalLayout, 0, 1, 1, 1);

        QWidget::setTabOrder(dontaskCheck, buttonBox);

        retranslateUi(ConfirmBox);
        QObject::connect(buttonBox, SIGNAL(accepted()), ConfirmBox, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ConfirmBox, SLOT(reject()));

        QMetaObject::connectSlotsByName(ConfirmBox);
    } // setupUi

    void retranslateUi(QDialog *ConfirmBox)
    {
        ConfirmBox->setWindowTitle(QApplication::translate("ConfirmBox", "Dialog", nullptr));
        iconLbl->setText(QString());
        msgLbl->setText(QString());
        dontaskCheck->setText(QApplication::translate("ConfirmBox", "Don't show this message again", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ConfirmBox: public Ui_ConfirmBox {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONFIRMBOX_H
