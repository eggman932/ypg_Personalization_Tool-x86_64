/********************************************************************************
** Form generated from reading UI file 'yubiaccbox.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YUBIACCBOX_H
#define UI_YUBIACCBOX_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_YubiAccBox
{
public:
    QGroupBox *configProtectionBox;
    QComboBox *configProtectionCombo;
    QLineEdit *currentAccessCodeTxt;
    QLabel *currentAccessCodeLbl;
    QLabel *newAccessCodeLbl;
    QLineEdit *newAccessCodeTxt;
    QPushButton *configProtectionHelpBtn;
    QCheckBox *currentUseSerial;
    QCheckBox *newUseSerial;

    void setupUi(QWidget *YubiAccBox)
    {
        if (YubiAccBox->objectName().isEmpty())
            YubiAccBox->setObjectName(QString::fromUtf8("YubiAccBox"));
        YubiAccBox->resize(350, 120);
        YubiAccBox->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"       color: rgb(0, 0, 0);"));
        configProtectionBox = new QGroupBox(YubiAccBox);
        configProtectionBox->setObjectName(QString::fromUtf8("configProtectionBox"));
        configProtectionBox->setGeometry(QRect(0, 0, 350, 120));
        configProtectionBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        configProtectionCombo = new QComboBox(configProtectionBox);
        configProtectionCombo->addItem(QString());
        configProtectionCombo->addItem(QString());
        configProtectionCombo->addItem(QString());
        configProtectionCombo->addItem(QString());
        configProtectionCombo->addItem(QString());
        configProtectionCombo->setObjectName(QString::fromUtf8("configProtectionCombo"));
        configProtectionCombo->setGeometry(QRect(10, 24, 330, 22));
        configProtectionCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        currentAccessCodeTxt = new QLineEdit(configProtectionBox);
        currentAccessCodeTxt->setObjectName(QString::fromUtf8("currentAccessCodeTxt"));
        currentAccessCodeTxt->setEnabled(false);
        currentAccessCodeTxt->setGeometry(QRect(170, 52, 170, 20));
        currentAccessCodeTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        currentAccessCodeTxt->setMaxLength(17);
        currentAccessCodeTxt->setCursorPosition(17);
        currentAccessCodeLbl = new QLabel(configProtectionBox);
        currentAccessCodeLbl->setObjectName(QString::fromUtf8("currentAccessCodeLbl"));
        currentAccessCodeLbl->setGeometry(QRect(10, 45, 141, 20));
        currentAccessCodeLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        newAccessCodeLbl = new QLabel(configProtectionBox);
        newAccessCodeLbl->setObjectName(QString::fromUtf8("newAccessCodeLbl"));
        newAccessCodeLbl->setGeometry(QRect(10, 80, 141, 20));
        newAccessCodeLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        newAccessCodeTxt = new QLineEdit(configProtectionBox);
        newAccessCodeTxt->setObjectName(QString::fromUtf8("newAccessCodeTxt"));
        newAccessCodeTxt->setEnabled(false);
        newAccessCodeTxt->setGeometry(QRect(170, 87, 170, 20));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(newAccessCodeTxt->sizePolicy().hasHeightForWidth());
        newAccessCodeTxt->setSizePolicy(sizePolicy);
        newAccessCodeTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        newAccessCodeTxt->setMaxLength(17);
        newAccessCodeTxt->setCursorPosition(17);
        configProtectionHelpBtn = new QPushButton(configProtectionBox);
        configProtectionHelpBtn->setObjectName(QString::fromUtf8("configProtectionHelpBtn"));
        configProtectionHelpBtn->setGeometry(QRect(325, 0, 16, 16));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(configProtectionHelpBtn->sizePolicy().hasHeightForWidth());
        configProtectionHelpBtn->setSizePolicy(sizePolicy1);
        configProtectionHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        configProtectionHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        configProtectionHelpBtn->setLayoutDirection(Qt::LeftToRight);
        configProtectionHelpBtn->setAutoFillBackground(false);
        configProtectionHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        configProtectionHelpBtn->setAutoDefault(false);
        currentUseSerial = new QCheckBox(configProtectionBox);
        currentUseSerial->setObjectName(QString::fromUtf8("currentUseSerial"));
        currentUseSerial->setEnabled(false);
        currentUseSerial->setGeometry(QRect(10, 60, 150, 23));
        currentUseSerial->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"       color: rgb(0, 0, 0);"));
        newUseSerial = new QCheckBox(configProtectionBox);
        newUseSerial->setObjectName(QString::fromUtf8("newUseSerial"));
        newUseSerial->setEnabled(false);
        newUseSerial->setGeometry(QRect(10, 95, 150, 23));
        newUseSerial->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"       color: rgb(0, 0, 0);"));

        retranslateUi(YubiAccBox);

        configProtectionHelpBtn->setDefault(false);


        QMetaObject::connectSlotsByName(YubiAccBox);
    } // setupUi

    void retranslateUi(QWidget *YubiAccBox)
    {
        YubiAccBox->setWindowTitle(QApplication::translate("YubiAccBox", "Form", nullptr));
        configProtectionBox->setTitle(QApplication::translate("YubiAccBox", "Configuration Protection (6 bytes Hex)", nullptr));
        configProtectionCombo->setItemText(0, QApplication::translate("YubiAccBox", "YubiKey(s) unprotected - Keep it that way", nullptr));
        configProtectionCombo->setItemText(1, QApplication::translate("YubiAccBox", "YubiKey(s) unprotected - Enable protection", nullptr));
        configProtectionCombo->setItemText(2, QApplication::translate("YubiAccBox", "YubiKey(s) protected - Disable protection", nullptr));
        configProtectionCombo->setItemText(3, QApplication::translate("YubiAccBox", "YubiKey(s) protected - Keep it that way", nullptr));
        configProtectionCombo->setItemText(4, QApplication::translate("YubiAccBox", "YubiKey(s) protected - Change access code", nullptr));

        currentAccessCodeTxt->setInputMask(QApplication::translate("YubiAccBox", "hh hh hh hh hh hh; ", nullptr));
        currentAccessCodeTxt->setText(QString());
        currentAccessCodeLbl->setText(QApplication::translate("YubiAccBox", "Current Access Code", nullptr));
        newAccessCodeLbl->setText(QApplication::translate("YubiAccBox", "New Access Code", nullptr));
        newAccessCodeTxt->setInputMask(QApplication::translate("YubiAccBox", "hh hh hh hh hh hh; ", nullptr));
        newAccessCodeTxt->setText(QString());
        configProtectionHelpBtn->setText(QString());
        currentUseSerial->setText(QApplication::translate("YubiAccBox", "Use Serial Number", nullptr));
        newUseSerial->setText(QApplication::translate("YubiAccBox", "Use Serial Number", nullptr));
    } // retranslateUi

};

namespace Ui {
    class YubiAccBox: public Ui_YubiAccBox {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YUBIACCBOX_H
