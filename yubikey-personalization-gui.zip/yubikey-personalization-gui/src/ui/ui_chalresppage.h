/********************************************************************************
** Form generated from reading UI file 'chalresppage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHALRESPPAGE_H
#define UI_CHALRESPPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>
#include "yubiaccbox.h"

QT_BEGIN_NAMESPACE

class Ui_ChalRespPage
{
public:
    QWidget *basePage;
    QLabel *baseHeadingLbl;
    QGroupBox *baseActionsBox;
    QPushButton *quickBtn;
    QPushButton *advBtn;
    QLabel *quickDescLbl;
    QLabel *advancedDescLbl;
    QPushButton *quickHelpBtn;
    QPushButton *advHelpBtn;
    QWidget *quickPage;
    QLabel *quickHeadingLbl;
    QGroupBox *quickProgramMulKeysBox;
    QCheckBox *quickAutoProgramKeysCheck;
    QLabel *quickParamGenSchemeLbl;
    QComboBox *quickConfigParamsCombo;
    QPushButton *quickParamGenSchemeHelpBtn;
    QGroupBox *quickConfigBox;
    QLabel *quickConfigDescLbl;
    QRadioButton *quickConfigSlot1Radio;
    QRadioButton *quickConfigSlot2Radio;
    QPushButton *quickConfigHelpBtn;
    QGroupBox *quickKeyParamsBox;
    QPushButton *quickSecretKeyHelpBtn;
    QLineEdit *quickSecretKeyTxt;
    QPushButton *quickSecretKeyGenerateBtn;
    QLabel *quickSecretKeyLbl;
    QCheckBox *quickPvtIdCheck;
    QLineEdit *quickPvtIdTxt;
    QPushButton *quickPvtIdGenerateBtn;
    QPushButton *quickPvtIdHelpBtn;
    QCheckBox *quickRequireUserInputCheck;
    QPushButton *quickChalRespOptionsHelpBtn;
    QGroupBox *quickActionsBox;
    QPushButton *quickWriteConfigBtn;
    QPushButton *quickStopBtn;
    QLabel *quickActionsDescLbl;
    QPushButton *quickBackBtn;
    QPushButton *quickResetBtn;
    QPushButton *quickExportConfigBtn;
    QGroupBox *quickResultsBox;
    QTableWidget *quickResultsWidget;
    YubiAccBox *quickConfigProtectionBox;
    QWidget *advPage;
    QLabel *advHeadingLbl;
    QGroupBox *advConfigBox;
    QLabel *advConfigDescLbl;
    QRadioButton *advConfigSlot1Radio;
    QRadioButton *advConfigSlot2Radio;
    QPushButton *advConfigHelpBtn;
    QGroupBox *advActionsBox;
    QPushButton *advWriteConfigBtn;
    QPushButton *advStopBtn;
    QLabel *advActionsDescLbl;
    QPushButton *advBackBtn;
    QPushButton *advResetBtn;
    QPushButton *advExportConfigBtn;
    QGroupBox *advProgramMulKeysBox;
    QCheckBox *advAutoProgramKeysCheck;
    QLabel *advParamGenSchemeLbl;
    QComboBox *advConfigParamsCombo;
    QGroupBox *advKeyParamsBox;
    QPushButton *advChalRespOptionsHelpBtn;
    QCheckBox *advRequireUserInputCheck;
    QRadioButton *advHmacVarInputRadio;
    QRadioButton *advHmacFixedInputRadio;
    QLabel *advHmacModeLbl;
    QLabel *advSecretKeyLbl;
    QLineEdit *advSecretKeyTxt;
    QPushButton *advSecretKeyGenerateBtn;
    QPushButton *advSecretKeyHelpBtn;
    QGroupBox *advResultsBox;
    QTableWidget *advResultsWidget;
    YubiAccBox *advConfigProtectionBox;

    void setupUi(QStackedWidget *ChalRespPage)
    {
        if (ChalRespPage->objectName().isEmpty())
            ChalRespPage->setObjectName(QString::fromUtf8("ChalRespPage"));
        ChalRespPage->resize(730, 650);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ChalRespPage->sizePolicy().hasHeightForWidth());
        ChalRespPage->setSizePolicy(sizePolicy);
        ChalRespPage->setMaximumSize(QSize(730, 650));
        ChalRespPage->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        basePage = new QWidget();
        basePage->setObjectName(QString::fromUtf8("basePage"));
        baseHeadingLbl = new QLabel(basePage);
        baseHeadingLbl->setObjectName(QString::fromUtf8("baseHeadingLbl"));
        baseHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        baseHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        baseHeadingLbl->setAlignment(Qt::AlignCenter);
        baseActionsBox = new QGroupBox(basePage);
        baseActionsBox->setObjectName(QString::fromUtf8("baseActionsBox"));
        baseActionsBox->setGeometry(QRect(10, 50, 710, 171));
        baseActionsBox->setStyleSheet(QString::fromUtf8("border-color: rgb(0, 0, 0);"));
        baseActionsBox->setAlignment(Qt::AlignCenter);
        quickBtn = new QPushButton(baseActionsBox);
        quickBtn->setObjectName(QString::fromUtf8("quickBtn"));
        quickBtn->setGeometry(QRect(20, 20, 141, 25));
        sizePolicy.setHeightForWidth(quickBtn->sizePolicy().hasHeightForWidth());
        quickBtn->setSizePolicy(sizePolicy);
        quickBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickBtn->setAutoExclusive(false);
        quickBtn->setFlat(false);
        advBtn = new QPushButton(baseActionsBox);
        advBtn->setObjectName(QString::fromUtf8("advBtn"));
        advBtn->setGeometry(QRect(20, 100, 141, 25));
        advBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advBtn->setCheckable(false);
        advBtn->setChecked(false);
        quickDescLbl = new QLabel(baseActionsBox);
        quickDescLbl->setObjectName(QString::fromUtf8("quickDescLbl"));
        quickDescLbl->setGeometry(QRect(20, 45, 671, 20));
        quickDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        advancedDescLbl = new QLabel(baseActionsBox);
        advancedDescLbl->setObjectName(QString::fromUtf8("advancedDescLbl"));
        advancedDescLbl->setGeometry(QRect(20, 125, 671, 30));
        advancedDescLbl->setStyleSheet(QString::fromUtf8(""));
        advancedDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        quickHelpBtn = new QPushButton(baseActionsBox);
        quickHelpBtn->setObjectName(QString::fromUtf8("quickHelpBtn"));
        quickHelpBtn->setGeometry(QRect(170, 24, 16, 16));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(quickHelpBtn->sizePolicy().hasHeightForWidth());
        quickHelpBtn->setSizePolicy(sizePolicy1);
        quickHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickHelpBtn->setAutoFillBackground(false);
        quickHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickHelpBtn->setAutoDefault(false);
        advHelpBtn = new QPushButton(baseActionsBox);
        advHelpBtn->setObjectName(QString::fromUtf8("advHelpBtn"));
        advHelpBtn->setGeometry(QRect(170, 104, 16, 16));
        sizePolicy1.setHeightForWidth(advHelpBtn->sizePolicy().hasHeightForWidth());
        advHelpBtn->setSizePolicy(sizePolicy1);
        advHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advHelpBtn->setAutoFillBackground(false);
        advHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advHelpBtn->setAutoDefault(false);
        ChalRespPage->addWidget(basePage);
        quickPage = new QWidget();
        quickPage->setObjectName(QString::fromUtf8("quickPage"));
        quickHeadingLbl = new QLabel(quickPage);
        quickHeadingLbl->setObjectName(QString::fromUtf8("quickHeadingLbl"));
        quickHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        quickHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        quickHeadingLbl->setAlignment(Qt::AlignCenter);
        quickProgramMulKeysBox = new QGroupBox(quickPage);
        quickProgramMulKeysBox->setObjectName(QString::fromUtf8("quickProgramMulKeysBox"));
        quickProgramMulKeysBox->setGeometry(QRect(10, 132, 350, 107));
        quickProgramMulKeysBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        quickProgramMulKeysBox->setCheckable(true);
        quickProgramMulKeysBox->setChecked(false);
        quickAutoProgramKeysCheck = new QCheckBox(quickProgramMulKeysBox);
        quickAutoProgramKeysCheck->setObjectName(QString::fromUtf8("quickAutoProgramKeysCheck"));
        quickAutoProgramKeysCheck->setGeometry(QRect(10, 25, 331, 17));
        quickAutoProgramKeysCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickParamGenSchemeLbl = new QLabel(quickProgramMulKeysBox);
        quickParamGenSchemeLbl->setObjectName(QString::fromUtf8("quickParamGenSchemeLbl"));
        quickParamGenSchemeLbl->setGeometry(QRect(10, 52, 191, 20));
        quickParamGenSchemeLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickParamGenSchemeLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        quickConfigParamsCombo = new QComboBox(quickProgramMulKeysBox);
        quickConfigParamsCombo->addItem(QString());
        quickConfigParamsCombo->addItem(QString());
        quickConfigParamsCombo->setObjectName(QString::fromUtf8("quickConfigParamsCombo"));
        quickConfigParamsCombo->setGeometry(QRect(10, 75, 331, 22));
        sizePolicy.setHeightForWidth(quickConfigParamsCombo->sizePolicy().hasHeightForWidth());
        quickConfigParamsCombo->setSizePolicy(sizePolicy);
        quickConfigParamsCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickParamGenSchemeHelpBtn = new QPushButton(quickProgramMulKeysBox);
        quickParamGenSchemeHelpBtn->setObjectName(QString::fromUtf8("quickParamGenSchemeHelpBtn"));
        quickParamGenSchemeHelpBtn->setGeometry(QRect(325, 52, 16, 16));
        sizePolicy1.setHeightForWidth(quickParamGenSchemeHelpBtn->sizePolicy().hasHeightForWidth());
        quickParamGenSchemeHelpBtn->setSizePolicy(sizePolicy1);
        quickParamGenSchemeHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickParamGenSchemeHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickParamGenSchemeHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickParamGenSchemeHelpBtn->setAutoFillBackground(false);
        quickParamGenSchemeHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickParamGenSchemeHelpBtn->setAutoDefault(false);
        quickConfigBox = new QGroupBox(quickPage);
        quickConfigBox->setObjectName(QString::fromUtf8("quickConfigBox"));
        quickConfigBox->setGeometry(QRect(10, 50, 711, 72));
        quickConfigBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        quickConfigDescLbl = new QLabel(quickConfigBox);
        quickConfigDescLbl->setObjectName(QString::fromUtf8("quickConfigDescLbl"));
        quickConfigDescLbl->setGeometry(QRect(10, 25, 321, 16));
        quickConfigDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        quickConfigSlot1Radio = new QRadioButton(quickConfigBox);
        quickConfigSlot1Radio->setObjectName(QString::fromUtf8("quickConfigSlot1Radio"));
        quickConfigSlot1Radio->setGeometry(QRect(10, 45, 151, 19));
        quickConfigSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickConfigSlot1Radio->setCheckable(true);
        quickConfigSlot1Radio->setChecked(false);
        quickConfigSlot2Radio = new QRadioButton(quickConfigBox);
        quickConfigSlot2Radio->setObjectName(QString::fromUtf8("quickConfigSlot2Radio"));
        quickConfigSlot2Radio->setGeometry(QRect(240, 45, 151, 19));
        quickConfigSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickConfigHelpBtn = new QPushButton(quickConfigBox);
        quickConfigHelpBtn->setObjectName(QString::fromUtf8("quickConfigHelpBtn"));
        quickConfigHelpBtn->setGeometry(QRect(685, 45, 16, 16));
        sizePolicy1.setHeightForWidth(quickConfigHelpBtn->sizePolicy().hasHeightForWidth());
        quickConfigHelpBtn->setSizePolicy(sizePolicy1);
        quickConfigHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickConfigHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickConfigHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickConfigHelpBtn->setAutoFillBackground(false);
        quickConfigHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickConfigHelpBtn->setAutoDefault(false);
        quickKeyParamsBox = new QGroupBox(quickPage);
        quickKeyParamsBox->setObjectName(QString::fromUtf8("quickKeyParamsBox"));
        quickKeyParamsBox->setGeometry(QRect(10, 249, 711, 107));
        quickKeyParamsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        quickSecretKeyHelpBtn = new QPushButton(quickKeyParamsBox);
        quickSecretKeyHelpBtn->setObjectName(QString::fromUtf8("quickSecretKeyHelpBtn"));
        quickSecretKeyHelpBtn->setGeometry(QRect(685, 77, 16, 16));
        sizePolicy1.setHeightForWidth(quickSecretKeyHelpBtn->sizePolicy().hasHeightForWidth());
        quickSecretKeyHelpBtn->setSizePolicy(sizePolicy1);
        quickSecretKeyHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickSecretKeyHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickSecretKeyHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickSecretKeyHelpBtn->setAutoFillBackground(false);
        quickSecretKeyHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickSecretKeyHelpBtn->setAutoDefault(false);
        quickSecretKeyTxt = new QLineEdit(quickKeyParamsBox);
        quickSecretKeyTxt->setObjectName(QString::fromUtf8("quickSecretKeyTxt"));
        quickSecretKeyTxt->setGeometry(QRect(240, 75, 330, 20));
        sizePolicy.setHeightForWidth(quickSecretKeyTxt->sizePolicy().hasHeightForWidth());
        quickSecretKeyTxt->setSizePolicy(sizePolicy);
        quickSecretKeyTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickSecretKeyTxt->setMaxLength(47);
        quickSecretKeyTxt->setCursorPosition(47);
        quickSecretKeyGenerateBtn = new QPushButton(quickKeyParamsBox);
        quickSecretKeyGenerateBtn->setObjectName(QString::fromUtf8("quickSecretKeyGenerateBtn"));
        quickSecretKeyGenerateBtn->setGeometry(QRect(580, 73, 100, 24));
        quickSecretKeyGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickSecretKeyGenerateBtn->setAutoExclusive(false);
        quickSecretKeyGenerateBtn->setFlat(false);
        quickSecretKeyLbl = new QLabel(quickKeyParamsBox);
        quickSecretKeyLbl->setObjectName(QString::fromUtf8("quickSecretKeyLbl"));
        quickSecretKeyLbl->setGeometry(QRect(10, 75, 221, 20));
        quickSecretKeyLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickPvtIdCheck = new QCheckBox(quickKeyParamsBox);
        quickPvtIdCheck->setObjectName(QString::fromUtf8("quickPvtIdCheck"));
        quickPvtIdCheck->setGeometry(QRect(10, 50, 221, 17));
        quickPvtIdCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickPvtIdTxt = new QLineEdit(quickKeyParamsBox);
        quickPvtIdTxt->setObjectName(QString::fromUtf8("quickPvtIdTxt"));
        quickPvtIdTxt->setGeometry(QRect(240, 50, 330, 20));
        sizePolicy.setHeightForWidth(quickPvtIdTxt->sizePolicy().hasHeightForWidth());
        quickPvtIdTxt->setSizePolicy(sizePolicy);
        quickPvtIdTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickPvtIdTxt->setMaxLength(17);
        quickPvtIdTxt->setCursorPosition(17);
        quickPvtIdGenerateBtn = new QPushButton(quickKeyParamsBox);
        quickPvtIdGenerateBtn->setObjectName(QString::fromUtf8("quickPvtIdGenerateBtn"));
        quickPvtIdGenerateBtn->setGeometry(QRect(580, 48, 100, 24));
        quickPvtIdGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickPvtIdGenerateBtn->setAutoExclusive(false);
        quickPvtIdGenerateBtn->setFlat(false);
        quickPvtIdHelpBtn = new QPushButton(quickKeyParamsBox);
        quickPvtIdHelpBtn->setObjectName(QString::fromUtf8("quickPvtIdHelpBtn"));
        quickPvtIdHelpBtn->setGeometry(QRect(685, 52, 16, 16));
        sizePolicy1.setHeightForWidth(quickPvtIdHelpBtn->sizePolicy().hasHeightForWidth());
        quickPvtIdHelpBtn->setSizePolicy(sizePolicy1);
        quickPvtIdHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickPvtIdHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickPvtIdHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickPvtIdHelpBtn->setAutoFillBackground(false);
        quickPvtIdHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickPvtIdHelpBtn->setAutoDefault(false);
        quickRequireUserInputCheck = new QCheckBox(quickKeyParamsBox);
        quickRequireUserInputCheck->setObjectName(QString::fromUtf8("quickRequireUserInputCheck"));
        quickRequireUserInputCheck->setGeometry(QRect(10, 25, 221, 17));
        quickRequireUserInputCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickChalRespOptionsHelpBtn = new QPushButton(quickKeyParamsBox);
        quickChalRespOptionsHelpBtn->setObjectName(QString::fromUtf8("quickChalRespOptionsHelpBtn"));
        quickChalRespOptionsHelpBtn->setGeometry(QRect(685, 27, 16, 16));
        sizePolicy1.setHeightForWidth(quickChalRespOptionsHelpBtn->sizePolicy().hasHeightForWidth());
        quickChalRespOptionsHelpBtn->setSizePolicy(sizePolicy1);
        quickChalRespOptionsHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickChalRespOptionsHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickChalRespOptionsHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickChalRespOptionsHelpBtn->setAutoFillBackground(false);
        quickChalRespOptionsHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickChalRespOptionsHelpBtn->setAutoDefault(false);
        quickActionsBox = new QGroupBox(quickPage);
        quickActionsBox->setObjectName(QString::fromUtf8("quickActionsBox"));
        quickActionsBox->setGeometry(QRect(10, 366, 711, 80));
        quickActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickWriteConfigBtn = new QPushButton(quickActionsBox);
        quickWriteConfigBtn->setObjectName(QString::fromUtf8("quickWriteConfigBtn"));
        quickWriteConfigBtn->setGeometry(QRect(10, 45, 175, 25));
        quickWriteConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickWriteConfigBtn->setAutoExclusive(false);
        quickWriteConfigBtn->setFlat(false);
        quickStopBtn = new QPushButton(quickActionsBox);
        quickStopBtn->setObjectName(QString::fromUtf8("quickStopBtn"));
        quickStopBtn->setEnabled(false);
        quickStopBtn->setGeometry(QRect(200, 45, 85, 25));
        quickStopBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickStopBtn->setAutoExclusive(false);
        quickStopBtn->setFlat(false);
        quickActionsDescLbl = new QLabel(quickActionsBox);
        quickActionsDescLbl->setObjectName(QString::fromUtf8("quickActionsDescLbl"));
        quickActionsDescLbl->setGeometry(QRect(10, 25, 691, 16));
        quickActionsDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        quickBackBtn = new QPushButton(quickActionsBox);
        quickBackBtn->setObjectName(QString::fromUtf8("quickBackBtn"));
        quickBackBtn->setGeometry(QRect(400, 45, 85, 25));
        quickBackBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickBackBtn->setAutoExclusive(false);
        quickBackBtn->setFlat(false);
        quickResetBtn = new QPushButton(quickActionsBox);
        quickResetBtn->setObjectName(QString::fromUtf8("quickResetBtn"));
        quickResetBtn->setEnabled(false);
        quickResetBtn->setGeometry(QRect(300, 45, 85, 25));
        quickResetBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickResetBtn->setAutoExclusive(false);
        quickResetBtn->setFlat(false);
        quickExportConfigBtn = new QPushButton(quickActionsBox);
        quickExportConfigBtn->setObjectName(QString::fromUtf8("quickExportConfigBtn"));
        quickExportConfigBtn->setGeometry(QRect(580, 45, 100, 25));
        quickExportConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickExportConfigBtn->setAutoExclusive(false);
        quickExportConfigBtn->setFlat(false);
        quickResultsBox = new QGroupBox(quickPage);
        quickResultsBox->setObjectName(QString::fromUtf8("quickResultsBox"));
        quickResultsBox->setGeometry(QRect(10, 456, 711, 130));
        quickResultsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickResultsWidget = new QTableWidget(quickResultsBox);
        if (quickResultsWidget->columnCount() < 3)
            quickResultsWidget->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        quickResultsWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        quickResultsWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        quickResultsWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        quickResultsWidget->setObjectName(QString::fromUtf8("quickResultsWidget"));
        quickResultsWidget->setGeometry(QRect(12, 20, 688, 100));
        quickResultsWidget->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        quickResultsWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        quickResultsWidget->setAlternatingRowColors(true);
        quickResultsWidget->setShowGrid(false);
        quickResultsWidget->setGridStyle(Qt::SolidLine);
        quickResultsWidget->setWordWrap(true);
        quickResultsWidget->setRowCount(0);
        quickResultsWidget->setColumnCount(3);
        quickResultsWidget->horizontalHeader()->setMinimumSectionSize(50);
        quickResultsWidget->verticalHeader()->setVisible(false);
        quickResultsWidget->verticalHeader()->setDefaultSectionSize(20);
        quickConfigProtectionBox = new YubiAccBox(quickPage);
        quickConfigProtectionBox->setObjectName(QString::fromUtf8("quickConfigProtectionBox"));
        quickConfigProtectionBox->setGeometry(QRect(370, 132, 350, 117));
        ChalRespPage->addWidget(quickPage);
        advPage = new QWidget();
        advPage->setObjectName(QString::fromUtf8("advPage"));
        advHeadingLbl = new QLabel(advPage);
        advHeadingLbl->setObjectName(QString::fromUtf8("advHeadingLbl"));
        advHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        advHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        advHeadingLbl->setAlignment(Qt::AlignCenter);
        advConfigBox = new QGroupBox(advPage);
        advConfigBox->setObjectName(QString::fromUtf8("advConfigBox"));
        advConfigBox->setGeometry(QRect(10, 50, 711, 72));
        advConfigBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advConfigDescLbl = new QLabel(advConfigBox);
        advConfigDescLbl->setObjectName(QString::fromUtf8("advConfigDescLbl"));
        advConfigDescLbl->setGeometry(QRect(10, 25, 321, 16));
        advConfigDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        advConfigSlot1Radio = new QRadioButton(advConfigBox);
        advConfigSlot1Radio->setObjectName(QString::fromUtf8("advConfigSlot1Radio"));
        advConfigSlot1Radio->setGeometry(QRect(10, 45, 151, 19));
        advConfigSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advConfigSlot1Radio->setCheckable(true);
        advConfigSlot1Radio->setChecked(false);
        advConfigSlot2Radio = new QRadioButton(advConfigBox);
        advConfigSlot2Radio->setObjectName(QString::fromUtf8("advConfigSlot2Radio"));
        advConfigSlot2Radio->setGeometry(QRect(240, 45, 151, 19));
        advConfigSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advConfigHelpBtn = new QPushButton(advConfigBox);
        advConfigHelpBtn->setObjectName(QString::fromUtf8("advConfigHelpBtn"));
        advConfigHelpBtn->setGeometry(QRect(685, 45, 16, 16));
        sizePolicy1.setHeightForWidth(advConfigHelpBtn->sizePolicy().hasHeightForWidth());
        advConfigHelpBtn->setSizePolicy(sizePolicy1);
        advConfigHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advConfigHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advConfigHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advConfigHelpBtn->setAutoFillBackground(false);
        advConfigHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advConfigHelpBtn->setAutoDefault(false);
        advActionsBox = new QGroupBox(advPage);
        advActionsBox->setObjectName(QString::fromUtf8("advActionsBox"));
        advActionsBox->setGeometry(QRect(10, 366, 711, 80));
        advActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        advWriteConfigBtn = new QPushButton(advActionsBox);
        advWriteConfigBtn->setObjectName(QString::fromUtf8("advWriteConfigBtn"));
        advWriteConfigBtn->setGeometry(QRect(10, 45, 175, 25));
        advWriteConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advWriteConfigBtn->setAutoExclusive(false);
        advWriteConfigBtn->setFlat(false);
        advStopBtn = new QPushButton(advActionsBox);
        advStopBtn->setObjectName(QString::fromUtf8("advStopBtn"));
        advStopBtn->setEnabled(false);
        advStopBtn->setGeometry(QRect(200, 45, 85, 25));
        advStopBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advStopBtn->setAutoExclusive(false);
        advStopBtn->setFlat(false);
        advActionsDescLbl = new QLabel(advActionsBox);
        advActionsDescLbl->setObjectName(QString::fromUtf8("advActionsDescLbl"));
        advActionsDescLbl->setGeometry(QRect(10, 25, 691, 16));
        advActionsDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        advBackBtn = new QPushButton(advActionsBox);
        advBackBtn->setObjectName(QString::fromUtf8("advBackBtn"));
        advBackBtn->setGeometry(QRect(400, 45, 85, 25));
        advBackBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advBackBtn->setAutoExclusive(false);
        advBackBtn->setFlat(false);
        advResetBtn = new QPushButton(advActionsBox);
        advResetBtn->setObjectName(QString::fromUtf8("advResetBtn"));
        advResetBtn->setEnabled(false);
        advResetBtn->setGeometry(QRect(300, 45, 85, 25));
        advResetBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advResetBtn->setAutoExclusive(false);
        advResetBtn->setFlat(false);
        advExportConfigBtn = new QPushButton(advActionsBox);
        advExportConfigBtn->setObjectName(QString::fromUtf8("advExportConfigBtn"));
        advExportConfigBtn->setGeometry(QRect(580, 45, 100, 25));
        advExportConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advExportConfigBtn->setAutoExclusive(false);
        advExportConfigBtn->setFlat(false);
        advProgramMulKeysBox = new QGroupBox(advPage);
        advProgramMulKeysBox->setObjectName(QString::fromUtf8("advProgramMulKeysBox"));
        advProgramMulKeysBox->setGeometry(QRect(10, 132, 350, 107));
        advProgramMulKeysBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advProgramMulKeysBox->setCheckable(true);
        advProgramMulKeysBox->setChecked(false);
        advAutoProgramKeysCheck = new QCheckBox(advProgramMulKeysBox);
        advAutoProgramKeysCheck->setObjectName(QString::fromUtf8("advAutoProgramKeysCheck"));
        advAutoProgramKeysCheck->setGeometry(QRect(10, 25, 331, 17));
        advAutoProgramKeysCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advParamGenSchemeLbl = new QLabel(advProgramMulKeysBox);
        advParamGenSchemeLbl->setObjectName(QString::fromUtf8("advParamGenSchemeLbl"));
        advParamGenSchemeLbl->setGeometry(QRect(10, 52, 191, 20));
        advParamGenSchemeLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advParamGenSchemeLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        advConfigParamsCombo = new QComboBox(advProgramMulKeysBox);
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->setObjectName(QString::fromUtf8("advConfigParamsCombo"));
        advConfigParamsCombo->setGeometry(QRect(10, 75, 331, 22));
        sizePolicy.setHeightForWidth(advConfigParamsCombo->sizePolicy().hasHeightForWidth());
        advConfigParamsCombo->setSizePolicy(sizePolicy);
        advConfigParamsCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advKeyParamsBox = new QGroupBox(advPage);
        advKeyParamsBox->setObjectName(QString::fromUtf8("advKeyParamsBox"));
        advKeyParamsBox->setGeometry(QRect(10, 249, 711, 107));
        advKeyParamsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advKeyParamsBox->setCheckable(false);
        advChalRespOptionsHelpBtn = new QPushButton(advKeyParamsBox);
        advChalRespOptionsHelpBtn->setObjectName(QString::fromUtf8("advChalRespOptionsHelpBtn"));
        advChalRespOptionsHelpBtn->setGeometry(QRect(685, 25, 16, 16));
        sizePolicy1.setHeightForWidth(advChalRespOptionsHelpBtn->sizePolicy().hasHeightForWidth());
        advChalRespOptionsHelpBtn->setSizePolicy(sizePolicy1);
        advChalRespOptionsHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advChalRespOptionsHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advChalRespOptionsHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advChalRespOptionsHelpBtn->setAutoFillBackground(false);
        advChalRespOptionsHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advChalRespOptionsHelpBtn->setAutoDefault(false);
        advRequireUserInputCheck = new QCheckBox(advKeyParamsBox);
        advRequireUserInputCheck->setObjectName(QString::fromUtf8("advRequireUserInputCheck"));
        advRequireUserInputCheck->setGeometry(QRect(10, 25, 221, 17));
        advRequireUserInputCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advHmacVarInputRadio = new QRadioButton(advKeyParamsBox);
        advHmacVarInputRadio->setObjectName(QString::fromUtf8("advHmacVarInputRadio"));
        advHmacVarInputRadio->setGeometry(QRect(240, 50, 111, 17));
        advHmacVarInputRadio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advHmacVarInputRadio->setCheckable(true);
        advHmacVarInputRadio->setChecked(true);
        advHmacFixedInputRadio = new QRadioButton(advKeyParamsBox);
        advHmacFixedInputRadio->setObjectName(QString::fromUtf8("advHmacFixedInputRadio"));
        advHmacFixedInputRadio->setGeometry(QRect(370, 50, 141, 17));
        advHmacFixedInputRadio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advHmacFixedInputRadio->setCheckable(true);
        advHmacFixedInputRadio->setChecked(false);
        advHmacModeLbl = new QLabel(advKeyParamsBox);
        advHmacModeLbl->setObjectName(QString::fromUtf8("advHmacModeLbl"));
        advHmacModeLbl->setGeometry(QRect(10, 50, 131, 20));
        advHmacModeLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advSecretKeyLbl = new QLabel(advKeyParamsBox);
        advSecretKeyLbl->setObjectName(QString::fromUtf8("advSecretKeyLbl"));
        advSecretKeyLbl->setGeometry(QRect(10, 75, 221, 20));
        advSecretKeyLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advSecretKeyTxt = new QLineEdit(advKeyParamsBox);
        advSecretKeyTxt->setObjectName(QString::fromUtf8("advSecretKeyTxt"));
        advSecretKeyTxt->setGeometry(QRect(240, 75, 330, 20));
        sizePolicy.setHeightForWidth(advSecretKeyTxt->sizePolicy().hasHeightForWidth());
        advSecretKeyTxt->setSizePolicy(sizePolicy);
        advSecretKeyTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advSecretKeyTxt->setMaxLength(59);
        advSecretKeyTxt->setCursorPosition(59);
        advSecretKeyGenerateBtn = new QPushButton(advKeyParamsBox);
        advSecretKeyGenerateBtn->setObjectName(QString::fromUtf8("advSecretKeyGenerateBtn"));
        advSecretKeyGenerateBtn->setGeometry(QRect(580, 73, 100, 24));
        advSecretKeyGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advSecretKeyGenerateBtn->setAutoExclusive(false);
        advSecretKeyGenerateBtn->setFlat(false);
        advSecretKeyHelpBtn = new QPushButton(advKeyParamsBox);
        advSecretKeyHelpBtn->setObjectName(QString::fromUtf8("advSecretKeyHelpBtn"));
        advSecretKeyHelpBtn->setGeometry(QRect(685, 77, 16, 16));
        sizePolicy1.setHeightForWidth(advSecretKeyHelpBtn->sizePolicy().hasHeightForWidth());
        advSecretKeyHelpBtn->setSizePolicy(sizePolicy1);
        advSecretKeyHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advSecretKeyHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advSecretKeyHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advSecretKeyHelpBtn->setAutoFillBackground(false);
        advSecretKeyHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advSecretKeyHelpBtn->setAutoDefault(false);
        advResultsBox = new QGroupBox(advPage);
        advResultsBox->setObjectName(QString::fromUtf8("advResultsBox"));
        advResultsBox->setGeometry(QRect(10, 456, 711, 130));
        advResultsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        advResultsWidget = new QTableWidget(advResultsBox);
        if (advResultsWidget->columnCount() < 3)
            advResultsWidget->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(0, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(1, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(2, __qtablewidgetitem5);
        advResultsWidget->setObjectName(QString::fromUtf8("advResultsWidget"));
        advResultsWidget->setGeometry(QRect(12, 20, 688, 100));
        advResultsWidget->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        advResultsWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        advResultsWidget->setAlternatingRowColors(true);
        advResultsWidget->setShowGrid(false);
        advResultsWidget->setGridStyle(Qt::SolidLine);
        advResultsWidget->setWordWrap(true);
        advResultsWidget->setRowCount(0);
        advResultsWidget->setColumnCount(3);
        advResultsWidget->horizontalHeader()->setMinimumSectionSize(50);
        advResultsWidget->verticalHeader()->setVisible(false);
        advResultsWidget->verticalHeader()->setDefaultSectionSize(20);
        advConfigProtectionBox = new YubiAccBox(advPage);
        advConfigProtectionBox->setObjectName(QString::fromUtf8("advConfigProtectionBox"));
        advConfigProtectionBox->setGeometry(QRect(370, 132, 350, 117));
        ChalRespPage->addWidget(advPage);
        QWidget::setTabOrder(quickBtn, advBtn);
        QWidget::setTabOrder(advBtn, quickHelpBtn);
        QWidget::setTabOrder(quickHelpBtn, advHelpBtn);
        QWidget::setTabOrder(advHelpBtn, quickConfigSlot1Radio);
        QWidget::setTabOrder(quickConfigSlot1Radio, quickConfigSlot2Radio);
        QWidget::setTabOrder(quickConfigSlot2Radio, quickProgramMulKeysBox);
        QWidget::setTabOrder(quickProgramMulKeysBox, quickAutoProgramKeysCheck);
        QWidget::setTabOrder(quickAutoProgramKeysCheck, quickConfigParamsCombo);
        QWidget::setTabOrder(quickConfigParamsCombo, quickRequireUserInputCheck);
        QWidget::setTabOrder(quickRequireUserInputCheck, quickPvtIdCheck);
        QWidget::setTabOrder(quickPvtIdCheck, quickPvtIdTxt);
        QWidget::setTabOrder(quickPvtIdTxt, quickPvtIdGenerateBtn);
        QWidget::setTabOrder(quickPvtIdGenerateBtn, quickSecretKeyTxt);
        QWidget::setTabOrder(quickSecretKeyTxt, quickSecretKeyGenerateBtn);
        QWidget::setTabOrder(quickSecretKeyGenerateBtn, quickWriteConfigBtn);
        QWidget::setTabOrder(quickWriteConfigBtn, quickStopBtn);
        QWidget::setTabOrder(quickStopBtn, quickResetBtn);
        QWidget::setTabOrder(quickResetBtn, quickBackBtn);
        QWidget::setTabOrder(quickBackBtn, quickResultsWidget);
        QWidget::setTabOrder(quickResultsWidget, quickConfigHelpBtn);
        QWidget::setTabOrder(quickConfigHelpBtn, quickChalRespOptionsHelpBtn);
        QWidget::setTabOrder(quickChalRespOptionsHelpBtn, quickPvtIdHelpBtn);
        QWidget::setTabOrder(quickPvtIdHelpBtn, quickSecretKeyHelpBtn);
        QWidget::setTabOrder(quickSecretKeyHelpBtn, advConfigSlot1Radio);
        QWidget::setTabOrder(advConfigSlot1Radio, advConfigSlot2Radio);
        QWidget::setTabOrder(advConfigSlot2Radio, advProgramMulKeysBox);
        QWidget::setTabOrder(advProgramMulKeysBox, advAutoProgramKeysCheck);
        QWidget::setTabOrder(advAutoProgramKeysCheck, advConfigParamsCombo);
        QWidget::setTabOrder(advConfigParamsCombo, advRequireUserInputCheck);
        QWidget::setTabOrder(advRequireUserInputCheck, advHmacVarInputRadio);
        QWidget::setTabOrder(advHmacVarInputRadio, advHmacFixedInputRadio);
        QWidget::setTabOrder(advHmacFixedInputRadio, advSecretKeyTxt);
        QWidget::setTabOrder(advSecretKeyTxt, advSecretKeyGenerateBtn);
        QWidget::setTabOrder(advSecretKeyGenerateBtn, advWriteConfigBtn);
        QWidget::setTabOrder(advWriteConfigBtn, advStopBtn);
        QWidget::setTabOrder(advStopBtn, advResetBtn);
        QWidget::setTabOrder(advResetBtn, advBackBtn);
        QWidget::setTabOrder(advBackBtn, advResultsWidget);
        QWidget::setTabOrder(advResultsWidget, advConfigHelpBtn);
        QWidget::setTabOrder(advConfigHelpBtn, advChalRespOptionsHelpBtn);
        QWidget::setTabOrder(advChalRespOptionsHelpBtn, advSecretKeyHelpBtn);

        retranslateUi(ChalRespPage);

        ChalRespPage->setCurrentIndex(2);
        quickBtn->setDefault(false);
        advBtn->setDefault(false);
        quickHelpBtn->setDefault(false);
        advHelpBtn->setDefault(false);
        quickParamGenSchemeHelpBtn->setDefault(false);
        quickConfigHelpBtn->setDefault(false);
        quickSecretKeyHelpBtn->setDefault(false);
        quickSecretKeyGenerateBtn->setDefault(false);
        quickPvtIdGenerateBtn->setDefault(false);
        quickPvtIdHelpBtn->setDefault(false);
        quickChalRespOptionsHelpBtn->setDefault(false);
        quickWriteConfigBtn->setDefault(false);
        quickStopBtn->setDefault(false);
        quickBackBtn->setDefault(false);
        quickResetBtn->setDefault(false);
        quickExportConfigBtn->setDefault(false);
        advConfigHelpBtn->setDefault(false);
        advWriteConfigBtn->setDefault(false);
        advStopBtn->setDefault(false);
        advBackBtn->setDefault(false);
        advResetBtn->setDefault(false);
        advExportConfigBtn->setDefault(false);
        advChalRespOptionsHelpBtn->setDefault(false);
        advSecretKeyGenerateBtn->setDefault(false);
        advSecretKeyHelpBtn->setDefault(false);


        QMetaObject::connectSlotsByName(ChalRespPage);
    } // setupUi

    void retranslateUi(QStackedWidget *ChalRespPage)
    {
        ChalRespPage->setWindowTitle(QApplication::translate("ChalRespPage", "StackedWidget", nullptr));
        baseHeadingLbl->setText(QApplication::translate("ChalRespPage", "Program in Challenge-Response mode", nullptr));
        baseActionsBox->setTitle(QString());
        quickBtn->setText(QApplication::translate("ChalRespPage", "Yubico OTP", nullptr));
        advBtn->setText(QApplication::translate("ChalRespPage", "HMAC-SHA1", nullptr));
        quickDescLbl->setText(QApplication::translate("ChalRespPage", "Allows you to program one or more YubiKeys in \"Yubico OTP\" Challenge-Response mode", nullptr));
        advancedDescLbl->setText(QApplication::translate("ChalRespPage", "Allows you to program one or more YubiKeys in \"HMAC-SHA1\" Challenge-Response mode", nullptr));
        quickHelpBtn->setText(QString());
        advHelpBtn->setText(QString());
        quickHeadingLbl->setText(QApplication::translate("ChalRespPage", "Program in Challenge-Response mode - Yubico OTP", nullptr));
        quickProgramMulKeysBox->setTitle(QApplication::translate("ChalRespPage", "Program Multiple YubiKeys", nullptr));
        quickAutoProgramKeysCheck->setText(QApplication::translate("ChalRespPage", "Automatically program YubiKeys when inserted", nullptr));
        quickParamGenSchemeLbl->setText(QApplication::translate("ChalRespPage", "Parameter Generation Scheme", nullptr));
        quickConfigParamsCombo->setItemText(0, QApplication::translate("ChalRespPage", "Increment Identities; Randomize Secret", nullptr));
        quickConfigParamsCombo->setItemText(1, QApplication::translate("ChalRespPage", "Randomize all parameters", nullptr));

        quickParamGenSchemeHelpBtn->setText(QString());
        quickConfigBox->setTitle(QApplication::translate("ChalRespPage", "Configuration Slot", nullptr));
        quickConfigDescLbl->setText(QApplication::translate("ChalRespPage", "Select the configuration slot to be programmed", nullptr));
        quickConfigSlot1Radio->setText(QApplication::translate("ChalRespPage", "Configuration Slot 1", nullptr));
        quickConfigSlot2Radio->setText(QApplication::translate("ChalRespPage", "Configuration Slot 2", nullptr));
        quickConfigHelpBtn->setText(QString());
        quickKeyParamsBox->setTitle(QApplication::translate("ChalRespPage", "Yubico OTP Parameters", nullptr));
        quickSecretKeyHelpBtn->setText(QString());
        quickSecretKeyTxt->setInputMask(QApplication::translate("ChalRespPage", "hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh; ", nullptr));
        quickSecretKeyTxt->setText(QApplication::translate("ChalRespPage", "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickSecretKeyGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickSecretKeyGenerateBtn->setText(QApplication::translate("ChalRespPage", "Generate", nullptr));
        quickSecretKeyLbl->setText(QApplication::translate("ChalRespPage", "Secret Key (16 bytes Hex)", nullptr));
        quickPvtIdCheck->setText(QApplication::translate("ChalRespPage", "Private Identity (6 bytes Hex)", nullptr));
        quickPvtIdTxt->setInputMask(QApplication::translate("ChalRespPage", "hh hh hh hh hh hh; ", nullptr));
        quickPvtIdTxt->setText(QApplication::translate("ChalRespPage", "00 00 00 00 00 00", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickPvtIdGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickPvtIdGenerateBtn->setText(QApplication::translate("ChalRespPage", "Generate", nullptr));
        quickPvtIdHelpBtn->setText(QString());
        quickRequireUserInputCheck->setText(QApplication::translate("ChalRespPage", "Require user input (button press)", nullptr));
        quickChalRespOptionsHelpBtn->setText(QString());
        quickActionsBox->setTitle(QApplication::translate("ChalRespPage", "Actions", nullptr));
        quickWriteConfigBtn->setText(QApplication::translate("ChalRespPage", "Write Configuration", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickStopBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickStopBtn->setText(QApplication::translate("ChalRespPage", "Stop", nullptr));
        quickActionsDescLbl->setText(QApplication::translate("ChalRespPage", "Press Write Configuration button to program your YubiKey's selected configuration slot", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickBackBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickBackBtn->setText(QApplication::translate("ChalRespPage", "Back", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickResetBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickResetBtn->setText(QApplication::translate("ChalRespPage", "Reset", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickExportConfigBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickExportConfigBtn->setText(QApplication::translate("ChalRespPage", "Export", nullptr));
        quickResultsBox->setTitle(QApplication::translate("ChalRespPage", "Results", nullptr));
        QTableWidgetItem *___qtablewidgetitem = quickResultsWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("ChalRespPage", "#", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = quickResultsWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("ChalRespPage", "Status", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = quickResultsWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("ChalRespPage", "Timestamp", nullptr));
        advHeadingLbl->setText(QApplication::translate("ChalRespPage", "Program in Challenge-Response mode - HMAC-SHA1", nullptr));
        advConfigBox->setTitle(QApplication::translate("ChalRespPage", "Configuration Slot", nullptr));
        advConfigDescLbl->setText(QApplication::translate("ChalRespPage", "Select the configuration slot to be programmed", nullptr));
        advConfigSlot1Radio->setText(QApplication::translate("ChalRespPage", "Configuration Slot 1", nullptr));
        advConfigSlot2Radio->setText(QApplication::translate("ChalRespPage", "Configuration Slot 2", nullptr));
        advConfigHelpBtn->setText(QString());
        advActionsBox->setTitle(QApplication::translate("ChalRespPage", "Actions", nullptr));
        advWriteConfigBtn->setText(QApplication::translate("ChalRespPage", "Write Configuration", nullptr));
#ifndef QT_NO_WHATSTHIS
        advStopBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advStopBtn->setText(QApplication::translate("ChalRespPage", "Stop", nullptr));
        advActionsDescLbl->setText(QApplication::translate("ChalRespPage", "Press Write Configuration button to program your YubiKey's selected configuration slot", nullptr));
#ifndef QT_NO_WHATSTHIS
        advBackBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advBackBtn->setText(QApplication::translate("ChalRespPage", "Back", nullptr));
#ifndef QT_NO_WHATSTHIS
        advResetBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advResetBtn->setText(QApplication::translate("ChalRespPage", "Reset", nullptr));
#ifndef QT_NO_WHATSTHIS
        advExportConfigBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advExportConfigBtn->setText(QApplication::translate("ChalRespPage", "Export", nullptr));
        advProgramMulKeysBox->setTitle(QApplication::translate("ChalRespPage", "Program Multiple YubiKeys", nullptr));
        advAutoProgramKeysCheck->setText(QApplication::translate("ChalRespPage", "Automatically program YubiKeys when inserted", nullptr));
        advParamGenSchemeLbl->setText(QApplication::translate("ChalRespPage", "Parameter Generation Scheme", nullptr));
        advConfigParamsCombo->setItemText(0, QApplication::translate("ChalRespPage", "Randomize Secret", nullptr));
        advConfigParamsCombo->setItemText(1, QApplication::translate("ChalRespPage", "Same Secret for all Keys", nullptr));

        advKeyParamsBox->setTitle(QApplication::translate("ChalRespPage", "HMAC-SHA1 Parameters", nullptr));
        advChalRespOptionsHelpBtn->setText(QString());
        advRequireUserInputCheck->setText(QApplication::translate("ChalRespPage", "Require user input (button press)", nullptr));
        advHmacVarInputRadio->setText(QApplication::translate("ChalRespPage", "Variable input", nullptr));
        advHmacFixedInputRadio->setText(QApplication::translate("ChalRespPage", "Fixed 64 byte input", nullptr));
        advHmacModeLbl->setText(QApplication::translate("ChalRespPage", "HMAC-SHA1 Mode", nullptr));
        advSecretKeyLbl->setText(QApplication::translate("ChalRespPage", "Secret Key (20 bytes Hex)", nullptr));
        advSecretKeyTxt->setInputMask(QApplication::translate("ChalRespPage", "hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh; ", nullptr));
        advSecretKeyTxt->setText(QApplication::translate("ChalRespPage", "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00", nullptr));
#ifndef QT_NO_WHATSTHIS
        advSecretKeyGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advSecretKeyGenerateBtn->setText(QApplication::translate("ChalRespPage", "Generate", nullptr));
        advSecretKeyHelpBtn->setText(QString());
        advResultsBox->setTitle(QApplication::translate("ChalRespPage", "Results", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = advResultsWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem3->setText(QApplication::translate("ChalRespPage", "#", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = advResultsWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem4->setText(QApplication::translate("ChalRespPage", "Status", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = advResultsWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem5->setText(QApplication::translate("ChalRespPage", "Timestamp", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ChalRespPage: public Ui_ChalRespPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHALRESPPAGE_H
