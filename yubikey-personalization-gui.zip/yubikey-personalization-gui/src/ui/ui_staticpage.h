/********************************************************************************
** Form generated from reading UI file 'staticpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATICPAGE_H
#define UI_STATICPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>
#include "yubiaccbox.h"

QT_BEGIN_NAMESPACE

class Ui_StaticPage
{
public:
    QWidget *basePage;
    QLabel *baseHeadingLbl;
    QGroupBox *baseActionsBox;
    QPushButton *quickBtn;
    QPushButton *advBtn;
    QLabel *quickDescLbl;
    QLabel *advancedDescLbl;
    QWidget *quickPage;
    QLabel *quickHeadingLbl;
    QGroupBox *quickConfigBox;
    QLabel *quickConfigDescLbl;
    QRadioButton *quickConfigSlot1Radio;
    QRadioButton *quickConfigSlot2Radio;
    QPushButton *quickConfigHelpBtn;
    QGroupBox *quickKeyParamsBox;
    QPushButton *quickStaticScanCodeHelpBtn;
    QLineEdit *quickStaticTxt;
    QLabel *quickStaticLenLbl;
    QLabel *quickStaticLbl;
    QLabel *quickBkpStaticLbl;
    QLabel *quickStaticLenDescLbl;
    QPushButton *quickStaticBkpHelpBtn;
    QPushButton *quickInsertTabBtn;
    QLabel *quickStaticLenTxt;
    QPushButton *quickClearBtn;
    QCheckBox *quickHideParams;
    QLabel *quickStaticLbl_2;
    QLineEdit *quickScanCodesTxt;
    QLabel *quickKeymapLbl;
    QComboBox *quickKeymapCmb;
    QGroupBox *quickActionsBox;
    QPushButton *quickWriteConfigBtn;
    QPushButton *quickBackBtn;
    QLabel *quickActionsDescLbl;
    QPushButton *quickResetBtn;
    QPushButton *quickStopBtn;
    QGroupBox *quickProgramMulKeysBox;
    QCheckBox *quickAutoProgramKeysCheck;
    QGroupBox *quickResultsBox;
    QTableWidget *quickResultsWidget;
    YubiAccBox *quickConfigProtectionBox;
    QWidget *advPage;
    QLabel *advHeadingLbl;
    QGroupBox *advConfigBox;
    QLabel *advConfigDescLbl;
    QRadioButton *advConfigSlot1Radio;
    QRadioButton *advConfigSlot2Radio;
    QPushButton *advConfigHelpBtn;
    QGroupBox *advKeyParamsBox;
    QPushButton *advSecretKeyHelpBtn;
    QLineEdit *advSecretKeyTxt;
    QPushButton *advSecretKeyGenerateBtn;
    QLineEdit *advPubIdTxt;
    QLineEdit *advPvtIdTxt;
    QPushButton *advPubIdGenerateBtn;
    QPushButton *advPvtIdGenerateBtn;
    QPushButton *advPubIdHelpBtn;
    QPushButton *advPvtIdHelpBtn;
    QLabel *advStaticLenLbl;
    QLabel *advSecretKeyLbl;
    QLabel *advPubIdLbl;
    QLabel *advPvtIdLbl;
    QSpinBox *advStaticLenBox;
    QLabel *advStrongPwLbl;
    QCheckBox *advStrongPw1Check;
    QCheckBox *advStrongPw2Check;
    QCheckBox *advStrongPw3Check;
    QRadioButton *advStaticLen16Radio;
    QRadioButton *advStaticLen32Radio;
    QLabel *advStaticCharsLbl;
    QLabel *advStaticLenDescLbl;
    QGroupBox *advActionsBox;
    QPushButton *advWriteConfigBtn;
    QPushButton *advStopBtn;
    QLabel *advActionsDescLbl;
    QPushButton *advBackBtn;
    QPushButton *advResetBtn;
    QGroupBox *advProgramMulKeysBox;
    QCheckBox *advAutoProgramKeysCheck;
    QLabel *advParamGenSchemeLbl;
    QComboBox *advConfigParamsCombo;
    QPushButton *advParamGenSchemeHelpBtn;
    QGroupBox *advResultsBox;
    QTableWidget *advResultsWidget;
    YubiAccBox *advConfigProtectionBox;

    void setupUi(QStackedWidget *StaticPage)
    {
        if (StaticPage->objectName().isEmpty())
            StaticPage->setObjectName(QString::fromUtf8("StaticPage"));
        StaticPage->resize(730, 650);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(StaticPage->sizePolicy().hasHeightForWidth());
        StaticPage->setSizePolicy(sizePolicy);
        StaticPage->setMaximumSize(QSize(730, 650));
        StaticPage->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        basePage = new QWidget();
        basePage->setObjectName(QString::fromUtf8("basePage"));
        baseHeadingLbl = new QLabel(basePage);
        baseHeadingLbl->setObjectName(QString::fromUtf8("baseHeadingLbl"));
        baseHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        baseHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        baseHeadingLbl->setAlignment(Qt::AlignCenter);
        baseActionsBox = new QGroupBox(basePage);
        baseActionsBox->setObjectName(QString::fromUtf8("baseActionsBox"));
        baseActionsBox->setGeometry(QRect(10, 50, 710, 171));
        baseActionsBox->setStyleSheet(QString::fromUtf8("border-color: rgb(0, 0, 0);"));
        baseActionsBox->setAlignment(Qt::AlignCenter);
        quickBtn = new QPushButton(baseActionsBox);
        quickBtn->setObjectName(QString::fromUtf8("quickBtn"));
        quickBtn->setGeometry(QRect(20, 20, 110, 25));
        sizePolicy.setHeightForWidth(quickBtn->sizePolicy().hasHeightForWidth());
        quickBtn->setSizePolicy(sizePolicy);
        quickBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickBtn->setAutoExclusive(false);
        quickBtn->setFlat(false);
        advBtn = new QPushButton(baseActionsBox);
        advBtn->setObjectName(QString::fromUtf8("advBtn"));
        advBtn->setGeometry(QRect(20, 100, 110, 25));
        advBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advBtn->setCheckable(false);
        advBtn->setChecked(false);
        quickDescLbl = new QLabel(baseActionsBox);
        quickDescLbl->setObjectName(QString::fromUtf8("quickDescLbl"));
        quickDescLbl->setGeometry(QRect(20, 45, 671, 20));
        quickDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        advancedDescLbl = new QLabel(baseActionsBox);
        advancedDescLbl->setObjectName(QString::fromUtf8("advancedDescLbl"));
        advancedDescLbl->setGeometry(QRect(20, 125, 671, 30));
        advancedDescLbl->setStyleSheet(QString::fromUtf8(""));
        advancedDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        StaticPage->addWidget(basePage);
        quickPage = new QWidget();
        quickPage->setObjectName(QString::fromUtf8("quickPage"));
        quickHeadingLbl = new QLabel(quickPage);
        quickHeadingLbl->setObjectName(QString::fromUtf8("quickHeadingLbl"));
        quickHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        quickHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        quickHeadingLbl->setAlignment(Qt::AlignCenter);
        quickConfigBox = new QGroupBox(quickPage);
        quickConfigBox->setObjectName(QString::fromUtf8("quickConfigBox"));
        quickConfigBox->setGeometry(QRect(10, 50, 711, 72));
        quickConfigBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickConfigDescLbl = new QLabel(quickConfigBox);
        quickConfigDescLbl->setObjectName(QString::fromUtf8("quickConfigDescLbl"));
        quickConfigDescLbl->setGeometry(QRect(10, 25, 691, 16));
        quickConfigDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)"));
        quickConfigSlot1Radio = new QRadioButton(quickConfigBox);
        quickConfigSlot1Radio->setObjectName(QString::fromUtf8("quickConfigSlot1Radio"));
        quickConfigSlot1Radio->setGeometry(QRect(10, 45, 151, 19));
        quickConfigSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickConfigSlot2Radio = new QRadioButton(quickConfigBox);
        quickConfigSlot2Radio->setObjectName(QString::fromUtf8("quickConfigSlot2Radio"));
        quickConfigSlot2Radio->setGeometry(QRect(240, 45, 151, 19));
        quickConfigSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickConfigHelpBtn = new QPushButton(quickConfigBox);
        quickConfigHelpBtn->setObjectName(QString::fromUtf8("quickConfigHelpBtn"));
        quickConfigHelpBtn->setGeometry(QRect(685, 45, 16, 16));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(quickConfigHelpBtn->sizePolicy().hasHeightForWidth());
        quickConfigHelpBtn->setSizePolicy(sizePolicy1);
        quickConfigHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickConfigHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickConfigHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickConfigHelpBtn->setAutoFillBackground(false);
        quickConfigHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickConfigHelpBtn->setAutoDefault(false);
        quickKeyParamsBox = new QGroupBox(quickPage);
        quickKeyParamsBox->setObjectName(QString::fromUtf8("quickKeyParamsBox"));
        quickKeyParamsBox->setGeometry(QRect(10, 240, 711, 190));
        quickKeyParamsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickKeyParamsBox->setCheckable(false);
        quickKeyParamsBox->setChecked(false);
        quickStaticScanCodeHelpBtn = new QPushButton(quickKeyParamsBox);
        quickStaticScanCodeHelpBtn->setObjectName(QString::fromUtf8("quickStaticScanCodeHelpBtn"));
        quickStaticScanCodeHelpBtn->setGeometry(QRect(685, 0, 16, 16));
        sizePolicy1.setHeightForWidth(quickStaticScanCodeHelpBtn->sizePolicy().hasHeightForWidth());
        quickStaticScanCodeHelpBtn->setSizePolicy(sizePolicy1);
        quickStaticScanCodeHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickStaticScanCodeHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickStaticScanCodeHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickStaticScanCodeHelpBtn->setAutoFillBackground(false);
        quickStaticScanCodeHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickStaticScanCodeHelpBtn->setAutoDefault(false);
        quickStaticTxt = new QLineEdit(quickKeyParamsBox);
        quickStaticTxt->setObjectName(QString::fromUtf8("quickStaticTxt"));
        quickStaticTxt->setGeometry(QRect(150, 75, 205, 20));
        sizePolicy.setHeightForWidth(quickStaticTxt->sizePolicy().hasHeightForWidth());
        quickStaticTxt->setSizePolicy(sizePolicy);
        quickStaticTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickStaticTxt->setMaxLength(76);
        quickStaticTxt->setEchoMode(QLineEdit::Normal);
        quickStaticTxt->setReadOnly(false);
        quickStaticLenLbl = new QLabel(quickKeyParamsBox);
        quickStaticLenLbl->setObjectName(QString::fromUtf8("quickStaticLenLbl"));
        quickStaticLenLbl->setGeometry(QRect(10, 50, 110, 20));
        quickStaticLenLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickStaticLbl = new QLabel(quickKeyParamsBox);
        quickStaticLbl->setObjectName(QString::fromUtf8("quickStaticLbl"));
        quickStaticLbl->setGeometry(QRect(10, 75, 110, 20));
        quickStaticLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickBkpStaticLbl = new QLabel(quickKeyParamsBox);
        quickBkpStaticLbl->setObjectName(QString::fromUtf8("quickBkpStaticLbl"));
        quickBkpStaticLbl->setGeometry(QRect(40, 146, 661, 31));
        quickBkpStaticLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;\n"
""));
        quickBkpStaticLbl->setWordWrap(true);
        quickStaticLenDescLbl = new QLabel(quickKeyParamsBox);
        quickStaticLenDescLbl->setObjectName(QString::fromUtf8("quickStaticLenDescLbl"));
        quickStaticLenDescLbl->setGeometry(QRect(180, 50, 431, 20));
        quickStaticLenDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)"));
        quickStaticBkpHelpBtn = new QPushButton(quickKeyParamsBox);
        quickStaticBkpHelpBtn->setObjectName(QString::fromUtf8("quickStaticBkpHelpBtn"));
        quickStaticBkpHelpBtn->setGeometry(QRect(10, 150, 24, 24));
        sizePolicy1.setHeightForWidth(quickStaticBkpHelpBtn->sizePolicy().hasHeightForWidth());
        quickStaticBkpHelpBtn->setSizePolicy(sizePolicy1);
        quickStaticBkpHelpBtn->setCursor(QCursor(Qt::ArrowCursor));
        quickStaticBkpHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickStaticBkpHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickStaticBkpHelpBtn->setAutoFillBackground(false);
        quickStaticBkpHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/recommend.png);\n"
"color: lightgray;\n"
"border-radius: 1px;"));
        quickStaticBkpHelpBtn->setAutoDefault(false);
        quickInsertTabBtn = new QPushButton(quickKeyParamsBox);
        quickInsertTabBtn->setObjectName(QString::fromUtf8("quickInsertTabBtn"));
        quickInsertTabBtn->setGeometry(QRect(150, 100, 111, 24));
        quickInsertTabBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickInsertTabBtn->setAutoExclusive(false);
        quickInsertTabBtn->setFlat(false);
        quickStaticLenTxt = new QLabel(quickKeyParamsBox);
        quickStaticLenTxt->setObjectName(QString::fromUtf8("quickStaticLenTxt"));
        quickStaticLenTxt->setGeometry(QRect(150, 50, 31, 20));
        quickStaticLenTxt->setStyleSheet(QString::fromUtf8(""));
        quickClearBtn = new QPushButton(quickKeyParamsBox);
        quickClearBtn->setObjectName(QString::fromUtf8("quickClearBtn"));
        quickClearBtn->setGeometry(QRect(270, 100, 85, 25));
        quickClearBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickClearBtn->setAutoExclusive(false);
        quickClearBtn->setFlat(false);
        quickHideParams = new QCheckBox(quickKeyParamsBox);
        quickHideParams->setObjectName(QString::fromUtf8("quickHideParams"));
        quickHideParams->setGeometry(QRect(10, 25, 221, 18));
        quickHideParams->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickHideParams->setChecked(false);
        quickStaticLbl_2 = new QLabel(quickKeyParamsBox);
        quickStaticLbl_2->setObjectName(QString::fromUtf8("quickStaticLbl_2"));
        quickStaticLbl_2->setGeometry(QRect(370, 75, 110, 20));
        quickStaticLbl_2->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickScanCodesTxt = new QLineEdit(quickKeyParamsBox);
        quickScanCodesTxt->setObjectName(QString::fromUtf8("quickScanCodesTxt"));
        quickScanCodesTxt->setGeometry(QRect(490, 75, 200, 20));
        QFont font;
        font.setFamily(QString::fromUtf8("Verdana"));
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        quickScanCodesTxt->setFont(font);
        quickScanCodesTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickKeymapLbl = new QLabel(quickKeyParamsBox);
        quickKeymapLbl->setObjectName(QString::fromUtf8("quickKeymapLbl"));
        quickKeymapLbl->setGeometry(QRect(490, 105, 51, 20));
        quickKeymapLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickKeymapCmb = new QComboBox(quickKeyParamsBox);
        quickKeymapCmb->addItem(QString());
        quickKeymapCmb->addItem(QString());
        quickKeymapCmb->addItem(QString());
        quickKeymapCmb->addItem(QString());
        quickKeymapCmb->addItem(QString());
        quickKeymapCmb->addItem(QString());
        quickKeymapCmb->setObjectName(QString::fromUtf8("quickKeymapCmb"));
        quickKeymapCmb->setGeometry(QRect(549, 101, 141, 22));
        sizePolicy.setHeightForWidth(quickKeymapCmb->sizePolicy().hasHeightForWidth());
        quickKeymapCmb->setSizePolicy(sizePolicy);
        quickKeymapCmb->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickActionsBox = new QGroupBox(quickPage);
        quickActionsBox->setObjectName(QString::fromUtf8("quickActionsBox"));
        quickActionsBox->setGeometry(QRect(10, 440, 711, 80));
        quickActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickWriteConfigBtn = new QPushButton(quickActionsBox);
        quickWriteConfigBtn->setObjectName(QString::fromUtf8("quickWriteConfigBtn"));
        quickWriteConfigBtn->setGeometry(QRect(10, 45, 175, 25));
        quickWriteConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickWriteConfigBtn->setAutoExclusive(false);
        quickWriteConfigBtn->setFlat(false);
        quickBackBtn = new QPushButton(quickActionsBox);
        quickBackBtn->setObjectName(QString::fromUtf8("quickBackBtn"));
        quickBackBtn->setGeometry(QRect(400, 45, 85, 25));
        quickBackBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickBackBtn->setAutoExclusive(false);
        quickBackBtn->setFlat(false);
        quickActionsDescLbl = new QLabel(quickActionsBox);
        quickActionsDescLbl->setObjectName(QString::fromUtf8("quickActionsDescLbl"));
        quickActionsDescLbl->setGeometry(QRect(10, 25, 691, 16));
        quickActionsDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        quickResetBtn = new QPushButton(quickActionsBox);
        quickResetBtn->setObjectName(QString::fromUtf8("quickResetBtn"));
        quickResetBtn->setEnabled(false);
        quickResetBtn->setGeometry(QRect(300, 45, 85, 25));
        quickResetBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickResetBtn->setAutoExclusive(false);
        quickResetBtn->setFlat(false);
        quickStopBtn = new QPushButton(quickActionsBox);
        quickStopBtn->setObjectName(QString::fromUtf8("quickStopBtn"));
        quickStopBtn->setEnabled(false);
        quickStopBtn->setGeometry(QRect(200, 45, 85, 25));
        quickStopBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickStopBtn->setAutoExclusive(false);
        quickStopBtn->setFlat(false);
        quickProgramMulKeysBox = new QGroupBox(quickPage);
        quickProgramMulKeysBox->setObjectName(QString::fromUtf8("quickProgramMulKeysBox"));
        quickProgramMulKeysBox->setGeometry(QRect(10, 132, 350, 107));
        quickProgramMulKeysBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        quickProgramMulKeysBox->setCheckable(true);
        quickProgramMulKeysBox->setChecked(false);
        quickAutoProgramKeysCheck = new QCheckBox(quickProgramMulKeysBox);
        quickAutoProgramKeysCheck->setObjectName(QString::fromUtf8("quickAutoProgramKeysCheck"));
        quickAutoProgramKeysCheck->setGeometry(QRect(10, 25, 331, 17));
        quickAutoProgramKeysCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickResultsBox = new QGroupBox(quickPage);
        quickResultsBox->setObjectName(QString::fromUtf8("quickResultsBox"));
        quickResultsBox->setGeometry(QRect(10, 520, 711, 130));
        quickResultsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickResultsWidget = new QTableWidget(quickResultsBox);
        if (quickResultsWidget->columnCount() < 4)
            quickResultsWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        quickResultsWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        quickResultsWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        quickResultsWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        quickResultsWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        quickResultsWidget->setObjectName(QString::fromUtf8("quickResultsWidget"));
        quickResultsWidget->setGeometry(QRect(12, 20, 688, 100));
        quickResultsWidget->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        quickResultsWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        quickResultsWidget->setAlternatingRowColors(true);
        quickResultsWidget->setShowGrid(false);
        quickResultsWidget->setGridStyle(Qt::SolidLine);
        quickResultsWidget->setWordWrap(true);
        quickResultsWidget->setRowCount(0);
        quickResultsWidget->setColumnCount(4);
        quickResultsWidget->horizontalHeader()->setMinimumSectionSize(50);
        quickResultsWidget->verticalHeader()->setVisible(false);
        quickResultsWidget->verticalHeader()->setDefaultSectionSize(20);
        quickConfigProtectionBox = new YubiAccBox(quickPage);
        quickConfigProtectionBox->setObjectName(QString::fromUtf8("quickConfigProtectionBox"));
        quickConfigProtectionBox->setGeometry(QRect(370, 132, 350, 117));
        StaticPage->addWidget(quickPage);
        advPage = new QWidget();
        advPage->setObjectName(QString::fromUtf8("advPage"));
        advHeadingLbl = new QLabel(advPage);
        advHeadingLbl->setObjectName(QString::fromUtf8("advHeadingLbl"));
        advHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        advHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        advHeadingLbl->setAlignment(Qt::AlignCenter);
        advConfigBox = new QGroupBox(advPage);
        advConfigBox->setObjectName(QString::fromUtf8("advConfigBox"));
        advConfigBox->setGeometry(QRect(10, 50, 711, 72));
        advConfigBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advConfigDescLbl = new QLabel(advConfigBox);
        advConfigDescLbl->setObjectName(QString::fromUtf8("advConfigDescLbl"));
        advConfigDescLbl->setGeometry(QRect(10, 25, 691, 16));
        advConfigDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        advConfigSlot1Radio = new QRadioButton(advConfigBox);
        advConfigSlot1Radio->setObjectName(QString::fromUtf8("advConfigSlot1Radio"));
        advConfigSlot1Radio->setGeometry(QRect(10, 45, 151, 19));
        advConfigSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advConfigSlot1Radio->setCheckable(true);
        advConfigSlot1Radio->setChecked(false);
        advConfigSlot2Radio = new QRadioButton(advConfigBox);
        advConfigSlot2Radio->setObjectName(QString::fromUtf8("advConfigSlot2Radio"));
        advConfigSlot2Radio->setGeometry(QRect(240, 45, 151, 19));
        advConfigSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advConfigHelpBtn = new QPushButton(advConfigBox);
        advConfigHelpBtn->setObjectName(QString::fromUtf8("advConfigHelpBtn"));
        advConfigHelpBtn->setGeometry(QRect(685, 45, 16, 16));
        sizePolicy1.setHeightForWidth(advConfigHelpBtn->sizePolicy().hasHeightForWidth());
        advConfigHelpBtn->setSizePolicy(sizePolicy1);
        advConfigHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advConfigHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advConfigHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advConfigHelpBtn->setAutoFillBackground(false);
        advConfigHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advConfigHelpBtn->setAutoDefault(false);
        advKeyParamsBox = new QGroupBox(advPage);
        advKeyParamsBox->setObjectName(QString::fromUtf8("advKeyParamsBox"));
        advKeyParamsBox->setGeometry(QRect(10, 249, 711, 161));
        advKeyParamsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advSecretKeyHelpBtn = new QPushButton(advKeyParamsBox);
        advSecretKeyHelpBtn->setObjectName(QString::fromUtf8("advSecretKeyHelpBtn"));
        advSecretKeyHelpBtn->setGeometry(QRect(685, 102, 16, 16));
        sizePolicy1.setHeightForWidth(advSecretKeyHelpBtn->sizePolicy().hasHeightForWidth());
        advSecretKeyHelpBtn->setSizePolicy(sizePolicy1);
        advSecretKeyHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advSecretKeyHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advSecretKeyHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advSecretKeyHelpBtn->setAutoFillBackground(false);
        advSecretKeyHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advSecretKeyHelpBtn->setAutoDefault(false);
        advSecretKeyTxt = new QLineEdit(advKeyParamsBox);
        advSecretKeyTxt->setObjectName(QString::fromUtf8("advSecretKeyTxt"));
        advSecretKeyTxt->setGeometry(QRect(240, 100, 330, 20));
        sizePolicy.setHeightForWidth(advSecretKeyTxt->sizePolicy().hasHeightForWidth());
        advSecretKeyTxt->setSizePolicy(sizePolicy);
        advSecretKeyTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advSecretKeyTxt->setMaxLength(47);
        advSecretKeyTxt->setCursorPosition(47);
        advSecretKeyGenerateBtn = new QPushButton(advKeyParamsBox);
        advSecretKeyGenerateBtn->setObjectName(QString::fromUtf8("advSecretKeyGenerateBtn"));
        advSecretKeyGenerateBtn->setGeometry(QRect(580, 98, 100, 24));
        advSecretKeyGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advSecretKeyGenerateBtn->setAutoExclusive(false);
        advSecretKeyGenerateBtn->setFlat(false);
        advPubIdTxt = new QLineEdit(advKeyParamsBox);
        advPubIdTxt->setObjectName(QString::fromUtf8("advPubIdTxt"));
        advPubIdTxt->setGeometry(QRect(240, 50, 330, 20));
        sizePolicy.setHeightForWidth(advPubIdTxt->sizePolicy().hasHeightForWidth());
        advPubIdTxt->setSizePolicy(sizePolicy);
        advPubIdTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advPubIdTxt->setMaxLength(0);
        advPubIdTxt->setCursorPosition(0);
        advPvtIdTxt = new QLineEdit(advKeyParamsBox);
        advPvtIdTxt->setObjectName(QString::fromUtf8("advPvtIdTxt"));
        advPvtIdTxt->setGeometry(QRect(240, 75, 330, 20));
        sizePolicy.setHeightForWidth(advPvtIdTxt->sizePolicy().hasHeightForWidth());
        advPvtIdTxt->setSizePolicy(sizePolicy);
        advPvtIdTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advPvtIdTxt->setMaxLength(17);
        advPvtIdTxt->setCursorPosition(17);
        advPubIdGenerateBtn = new QPushButton(advKeyParamsBox);
        advPubIdGenerateBtn->setObjectName(QString::fromUtf8("advPubIdGenerateBtn"));
        advPubIdGenerateBtn->setGeometry(QRect(580, 48, 100, 24));
        advPubIdGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advPubIdGenerateBtn->setAutoExclusive(false);
        advPubIdGenerateBtn->setFlat(false);
        advPvtIdGenerateBtn = new QPushButton(advKeyParamsBox);
        advPvtIdGenerateBtn->setObjectName(QString::fromUtf8("advPvtIdGenerateBtn"));
        advPvtIdGenerateBtn->setGeometry(QRect(580, 73, 100, 24));
        advPvtIdGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advPvtIdGenerateBtn->setAutoExclusive(false);
        advPvtIdGenerateBtn->setFlat(false);
        advPubIdHelpBtn = new QPushButton(advKeyParamsBox);
        advPubIdHelpBtn->setObjectName(QString::fromUtf8("advPubIdHelpBtn"));
        advPubIdHelpBtn->setGeometry(QRect(685, 52, 16, 16));
        sizePolicy1.setHeightForWidth(advPubIdHelpBtn->sizePolicy().hasHeightForWidth());
        advPubIdHelpBtn->setSizePolicy(sizePolicy1);
        advPubIdHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advPubIdHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advPubIdHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advPubIdHelpBtn->setAutoFillBackground(false);
        advPubIdHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advPubIdHelpBtn->setAutoDefault(false);
        advPvtIdHelpBtn = new QPushButton(advKeyParamsBox);
        advPvtIdHelpBtn->setObjectName(QString::fromUtf8("advPvtIdHelpBtn"));
        advPvtIdHelpBtn->setGeometry(QRect(685, 77, 16, 16));
        sizePolicy1.setHeightForWidth(advPvtIdHelpBtn->sizePolicy().hasHeightForWidth());
        advPvtIdHelpBtn->setSizePolicy(sizePolicy1);
        advPvtIdHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advPvtIdHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advPvtIdHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advPvtIdHelpBtn->setAutoFillBackground(false);
        advPvtIdHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advPvtIdHelpBtn->setAutoDefault(false);
        advStaticLenLbl = new QLabel(advKeyParamsBox);
        advStaticLenLbl->setObjectName(QString::fromUtf8("advStaticLenLbl"));
        advStaticLenLbl->setGeometry(QRect(10, 25, 221, 20));
        advStaticLenLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advSecretKeyLbl = new QLabel(advKeyParamsBox);
        advSecretKeyLbl->setObjectName(QString::fromUtf8("advSecretKeyLbl"));
        advSecretKeyLbl->setGeometry(QRect(10, 100, 221, 20));
        advSecretKeyLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advPubIdLbl = new QLabel(advKeyParamsBox);
        advPubIdLbl->setObjectName(QString::fromUtf8("advPubIdLbl"));
        advPubIdLbl->setGeometry(QRect(10, 50, 221, 20));
        advPubIdLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advPvtIdLbl = new QLabel(advKeyParamsBox);
        advPvtIdLbl->setObjectName(QString::fromUtf8("advPvtIdLbl"));
        advPvtIdLbl->setGeometry(QRect(10, 75, 221, 20));
        advPvtIdLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advStaticLenBox = new QSpinBox(advKeyParamsBox);
        advStaticLenBox->setObjectName(QString::fromUtf8("advStaticLenBox"));
        advStaticLenBox->setGeometry(QRect(360, 23, 42, 20));
        advStaticLenBox->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advStaticLenBox->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        advStaticLenBox->setCorrectionMode(QAbstractSpinBox::CorrectToNearestValue);
        advStaticLenBox->setMinimum(32);
        advStaticLenBox->setMaximum(64);
        advStaticLenBox->setSingleStep(2);
        advStaticLenBox->setValue(32);
        advStrongPwLbl = new QLabel(advKeyParamsBox);
        advStrongPwLbl->setObjectName(QString::fromUtf8("advStrongPwLbl"));
        advStrongPwLbl->setGeometry(QRect(10, 125, 221, 20));
        advStrongPwLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advStrongPw1Check = new QCheckBox(advKeyParamsBox);
        advStrongPw1Check->setObjectName(QString::fromUtf8("advStrongPw1Check"));
        advStrongPw1Check->setGeometry(QRect(240, 130, 147, 17));
        advStrongPw1Check->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advStrongPw2Check = new QCheckBox(advKeyParamsBox);
        advStrongPw2Check->setObjectName(QString::fromUtf8("advStrongPw2Check"));
        advStrongPw2Check->setGeometry(QRect(410, 130, 101, 17));
        advStrongPw2Check->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advStrongPw3Check = new QCheckBox(advKeyParamsBox);
        advStrongPw3Check->setObjectName(QString::fromUtf8("advStrongPw3Check"));
        advStrongPw3Check->setGeometry(QRect(540, 130, 157, 17));
        advStrongPw3Check->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advStaticLen16Radio = new QRadioButton(advKeyParamsBox);
        advStaticLen16Radio->setObjectName(QString::fromUtf8("advStaticLen16Radio"));
        advStaticLen16Radio->setGeometry(QRect(240, 25, 72, 17));
        advStaticLen16Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advStaticLen16Radio->setCheckable(true);
        advStaticLen16Radio->setChecked(false);
        advStaticLen32Radio = new QRadioButton(advKeyParamsBox);
        advStaticLen32Radio->setObjectName(QString::fromUtf8("advStaticLen32Radio"));
        advStaticLen32Radio->setGeometry(QRect(340, 25, 17, 17));
        advStaticLen32Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advStaticLen32Radio->setChecked(true);
        advStaticCharsLbl = new QLabel(advKeyParamsBox);
        advStaticCharsLbl->setObjectName(QString::fromUtf8("advStaticCharsLbl"));
        advStaticCharsLbl->setGeometry(QRect(410, 25, 31, 20));
        advStaticCharsLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advStaticLenDescLbl = new QLabel(advKeyParamsBox);
        advStaticLenDescLbl->setObjectName(QString::fromUtf8("advStaticLenDescLbl"));
        advStaticLenDescLbl->setGeometry(QRect(450, 25, 251, 20));
        advStaticLenDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)"));
        advActionsBox = new QGroupBox(advPage);
        advActionsBox->setObjectName(QString::fromUtf8("advActionsBox"));
        advActionsBox->setGeometry(QRect(10, 421, 711, 80));
        advActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        advWriteConfigBtn = new QPushButton(advActionsBox);
        advWriteConfigBtn->setObjectName(QString::fromUtf8("advWriteConfigBtn"));
        advWriteConfigBtn->setGeometry(QRect(10, 45, 175, 25));
        advWriteConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advWriteConfigBtn->setAutoExclusive(false);
        advWriteConfigBtn->setFlat(false);
        advStopBtn = new QPushButton(advActionsBox);
        advStopBtn->setObjectName(QString::fromUtf8("advStopBtn"));
        advStopBtn->setEnabled(false);
        advStopBtn->setGeometry(QRect(200, 45, 85, 25));
        advStopBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advStopBtn->setAutoExclusive(false);
        advStopBtn->setFlat(false);
        advActionsDescLbl = new QLabel(advActionsBox);
        advActionsDescLbl->setObjectName(QString::fromUtf8("advActionsDescLbl"));
        advActionsDescLbl->setGeometry(QRect(20, 20, 691, 16));
        advActionsDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        advBackBtn = new QPushButton(advActionsBox);
        advBackBtn->setObjectName(QString::fromUtf8("advBackBtn"));
        advBackBtn->setGeometry(QRect(400, 45, 85, 25));
        advBackBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advBackBtn->setAutoExclusive(false);
        advBackBtn->setFlat(false);
        advResetBtn = new QPushButton(advActionsBox);
        advResetBtn->setObjectName(QString::fromUtf8("advResetBtn"));
        advResetBtn->setEnabled(false);
        advResetBtn->setGeometry(QRect(300, 45, 85, 25));
        advResetBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advResetBtn->setAutoExclusive(false);
        advResetBtn->setFlat(false);
        advProgramMulKeysBox = new QGroupBox(advPage);
        advProgramMulKeysBox->setObjectName(QString::fromUtf8("advProgramMulKeysBox"));
        advProgramMulKeysBox->setGeometry(QRect(10, 132, 350, 107));
        advProgramMulKeysBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advProgramMulKeysBox->setCheckable(true);
        advProgramMulKeysBox->setChecked(false);
        advAutoProgramKeysCheck = new QCheckBox(advProgramMulKeysBox);
        advAutoProgramKeysCheck->setObjectName(QString::fromUtf8("advAutoProgramKeysCheck"));
        advAutoProgramKeysCheck->setGeometry(QRect(10, 25, 331, 17));
        advAutoProgramKeysCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advParamGenSchemeLbl = new QLabel(advProgramMulKeysBox);
        advParamGenSchemeLbl->setObjectName(QString::fromUtf8("advParamGenSchemeLbl"));
        advParamGenSchemeLbl->setGeometry(QRect(10, 52, 191, 20));
        advParamGenSchemeLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advParamGenSchemeLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        advConfigParamsCombo = new QComboBox(advProgramMulKeysBox);
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->setObjectName(QString::fromUtf8("advConfigParamsCombo"));
        advConfigParamsCombo->setGeometry(QRect(10, 75, 331, 22));
        sizePolicy.setHeightForWidth(advConfigParamsCombo->sizePolicy().hasHeightForWidth());
        advConfigParamsCombo->setSizePolicy(sizePolicy);
        advConfigParamsCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advParamGenSchemeHelpBtn = new QPushButton(advProgramMulKeysBox);
        advParamGenSchemeHelpBtn->setObjectName(QString::fromUtf8("advParamGenSchemeHelpBtn"));
        advParamGenSchemeHelpBtn->setGeometry(QRect(325, 52, 16, 16));
        sizePolicy1.setHeightForWidth(advParamGenSchemeHelpBtn->sizePolicy().hasHeightForWidth());
        advParamGenSchemeHelpBtn->setSizePolicy(sizePolicy1);
        advParamGenSchemeHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advParamGenSchemeHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advParamGenSchemeHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advParamGenSchemeHelpBtn->setAutoFillBackground(false);
        advParamGenSchemeHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advParamGenSchemeHelpBtn->setAutoDefault(false);
        advResultsBox = new QGroupBox(advPage);
        advResultsBox->setObjectName(QString::fromUtf8("advResultsBox"));
        advResultsBox->setGeometry(QRect(10, 511, 711, 130));
        advResultsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        advResultsWidget = new QTableWidget(advResultsBox);
        if (advResultsWidget->columnCount() < 5)
            advResultsWidget->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(0, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(1, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(2, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(3, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(4, __qtablewidgetitem8);
        advResultsWidget->setObjectName(QString::fromUtf8("advResultsWidget"));
        advResultsWidget->setGeometry(QRect(12, 20, 688, 100));
        advResultsWidget->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        advResultsWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        advResultsWidget->setAlternatingRowColors(true);
        advResultsWidget->setShowGrid(false);
        advResultsWidget->setGridStyle(Qt::SolidLine);
        advResultsWidget->setWordWrap(true);
        advResultsWidget->setRowCount(0);
        advResultsWidget->setColumnCount(5);
        advResultsWidget->horizontalHeader()->setMinimumSectionSize(50);
        advResultsWidget->verticalHeader()->setVisible(false);
        advResultsWidget->verticalHeader()->setDefaultSectionSize(20);
        advConfigProtectionBox = new YubiAccBox(advPage);
        advConfigProtectionBox->setObjectName(QString::fromUtf8("advConfigProtectionBox"));
        advConfigProtectionBox->setGeometry(QRect(370, 132, 350, 117));
        StaticPage->addWidget(advPage);
        QWidget::setTabOrder(quickBtn, advBtn);
        QWidget::setTabOrder(advBtn, quickConfigSlot1Radio);
        QWidget::setTabOrder(quickConfigSlot1Radio, quickConfigSlot2Radio);
        QWidget::setTabOrder(quickConfigSlot2Radio, quickProgramMulKeysBox);
        QWidget::setTabOrder(quickProgramMulKeysBox, quickAutoProgramKeysCheck);
        QWidget::setTabOrder(quickAutoProgramKeysCheck, quickHideParams);
        QWidget::setTabOrder(quickHideParams, quickStaticTxt);
        QWidget::setTabOrder(quickStaticTxt, quickInsertTabBtn);
        QWidget::setTabOrder(quickInsertTabBtn, quickClearBtn);
        QWidget::setTabOrder(quickClearBtn, quickWriteConfigBtn);
        QWidget::setTabOrder(quickWriteConfigBtn, quickStopBtn);
        QWidget::setTabOrder(quickStopBtn, quickResetBtn);
        QWidget::setTabOrder(quickResetBtn, quickBackBtn);
        QWidget::setTabOrder(quickBackBtn, quickResultsWidget);
        QWidget::setTabOrder(quickResultsWidget, quickConfigHelpBtn);
        QWidget::setTabOrder(quickConfigHelpBtn, quickStaticScanCodeHelpBtn);
        QWidget::setTabOrder(quickStaticScanCodeHelpBtn, quickStaticBkpHelpBtn);
        QWidget::setTabOrder(quickStaticBkpHelpBtn, advConfigSlot1Radio);
        QWidget::setTabOrder(advConfigSlot1Radio, advConfigSlot2Radio);
        QWidget::setTabOrder(advConfigSlot2Radio, advProgramMulKeysBox);
        QWidget::setTabOrder(advProgramMulKeysBox, advAutoProgramKeysCheck);
        QWidget::setTabOrder(advAutoProgramKeysCheck, advConfigParamsCombo);
        QWidget::setTabOrder(advConfigParamsCombo, advStaticLen16Radio);
        QWidget::setTabOrder(advStaticLen16Radio, advStaticLen32Radio);
        QWidget::setTabOrder(advStaticLen32Radio, advStaticLenBox);
        QWidget::setTabOrder(advStaticLenBox, advPubIdTxt);
        QWidget::setTabOrder(advPubIdTxt, advPubIdGenerateBtn);
        QWidget::setTabOrder(advPubIdGenerateBtn, advPvtIdTxt);
        QWidget::setTabOrder(advPvtIdTxt, advPvtIdGenerateBtn);
        QWidget::setTabOrder(advPvtIdGenerateBtn, advSecretKeyTxt);
        QWidget::setTabOrder(advSecretKeyTxt, advSecretKeyGenerateBtn);
        QWidget::setTabOrder(advSecretKeyGenerateBtn, advStrongPw1Check);
        QWidget::setTabOrder(advStrongPw1Check, advStrongPw2Check);
        QWidget::setTabOrder(advStrongPw2Check, advStrongPw3Check);
        QWidget::setTabOrder(advStrongPw3Check, advWriteConfigBtn);
        QWidget::setTabOrder(advWriteConfigBtn, advStopBtn);
        QWidget::setTabOrder(advStopBtn, advResetBtn);
        QWidget::setTabOrder(advResetBtn, advBackBtn);
        QWidget::setTabOrder(advBackBtn, advResultsWidget);
        QWidget::setTabOrder(advResultsWidget, advConfigHelpBtn);
        QWidget::setTabOrder(advConfigHelpBtn, advParamGenSchemeHelpBtn);
        QWidget::setTabOrder(advParamGenSchemeHelpBtn, advPubIdHelpBtn);
        QWidget::setTabOrder(advPubIdHelpBtn, advPvtIdHelpBtn);
        QWidget::setTabOrder(advPvtIdHelpBtn, advSecretKeyHelpBtn);

        retranslateUi(StaticPage);

        StaticPage->setCurrentIndex(1);
        quickBtn->setDefault(false);
        advBtn->setDefault(false);
        quickConfigHelpBtn->setDefault(false);
        quickStaticScanCodeHelpBtn->setDefault(false);
        quickStaticBkpHelpBtn->setDefault(false);
        quickInsertTabBtn->setDefault(false);
        quickClearBtn->setDefault(false);
        quickWriteConfigBtn->setDefault(false);
        quickBackBtn->setDefault(false);
        quickResetBtn->setDefault(false);
        quickStopBtn->setDefault(false);
        advConfigHelpBtn->setDefault(false);
        advSecretKeyHelpBtn->setDefault(false);
        advSecretKeyGenerateBtn->setDefault(false);
        advPubIdGenerateBtn->setDefault(false);
        advPvtIdGenerateBtn->setDefault(false);
        advPubIdHelpBtn->setDefault(false);
        advPvtIdHelpBtn->setDefault(false);
        advWriteConfigBtn->setDefault(false);
        advStopBtn->setDefault(false);
        advBackBtn->setDefault(false);
        advResetBtn->setDefault(false);
        advParamGenSchemeHelpBtn->setDefault(false);


        QMetaObject::connectSlotsByName(StaticPage);
    } // setupUi

    void retranslateUi(QStackedWidget *StaticPage)
    {
        StaticPage->setWindowTitle(QApplication::translate("StaticPage", "StackedWidget", nullptr));
        baseHeadingLbl->setText(QApplication::translate("StaticPage", "Program in Static Password mode", nullptr));
        baseActionsBox->setTitle(QString());
        quickBtn->setText(QApplication::translate("StaticPage", "Scan Code", nullptr));
        advBtn->setText(QApplication::translate("StaticPage", "Advanced", nullptr));
        quickDescLbl->setText(QApplication::translate("StaticPage", "Quickly program a YubiKey to emit your desired static password", nullptr));
        advancedDescLbl->setText(QApplication::translate("StaticPage", "Allows you to program one or more YubiKeys to emit long, \"hard to guess and remember\" static passwords", nullptr));
        quickHeadingLbl->setText(QApplication::translate("StaticPage", "Program in Static Password mode - Scan Code", nullptr));
        quickConfigBox->setTitle(QApplication::translate("StaticPage", "Configuration Slot", nullptr));
        quickConfigDescLbl->setText(QApplication::translate("StaticPage", "Select the configuration slot to be programmed", nullptr));
        quickConfigSlot1Radio->setText(QApplication::translate("StaticPage", "Configuration Slot 1", nullptr));
        quickConfigSlot2Radio->setText(QApplication::translate("StaticPage", "Configuration Slot 2", nullptr));
        quickConfigHelpBtn->setText(QString());
        quickKeyParamsBox->setTitle(QApplication::translate("StaticPage", "Password", nullptr));
        quickStaticScanCodeHelpBtn->setText(QString());
        quickStaticTxt->setInputMask(QString());
        quickStaticTxt->setText(QString());
        quickStaticLenLbl->setText(QApplication::translate("StaticPage", "Password Length", nullptr));
        quickStaticLbl->setText(QApplication::translate("StaticPage", "Password", nullptr));
        quickBkpStaticLbl->setText(QApplication::translate("StaticPage", "It is strongly recommended to create a backup YubiKey with same password in case original YubiKey is lost/broken", nullptr));
        quickStaticLenDescLbl->setText(QApplication::translate("StaticPage", "(Max. 38 chars for YubiKey 2.2+ and 16 chars for 2.0 and 2.1)", nullptr));
        quickStaticBkpHelpBtn->setText(QString());
#ifndef QT_NO_WHATSTHIS
        quickInsertTabBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickInsertTabBtn->setText(QApplication::translate("StaticPage", "Insert Tab", nullptr));
        quickStaticLenTxt->setText(QApplication::translate("StaticPage", "0", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickClearBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickClearBtn->setText(QApplication::translate("StaticPage", "Clear", nullptr));
        quickHideParams->setText(QApplication::translate("StaticPage", "Hide Password", nullptr));
        quickStaticLbl_2->setText(QApplication::translate("StaticPage", "Scan codes", nullptr));
        quickKeymapLbl->setText(QApplication::translate("StaticPage", "Keyboard", nullptr));
        quickKeymapCmb->setItemText(0, QApplication::translate("StaticPage", "Choose a layout ...", nullptr));
        quickKeymapCmb->setItemText(1, QApplication::translate("StaticPage", "US Keyboard", nullptr));
        quickKeymapCmb->setItemText(2, QApplication::translate("StaticPage", "DE Keyboard", nullptr));
        quickKeymapCmb->setItemText(3, QApplication::translate("StaticPage", "B\303\211PO Keyboard", nullptr));
        quickKeymapCmb->setItemText(4, QApplication::translate("StaticPage", "FR Keyboard", nullptr));
        quickKeymapCmb->setItemText(5, QApplication::translate("StaticPage", "IT Keyboard", nullptr));

        quickActionsBox->setTitle(QApplication::translate("StaticPage", "Actions", nullptr));
        quickWriteConfigBtn->setText(QApplication::translate("StaticPage", "Write Configuration", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickBackBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickBackBtn->setText(QApplication::translate("StaticPage", "Back", nullptr));
        quickActionsDescLbl->setText(QApplication::translate("StaticPage", "Press Write Configuration button to program your YubiKey's selected configuration slot", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickResetBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickResetBtn->setText(QApplication::translate("StaticPage", "Reset", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickStopBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickStopBtn->setText(QApplication::translate("StaticPage", "Stop", nullptr));
        quickProgramMulKeysBox->setTitle(QApplication::translate("StaticPage", "Program Multiple YubiKeys", nullptr));
        quickAutoProgramKeysCheck->setText(QApplication::translate("StaticPage", "Automatically program YubiKeys when inserted", nullptr));
        quickResultsBox->setTitle(QApplication::translate("StaticPage", "Results", nullptr));
        QTableWidgetItem *___qtablewidgetitem = quickResultsWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("StaticPage", "#", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = quickResultsWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("StaticPage", "Password Length", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = quickResultsWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("StaticPage", "Status", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = quickResultsWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("StaticPage", "Timestamp", nullptr));
        advHeadingLbl->setText(QApplication::translate("StaticPage", "Program in Static Password mode - Advanced", nullptr));
        advConfigBox->setTitle(QApplication::translate("StaticPage", "Configuration Slot", nullptr));
        advConfigDescLbl->setText(QApplication::translate("StaticPage", "Select the configuration slot to be programmed", nullptr));
        advConfigSlot1Radio->setText(QApplication::translate("StaticPage", "Configuration Slot 1", nullptr));
        advConfigSlot2Radio->setText(QApplication::translate("StaticPage", "Configuration Slot 2", nullptr));
        advConfigHelpBtn->setText(QString());
        advKeyParamsBox->setTitle(QApplication::translate("StaticPage", "Password Parameters", nullptr));
        advSecretKeyHelpBtn->setText(QString());
        advSecretKeyTxt->setInputMask(QApplication::translate("StaticPage", "hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh", nullptr));
        advSecretKeyTxt->setText(QApplication::translate("StaticPage", "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00", nullptr));
#ifndef QT_NO_WHATSTHIS
        advSecretKeyGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advSecretKeyGenerateBtn->setText(QApplication::translate("StaticPage", "Generate", nullptr));
        advPubIdTxt->setInputMask(QString());
        advPubIdTxt->setText(QString());
        advPvtIdTxt->setInputMask(QApplication::translate("StaticPage", "hh hh hh hh hh hh", nullptr));
        advPvtIdTxt->setText(QApplication::translate("StaticPage", "00 00 00 00 00 00", nullptr));
#ifndef QT_NO_WHATSTHIS
        advPubIdGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advPubIdGenerateBtn->setText(QApplication::translate("StaticPage", "Generate", nullptr));
#ifndef QT_NO_WHATSTHIS
        advPvtIdGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advPvtIdGenerateBtn->setText(QApplication::translate("StaticPage", "Generate", nullptr));
        advPubIdHelpBtn->setText(QString());
        advPvtIdHelpBtn->setText(QString());
        advStaticLenLbl->setText(QApplication::translate("StaticPage", "Password Length", nullptr));
        advSecretKeyLbl->setText(QApplication::translate("StaticPage", "Secret Key (16 bytes Hex)", nullptr));
        advPubIdLbl->setText(QApplication::translate("StaticPage", "Public Identity (1-16 bytes Modhex)", nullptr));
        advPvtIdLbl->setText(QApplication::translate("StaticPage", "Private Identity (6 bytes Hex)", nullptr));
        advStaticLenBox->setSuffix(QString());
        advStaticLenBox->setPrefix(QString());
        advStrongPwLbl->setText(QApplication::translate("StaticPage", "Strong Password Policy", nullptr));
        advStrongPw1Check->setText(QApplication::translate("StaticPage", "Upper and lower case", nullptr));
        advStrongPw2Check->setText(QApplication::translate("StaticPage", "Alphanumeric", nullptr));
        advStrongPw3Check->setText(QApplication::translate("StaticPage", "Send ! as prefix", nullptr));
        advStaticLen16Radio->setText(QApplication::translate("StaticPage", "16 chars", nullptr));
        advStaticLen32Radio->setText(QString());
        advStaticCharsLbl->setText(QApplication::translate("StaticPage", "chars", nullptr));
        advStaticLenDescLbl->setText(QApplication::translate("StaticPage", "(16 chars for YubiKey 2.0 and above only)", nullptr));
        advActionsBox->setTitle(QApplication::translate("StaticPage", "Actions", nullptr));
        advWriteConfigBtn->setText(QApplication::translate("StaticPage", "Write Configuration", nullptr));
#ifndef QT_NO_WHATSTHIS
        advStopBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advStopBtn->setText(QApplication::translate("StaticPage", "Stop", nullptr));
        advActionsDescLbl->setText(QApplication::translate("StaticPage", "Press Write Configuration button to program your YubiKey's selected configuration slot", nullptr));
#ifndef QT_NO_WHATSTHIS
        advBackBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advBackBtn->setText(QApplication::translate("StaticPage", "Back", nullptr));
#ifndef QT_NO_WHATSTHIS
        advResetBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advResetBtn->setText(QApplication::translate("StaticPage", "Reset", nullptr));
        advProgramMulKeysBox->setTitle(QApplication::translate("StaticPage", "Program Multiple YubiKeys", nullptr));
        advAutoProgramKeysCheck->setText(QApplication::translate("StaticPage", "Automatically program YubiKeys when inserted", nullptr));
        advParamGenSchemeLbl->setText(QApplication::translate("StaticPage", "Parameter Generation Scheme", nullptr));
        advConfigParamsCombo->setItemText(0, QApplication::translate("StaticPage", "Increment Identities; Randomize Secret", nullptr));
        advConfigParamsCombo->setItemText(1, QApplication::translate("StaticPage", "Randomize all parameters", nullptr));
        advConfigParamsCombo->setItemText(2, QApplication::translate("StaticPage", "Fixed parameters", nullptr));

        advParamGenSchemeHelpBtn->setText(QString());
        advResultsBox->setTitle(QApplication::translate("StaticPage", "Results", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = advResultsWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem4->setText(QApplication::translate("StaticPage", "#", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = advResultsWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem5->setText(QApplication::translate("StaticPage", "Password Length", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = advResultsWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem6->setText(QApplication::translate("StaticPage", "Public Identity (Modhex)", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = advResultsWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem7->setText(QApplication::translate("StaticPage", "Status", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = advResultsWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem8->setText(QApplication::translate("StaticPage", "Timestamp", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StaticPage: public Ui_StaticPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATICPAGE_H
