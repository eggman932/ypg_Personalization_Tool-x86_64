/********************************************************************************
** Form generated from reading UI file 'oathpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OATHPAGE_H
#define UI_OATHPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>
#include "yubiaccbox.h"

QT_BEGIN_NAMESPACE

class Ui_OathPage
{
public:
    QWidget *basePage;
    QLabel *baseHeadingLbl;
    QGroupBox *baseActionsBox;
    QPushButton *quickBtn;
    QPushButton *advBtn;
    QLabel *quickDescLbl;
    QLabel *advancedDescLbl;
    QWidget *quickPage;
    QLabel *quickHeadingLbl;
    QGroupBox *quickConfigBox;
    QLabel *quickConfigDescLbl;
    QRadioButton *quickConfigSlot1Radio;
    QRadioButton *quickConfigSlot2Radio;
    QPushButton *quickConfigHelpBtn;
    QGroupBox *quickKeyParamsBox;
    QPushButton *quickHotpLenHelpBtn;
    QPushButton *quickPubIdHelpBtn;
    QPushButton *quickSecretKeyHelpBtn;
    QLabel *quickHotpLenLbl;
    QLineEdit *quickMUITxt;
    QLineEdit *quickSecretKeyTxt;
    QCheckBox *quickHideParams;
    QRadioButton *quickHotpLen6Radio;
    QRadioButton *quickHotpLen8Radio;
    QLabel *quickSecretKeyLbl;
    QCheckBox *quickPubIdCheck;
    QPushButton *quickMUIGenerateBtn;
    QLabel *quickPrefixTxt;
    QGroupBox *quickActionsBox;
    QPushButton *quickWriteConfigBtn;
    QPushButton *quickBackBtn;
    QLabel *quickActionsDescLbl;
    QPushButton *quickResetBtn;
    QWidget *advPage;
    QLabel *advHeadingLbl;
    QGroupBox *advConfigBox;
    QLabel *advConfigDescLbl;
    QRadioButton *advConfigSlot1Radio;
    QRadioButton *advConfigSlot2Radio;
    QPushButton *advConfigHelpBtn;
    QGroupBox *advKeyParamsBox;
    QPushButton *advSecretKeyHelpBtn;
    QLineEdit *advSecretKeyTxt;
    QPushButton *advSecretKeyGenerateBtn;
    QComboBox *advPubIdFormatCombo;
    QLineEdit *advMUITxt;
    QLineEdit *advTTTxt;
    QLineEdit *advOMPTxt;
    QPushButton *advMUIGenerateBtn;
    QLabel *advSecretKeyLbl;
    QCheckBox *advPubIdCheck;
    QLabel *advHotpLenLbl;
    QRadioButton *advHotpLen8Radio;
    QRadioButton *advHotpLen6Radio;
    QLabel *advMovingFactorSeedLbl;
    QComboBox *advMovingFactorSeedCombo;
    QLineEdit *advMovingFactorSeedTxt;
    QPushButton *advPubIdHelpBtn;
    QPushButton *advHotpParamsHelpBtn;
    QLabel *advPubIdDescLbl;
    QPushButton *advHotpLenHelpBtn;
    QGroupBox *advActionsBox;
    QPushButton *advWriteConfigBtn;
    QPushButton *advStopBtn;
    QLabel *advActionsDescLbl;
    QPushButton *advBackBtn;
    QPushButton *advResetBtn;
    QPushButton *advExportConfigBtn;
    QGroupBox *advProgramMulKeysBox;
    QCheckBox *advAutoProgramKeysCheck;
    QComboBox *advConfigParamsCombo;
    QLabel *advParamGenSchemeLbl;
    QPushButton *advParamGenSchemeHelpBtn;
    QGroupBox *advResultsBox;
    QTableWidget *advResultsWidget;
    YubiAccBox *advConfigProtectionBox;

    void setupUi(QStackedWidget *OathPage)
    {
        if (OathPage->objectName().isEmpty())
            OathPage->setObjectName(QString::fromUtf8("OathPage"));
        OathPage->resize(730, 650);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(OathPage->sizePolicy().hasHeightForWidth());
        OathPage->setSizePolicy(sizePolicy);
        OathPage->setMaximumSize(QSize(730, 650));
        OathPage->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        basePage = new QWidget();
        basePage->setObjectName(QString::fromUtf8("basePage"));
        baseHeadingLbl = new QLabel(basePage);
        baseHeadingLbl->setObjectName(QString::fromUtf8("baseHeadingLbl"));
        baseHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        baseHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        baseHeadingLbl->setAlignment(Qt::AlignCenter);
        baseActionsBox = new QGroupBox(basePage);
        baseActionsBox->setObjectName(QString::fromUtf8("baseActionsBox"));
        baseActionsBox->setGeometry(QRect(10, 50, 710, 171));
        baseActionsBox->setStyleSheet(QString::fromUtf8("border-color: rgb(0, 0, 0);"));
        baseActionsBox->setAlignment(Qt::AlignCenter);
        quickBtn = new QPushButton(baseActionsBox);
        quickBtn->setObjectName(QString::fromUtf8("quickBtn"));
        quickBtn->setGeometry(QRect(20, 20, 110, 25));
        sizePolicy.setHeightForWidth(quickBtn->sizePolicy().hasHeightForWidth());
        quickBtn->setSizePolicy(sizePolicy);
        quickBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickBtn->setAutoExclusive(false);
        quickBtn->setFlat(false);
        advBtn = new QPushButton(baseActionsBox);
        advBtn->setObjectName(QString::fromUtf8("advBtn"));
        advBtn->setGeometry(QRect(20, 100, 110, 25));
        advBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advBtn->setCheckable(false);
        advBtn->setChecked(false);
        quickDescLbl = new QLabel(baseActionsBox);
        quickDescLbl->setObjectName(QString::fromUtf8("quickDescLbl"));
        quickDescLbl->setGeometry(QRect(20, 45, 671, 20));
        quickDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        advancedDescLbl = new QLabel(baseActionsBox);
        advancedDescLbl->setObjectName(QString::fromUtf8("advancedDescLbl"));
        advancedDescLbl->setGeometry(QRect(20, 125, 671, 30));
        advancedDescLbl->setStyleSheet(QString::fromUtf8(""));
        advancedDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        OathPage->addWidget(basePage);
        quickPage = new QWidget();
        quickPage->setObjectName(QString::fromUtf8("quickPage"));
        quickHeadingLbl = new QLabel(quickPage);
        quickHeadingLbl->setObjectName(QString::fromUtf8("quickHeadingLbl"));
        quickHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        quickHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        quickHeadingLbl->setAlignment(Qt::AlignCenter);
        quickConfigBox = new QGroupBox(quickPage);
        quickConfigBox->setObjectName(QString::fromUtf8("quickConfigBox"));
        quickConfigBox->setGeometry(QRect(10, 50, 711, 72));
        quickConfigBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickConfigDescLbl = new QLabel(quickConfigBox);
        quickConfigDescLbl->setObjectName(QString::fromUtf8("quickConfigDescLbl"));
        quickConfigDescLbl->setGeometry(QRect(10, 25, 291, 16));
        quickConfigDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)"));
        quickConfigSlot1Radio = new QRadioButton(quickConfigBox);
        quickConfigSlot1Radio->setObjectName(QString::fromUtf8("quickConfigSlot1Radio"));
        quickConfigSlot1Radio->setGeometry(QRect(10, 45, 151, 19));
        quickConfigSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickConfigSlot2Radio = new QRadioButton(quickConfigBox);
        quickConfigSlot2Radio->setObjectName(QString::fromUtf8("quickConfigSlot2Radio"));
        quickConfigSlot2Radio->setGeometry(QRect(240, 45, 151, 19));
        quickConfigSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickConfigHelpBtn = new QPushButton(quickConfigBox);
        quickConfigHelpBtn->setObjectName(QString::fromUtf8("quickConfigHelpBtn"));
        quickConfigHelpBtn->setGeometry(QRect(685, 45, 16, 16));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(quickConfigHelpBtn->sizePolicy().hasHeightForWidth());
        quickConfigHelpBtn->setSizePolicy(sizePolicy1);
        quickConfigHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickConfigHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickConfigHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickConfigHelpBtn->setAutoFillBackground(false);
        quickConfigHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickConfigHelpBtn->setAutoDefault(false);
        quickKeyParamsBox = new QGroupBox(quickPage);
        quickKeyParamsBox->setObjectName(QString::fromUtf8("quickKeyParamsBox"));
        quickKeyParamsBox->setGeometry(QRect(10, 132, 711, 130));
        quickKeyParamsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickKeyParamsBox->setCheckable(false);
        quickKeyParamsBox->setChecked(false);
        quickHotpLenHelpBtn = new QPushButton(quickKeyParamsBox);
        quickHotpLenHelpBtn->setObjectName(QString::fromUtf8("quickHotpLenHelpBtn"));
        quickHotpLenHelpBtn->setGeometry(QRect(685, 50, 16, 16));
        sizePolicy1.setHeightForWidth(quickHotpLenHelpBtn->sizePolicy().hasHeightForWidth());
        quickHotpLenHelpBtn->setSizePolicy(sizePolicy1);
        quickHotpLenHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickHotpLenHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickHotpLenHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickHotpLenHelpBtn->setAutoFillBackground(false);
        quickHotpLenHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickHotpLenHelpBtn->setAutoDefault(false);
        quickPubIdHelpBtn = new QPushButton(quickKeyParamsBox);
        quickPubIdHelpBtn->setObjectName(QString::fromUtf8("quickPubIdHelpBtn"));
        quickPubIdHelpBtn->setGeometry(QRect(685, 27, 16, 16));
        sizePolicy1.setHeightForWidth(quickPubIdHelpBtn->sizePolicy().hasHeightForWidth());
        quickPubIdHelpBtn->setSizePolicy(sizePolicy1);
        quickPubIdHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickPubIdHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickPubIdHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickPubIdHelpBtn->setAutoFillBackground(false);
        quickPubIdHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickPubIdHelpBtn->setAutoDefault(false);
        quickSecretKeyHelpBtn = new QPushButton(quickKeyParamsBox);
        quickSecretKeyHelpBtn->setObjectName(QString::fromUtf8("quickSecretKeyHelpBtn"));
        quickSecretKeyHelpBtn->setGeometry(QRect(685, 100, 16, 16));
        sizePolicy1.setHeightForWidth(quickSecretKeyHelpBtn->sizePolicy().hasHeightForWidth());
        quickSecretKeyHelpBtn->setSizePolicy(sizePolicy1);
        quickSecretKeyHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        quickSecretKeyHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        quickSecretKeyHelpBtn->setLayoutDirection(Qt::LeftToRight);
        quickSecretKeyHelpBtn->setAutoFillBackground(false);
        quickSecretKeyHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        quickSecretKeyHelpBtn->setAutoDefault(false);
        quickHotpLenLbl = new QLabel(quickKeyParamsBox);
        quickHotpLenLbl->setObjectName(QString::fromUtf8("quickHotpLenLbl"));
        quickHotpLenLbl->setGeometry(QRect(10, 50, 221, 20));
        quickHotpLenLbl->setTextFormat(Qt::RichText);
        quickMUITxt = new QLineEdit(quickKeyParamsBox);
        quickMUITxt->setObjectName(QString::fromUtf8("quickMUITxt"));
        quickMUITxt->setEnabled(true);
        quickMUITxt->setGeometry(QRect(280, 25, 181, 20));
        sizePolicy.setHeightForWidth(quickMUITxt->sizePolicy().hasHeightForWidth());
        quickMUITxt->setSizePolicy(sizePolicy);
        quickMUITxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickMUITxt->setEchoMode(QLineEdit::Normal);
        quickMUITxt->setCursorPosition(11);
        quickMUITxt->setReadOnly(false);
        quickSecretKeyTxt = new QLineEdit(quickKeyParamsBox);
        quickSecretKeyTxt->setObjectName(QString::fromUtf8("quickSecretKeyTxt"));
        quickSecretKeyTxt->setEnabled(true);
        quickSecretKeyTxt->setGeometry(QRect(240, 100, 371, 20));
        quickSecretKeyTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickSecretKeyTxt->setEchoMode(QLineEdit::Password);
        quickSecretKeyTxt->setCursorPosition(59);
        quickSecretKeyTxt->setReadOnly(true);
        quickHideParams = new QCheckBox(quickKeyParamsBox);
        quickHideParams->setObjectName(QString::fromUtf8("quickHideParams"));
        quickHideParams->setGeometry(QRect(10, 75, 221, 18));
        quickHideParams->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickHideParams->setChecked(true);
        quickHotpLen6Radio = new QRadioButton(quickKeyParamsBox);
        quickHotpLen6Radio->setObjectName(QString::fromUtf8("quickHotpLen6Radio"));
        quickHotpLen6Radio->setGeometry(QRect(240, 51, 71, 17));
        quickHotpLen6Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickHotpLen6Radio->setCheckable(true);
        quickHotpLen6Radio->setChecked(true);
        quickHotpLen8Radio = new QRadioButton(quickKeyParamsBox);
        quickHotpLen8Radio->setObjectName(QString::fromUtf8("quickHotpLen8Radio"));
        quickHotpLen8Radio->setGeometry(QRect(320, 51, 71, 17));
        quickHotpLen8Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickHotpLen8Radio->setCheckable(true);
        quickHotpLen8Radio->setChecked(false);
        quickSecretKeyLbl = new QLabel(quickKeyParamsBox);
        quickSecretKeyLbl->setObjectName(QString::fromUtf8("quickSecretKeyLbl"));
        quickSecretKeyLbl->setGeometry(QRect(10, 100, 221, 20));
        quickSecretKeyLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        quickPubIdCheck = new QCheckBox(quickKeyParamsBox);
        quickPubIdCheck->setObjectName(QString::fromUtf8("quickPubIdCheck"));
        quickPubIdCheck->setGeometry(QRect(10, 25, 221, 17));
        quickPubIdCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        quickMUIGenerateBtn = new QPushButton(quickKeyParamsBox);
        quickMUIGenerateBtn->setObjectName(QString::fromUtf8("quickMUIGenerateBtn"));
        quickMUIGenerateBtn->setGeometry(QRect(470, 23, 141, 24));
        quickMUIGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickMUIGenerateBtn->setAutoExclusive(false);
        quickMUIGenerateBtn->setFlat(false);
        quickPrefixTxt = new QLabel(quickKeyParamsBox);
        quickPrefixTxt->setObjectName(QString::fromUtf8("quickPrefixTxt"));
        quickPrefixTxt->setGeometry(QRect(240, 25, 41, 20));
        quickPrefixTxt->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickActionsBox = new QGroupBox(quickPage);
        quickActionsBox->setObjectName(QString::fromUtf8("quickActionsBox"));
        quickActionsBox->setGeometry(QRect(10, 272, 711, 80));
        quickActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        quickWriteConfigBtn = new QPushButton(quickActionsBox);
        quickWriteConfigBtn->setObjectName(QString::fromUtf8("quickWriteConfigBtn"));
        quickWriteConfigBtn->setGeometry(QRect(10, 45, 175, 25));
        quickWriteConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickWriteConfigBtn->setAutoExclusive(false);
        quickWriteConfigBtn->setFlat(false);
        quickBackBtn = new QPushButton(quickActionsBox);
        quickBackBtn->setObjectName(QString::fromUtf8("quickBackBtn"));
        quickBackBtn->setGeometry(QRect(335, 45, 85, 25));
        quickBackBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickBackBtn->setAutoExclusive(false);
        quickBackBtn->setFlat(false);
        quickActionsDescLbl = new QLabel(quickActionsBox);
        quickActionsDescLbl->setObjectName(QString::fromUtf8("quickActionsDescLbl"));
        quickActionsDescLbl->setGeometry(QRect(10, 25, 691, 16));
        quickActionsDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        quickResetBtn = new QPushButton(quickActionsBox);
        quickResetBtn->setObjectName(QString::fromUtf8("quickResetBtn"));
        quickResetBtn->setEnabled(true);
        quickResetBtn->setGeometry(QRect(200, 45, 120, 25));
        quickResetBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        quickResetBtn->setAutoExclusive(false);
        quickResetBtn->setFlat(false);
        OathPage->addWidget(quickPage);
        advPage = new QWidget();
        advPage->setObjectName(QString::fromUtf8("advPage"));
        advHeadingLbl = new QLabel(advPage);
        advHeadingLbl->setObjectName(QString::fromUtf8("advHeadingLbl"));
        advHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        advHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        advHeadingLbl->setAlignment(Qt::AlignCenter);
        advConfigBox = new QGroupBox(advPage);
        advConfigBox->setObjectName(QString::fromUtf8("advConfigBox"));
        advConfigBox->setGeometry(QRect(10, 50, 711, 72));
        advConfigBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advConfigDescLbl = new QLabel(advConfigBox);
        advConfigDescLbl->setObjectName(QString::fromUtf8("advConfigDescLbl"));
        advConfigDescLbl->setGeometry(QRect(10, 25, 331, 16));
        advConfigDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        advConfigSlot1Radio = new QRadioButton(advConfigBox);
        advConfigSlot1Radio->setObjectName(QString::fromUtf8("advConfigSlot1Radio"));
        advConfigSlot1Radio->setGeometry(QRect(10, 45, 151, 19));
        advConfigSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advConfigSlot1Radio->setCheckable(true);
        advConfigSlot1Radio->setChecked(false);
        advConfigSlot2Radio = new QRadioButton(advConfigBox);
        advConfigSlot2Radio->setObjectName(QString::fromUtf8("advConfigSlot2Radio"));
        advConfigSlot2Radio->setGeometry(QRect(240, 45, 151, 19));
        advConfigSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advConfigHelpBtn = new QPushButton(advConfigBox);
        advConfigHelpBtn->setObjectName(QString::fromUtf8("advConfigHelpBtn"));
        advConfigHelpBtn->setGeometry(QRect(685, 45, 16, 16));
        sizePolicy1.setHeightForWidth(advConfigHelpBtn->sizePolicy().hasHeightForWidth());
        advConfigHelpBtn->setSizePolicy(sizePolicy1);
        advConfigHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advConfigHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advConfigHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advConfigHelpBtn->setAutoFillBackground(false);
        advConfigHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advConfigHelpBtn->setAutoDefault(false);
        advKeyParamsBox = new QGroupBox(advPage);
        advKeyParamsBox->setObjectName(QString::fromUtf8("advKeyParamsBox"));
        advKeyParamsBox->setGeometry(QRect(10, 249, 711, 157));
        advKeyParamsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advSecretKeyHelpBtn = new QPushButton(advKeyParamsBox);
        advSecretKeyHelpBtn->setObjectName(QString::fromUtf8("advSecretKeyHelpBtn"));
        advSecretKeyHelpBtn->setGeometry(QRect(685, 127, 16, 16));
        sizePolicy1.setHeightForWidth(advSecretKeyHelpBtn->sizePolicy().hasHeightForWidth());
        advSecretKeyHelpBtn->setSizePolicy(sizePolicy1);
        advSecretKeyHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advSecretKeyHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advSecretKeyHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advSecretKeyHelpBtn->setAutoFillBackground(false);
        advSecretKeyHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advSecretKeyHelpBtn->setAutoDefault(false);
        advSecretKeyTxt = new QLineEdit(advKeyParamsBox);
        advSecretKeyTxt->setObjectName(QString::fromUtf8("advSecretKeyTxt"));
        advSecretKeyTxt->setGeometry(QRect(240, 125, 330, 20));
        sizePolicy.setHeightForWidth(advSecretKeyTxt->sizePolicy().hasHeightForWidth());
        advSecretKeyTxt->setSizePolicy(sizePolicy);
        advSecretKeyTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advSecretKeyTxt->setMaxLength(59);
        advSecretKeyTxt->setCursorPosition(59);
        advSecretKeyGenerateBtn = new QPushButton(advKeyParamsBox);
        advSecretKeyGenerateBtn->setObjectName(QString::fromUtf8("advSecretKeyGenerateBtn"));
        advSecretKeyGenerateBtn->setGeometry(QRect(580, 123, 100, 24));
        advSecretKeyGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advSecretKeyGenerateBtn->setAutoExclusive(false);
        advSecretKeyGenerateBtn->setFlat(false);
        advPubIdFormatCombo = new QComboBox(advKeyParamsBox);
        advPubIdFormatCombo->addItem(QString());
        advPubIdFormatCombo->addItem(QString());
        advPubIdFormatCombo->addItem(QString());
        advPubIdFormatCombo->addItem(QString());
        advPubIdFormatCombo->setObjectName(QString::fromUtf8("advPubIdFormatCombo"));
        advPubIdFormatCombo->setGeometry(QRect(240, 25, 330, 20));
        sizePolicy.setHeightForWidth(advPubIdFormatCombo->sizePolicy().hasHeightForWidth());
        advPubIdFormatCombo->setSizePolicy(sizePolicy);
        advPubIdFormatCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advMUITxt = new QLineEdit(advKeyParamsBox);
        advMUITxt->setObjectName(QString::fromUtf8("advMUITxt"));
        advMUITxt->setGeometry(QRect(320, 50, 111, 20));
        sizePolicy.setHeightForWidth(advMUITxt->sizePolicy().hasHeightForWidth());
        advMUITxt->setSizePolicy(sizePolicy);
        advMUITxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advMUITxt->setMaxLength(11);
        advMUITxt->setCursorPosition(11);
        advTTTxt = new QLineEdit(advKeyParamsBox);
        advTTTxt->setObjectName(QString::fromUtf8("advTTTxt"));
        advTTTxt->setGeometry(QRect(281, 50, 30, 20));
        sizePolicy.setHeightForWidth(advTTTxt->sizePolicy().hasHeightForWidth());
        advTTTxt->setSizePolicy(sizePolicy);
        advTTTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advTTTxt->setMaxLength(2);
        advTTTxt->setCursorPosition(2);
        advOMPTxt = new QLineEdit(advKeyParamsBox);
        advOMPTxt->setObjectName(QString::fromUtf8("advOMPTxt"));
        advOMPTxt->setGeometry(QRect(241, 50, 30, 20));
        sizePolicy.setHeightForWidth(advOMPTxt->sizePolicy().hasHeightForWidth());
        advOMPTxt->setSizePolicy(sizePolicy);
        advOMPTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advOMPTxt->setMaxLength(2);
        advOMPTxt->setCursorPosition(2);
        advMUIGenerateBtn = new QPushButton(advKeyParamsBox);
        advMUIGenerateBtn->setObjectName(QString::fromUtf8("advMUIGenerateBtn"));
        advMUIGenerateBtn->setGeometry(QRect(440, 48, 130, 24));
        advMUIGenerateBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advMUIGenerateBtn->setAutoExclusive(false);
        advMUIGenerateBtn->setFlat(false);
        advSecretKeyLbl = new QLabel(advKeyParamsBox);
        advSecretKeyLbl->setObjectName(QString::fromUtf8("advSecretKeyLbl"));
        advSecretKeyLbl->setGeometry(QRect(10, 125, 221, 20));
        advSecretKeyLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advPubIdCheck = new QCheckBox(advKeyParamsBox);
        advPubIdCheck->setObjectName(QString::fromUtf8("advPubIdCheck"));
        advPubIdCheck->setGeometry(QRect(10, 25, 221, 17));
        advPubIdCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advHotpLenLbl = new QLabel(advKeyParamsBox);
        advHotpLenLbl->setObjectName(QString::fromUtf8("advHotpLenLbl"));
        advHotpLenLbl->setGeometry(QRect(10, 75, 221, 20));
        advHotpLenLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advHotpLen8Radio = new QRadioButton(advKeyParamsBox);
        advHotpLen8Radio->setObjectName(QString::fromUtf8("advHotpLen8Radio"));
        advHotpLen8Radio->setGeometry(QRect(320, 76, 71, 17));
        advHotpLen8Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advHotpLen8Radio->setCheckable(true);
        advHotpLen8Radio->setChecked(false);
        advHotpLen6Radio = new QRadioButton(advKeyParamsBox);
        advHotpLen6Radio->setObjectName(QString::fromUtf8("advHotpLen6Radio"));
        advHotpLen6Radio->setGeometry(QRect(240, 76, 71, 17));
        advHotpLen6Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advHotpLen6Radio->setCheckable(true);
        advHotpLen6Radio->setChecked(true);
        advMovingFactorSeedLbl = new QLabel(advKeyParamsBox);
        advMovingFactorSeedLbl->setObjectName(QString::fromUtf8("advMovingFactorSeedLbl"));
        advMovingFactorSeedLbl->setGeometry(QRect(10, 100, 221, 20));
        advMovingFactorSeedLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advMovingFactorSeedCombo = new QComboBox(advKeyParamsBox);
        advMovingFactorSeedCombo->addItem(QString());
        advMovingFactorSeedCombo->addItem(QString());
        advMovingFactorSeedCombo->addItem(QString());
        advMovingFactorSeedCombo->setObjectName(QString::fromUtf8("advMovingFactorSeedCombo"));
        advMovingFactorSeedCombo->setGeometry(QRect(240, 99, 191, 20));
        sizePolicy.setHeightForWidth(advMovingFactorSeedCombo->sizePolicy().hasHeightForWidth());
        advMovingFactorSeedCombo->setSizePolicy(sizePolicy);
        advMovingFactorSeedCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advMovingFactorSeedTxt = new QLineEdit(advKeyParamsBox);
        advMovingFactorSeedTxt->setObjectName(QString::fromUtf8("advMovingFactorSeedTxt"));
        advMovingFactorSeedTxt->setEnabled(false);
        advMovingFactorSeedTxt->setGeometry(QRect(440, 99, 130, 20));
        advMovingFactorSeedTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advMovingFactorSeedTxt->setMaxLength(8);
        advMovingFactorSeedTxt->setCursorPosition(8);
        advPubIdHelpBtn = new QPushButton(advKeyParamsBox);
        advPubIdHelpBtn->setObjectName(QString::fromUtf8("advPubIdHelpBtn"));
        advPubIdHelpBtn->setGeometry(QRect(685, 27, 16, 16));
        sizePolicy1.setHeightForWidth(advPubIdHelpBtn->sizePolicy().hasHeightForWidth());
        advPubIdHelpBtn->setSizePolicy(sizePolicy1);
        advPubIdHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advPubIdHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advPubIdHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advPubIdHelpBtn->setAutoFillBackground(false);
        advPubIdHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advPubIdHelpBtn->setAutoDefault(false);
        advHotpParamsHelpBtn = new QPushButton(advKeyParamsBox);
        advHotpParamsHelpBtn->setObjectName(QString::fromUtf8("advHotpParamsHelpBtn"));
        advHotpParamsHelpBtn->setGeometry(QRect(685, 102, 16, 16));
        sizePolicy1.setHeightForWidth(advHotpParamsHelpBtn->sizePolicy().hasHeightForWidth());
        advHotpParamsHelpBtn->setSizePolicy(sizePolicy1);
        advHotpParamsHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advHotpParamsHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advHotpParamsHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advHotpParamsHelpBtn->setAutoFillBackground(false);
        advHotpParamsHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advHotpParamsHelpBtn->setAutoDefault(false);
        advPubIdDescLbl = new QLabel(advKeyParamsBox);
        advPubIdDescLbl->setObjectName(QString::fromUtf8("advPubIdDescLbl"));
        advPubIdDescLbl->setGeometry(QRect(10, 50, 221, 16));
        advPubIdDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        advHotpLenHelpBtn = new QPushButton(advKeyParamsBox);
        advHotpLenHelpBtn->setObjectName(QString::fromUtf8("advHotpLenHelpBtn"));
        advHotpLenHelpBtn->setGeometry(QRect(685, 77, 16, 16));
        sizePolicy1.setHeightForWidth(advHotpLenHelpBtn->sizePolicy().hasHeightForWidth());
        advHotpLenHelpBtn->setSizePolicy(sizePolicy1);
        advHotpLenHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advHotpLenHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advHotpLenHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advHotpLenHelpBtn->setAutoFillBackground(false);
        advHotpLenHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advHotpLenHelpBtn->setAutoDefault(false);
        advActionsBox = new QGroupBox(advPage);
        advActionsBox->setObjectName(QString::fromUtf8("advActionsBox"));
        advActionsBox->setGeometry(QRect(10, 416, 711, 80));
        advActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        advWriteConfigBtn = new QPushButton(advActionsBox);
        advWriteConfigBtn->setObjectName(QString::fromUtf8("advWriteConfigBtn"));
        advWriteConfigBtn->setGeometry(QRect(10, 45, 175, 25));
        advWriteConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advWriteConfigBtn->setAutoExclusive(false);
        advWriteConfigBtn->setFlat(false);
        advStopBtn = new QPushButton(advActionsBox);
        advStopBtn->setObjectName(QString::fromUtf8("advStopBtn"));
        advStopBtn->setEnabled(false);
        advStopBtn->setGeometry(QRect(200, 45, 85, 25));
        advStopBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advStopBtn->setAutoExclusive(false);
        advStopBtn->setFlat(false);
        advActionsDescLbl = new QLabel(advActionsBox);
        advActionsDescLbl->setObjectName(QString::fromUtf8("advActionsDescLbl"));
        advActionsDescLbl->setGeometry(QRect(10, 25, 691, 16));
        advActionsDescLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)\n"
""));
        advBackBtn = new QPushButton(advActionsBox);
        advBackBtn->setObjectName(QString::fromUtf8("advBackBtn"));
        advBackBtn->setGeometry(QRect(400, 45, 85, 25));
        advBackBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advBackBtn->setAutoExclusive(false);
        advBackBtn->setFlat(false);
        advResetBtn = new QPushButton(advActionsBox);
        advResetBtn->setObjectName(QString::fromUtf8("advResetBtn"));
        advResetBtn->setEnabled(true);
        advResetBtn->setGeometry(QRect(300, 45, 85, 25));
        advResetBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advResetBtn->setAutoExclusive(false);
        advResetBtn->setFlat(false);
        advExportConfigBtn = new QPushButton(advActionsBox);
        advExportConfigBtn->setObjectName(QString::fromUtf8("advExportConfigBtn"));
        advExportConfigBtn->setGeometry(QRect(580, 45, 100, 25));
        advExportConfigBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        advExportConfigBtn->setAutoExclusive(false);
        advExportConfigBtn->setFlat(false);
        advProgramMulKeysBox = new QGroupBox(advPage);
        advProgramMulKeysBox->setObjectName(QString::fromUtf8("advProgramMulKeysBox"));
        advProgramMulKeysBox->setGeometry(QRect(10, 132, 350, 107));
        advProgramMulKeysBox->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
""));
        advProgramMulKeysBox->setCheckable(true);
        advProgramMulKeysBox->setChecked(false);
        advAutoProgramKeysCheck = new QCheckBox(advProgramMulKeysBox);
        advAutoProgramKeysCheck->setObjectName(QString::fromUtf8("advAutoProgramKeysCheck"));
        advAutoProgramKeysCheck->setGeometry(QRect(10, 25, 331, 17));
        advAutoProgramKeysCheck->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advConfigParamsCombo = new QComboBox(advProgramMulKeysBox);
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->addItem(QString());
        advConfigParamsCombo->setObjectName(QString::fromUtf8("advConfigParamsCombo"));
        advConfigParamsCombo->setGeometry(QRect(10, 75, 331, 22));
        sizePolicy.setHeightForWidth(advConfigParamsCombo->sizePolicy().hasHeightForWidth());
        advConfigParamsCombo->setSizePolicy(sizePolicy);
        advConfigParamsCombo->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        advParamGenSchemeLbl = new QLabel(advProgramMulKeysBox);
        advParamGenSchemeLbl->setObjectName(QString::fromUtf8("advParamGenSchemeLbl"));
        advParamGenSchemeLbl->setGeometry(QRect(10, 52, 191, 20));
        advParamGenSchemeLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        advParamGenSchemeLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        advParamGenSchemeHelpBtn = new QPushButton(advProgramMulKeysBox);
        advParamGenSchemeHelpBtn->setObjectName(QString::fromUtf8("advParamGenSchemeHelpBtn"));
        advParamGenSchemeHelpBtn->setGeometry(QRect(325, 52, 16, 16));
        sizePolicy1.setHeightForWidth(advParamGenSchemeHelpBtn->sizePolicy().hasHeightForWidth());
        advParamGenSchemeHelpBtn->setSizePolicy(sizePolicy1);
        advParamGenSchemeHelpBtn->setCursor(QCursor(Qt::PointingHandCursor));
        advParamGenSchemeHelpBtn->setContextMenuPolicy(Qt::DefaultContextMenu);
        advParamGenSchemeHelpBtn->setLayoutDirection(Qt::LeftToRight);
        advParamGenSchemeHelpBtn->setAutoFillBackground(false);
        advParamGenSchemeHelpBtn->setStyleSheet(QString::fromUtf8("background-image: url(:/res/images/question.png);\n"
"color: lightgray;\n"
"border-radius: 10px;\n"
""));
        advParamGenSchemeHelpBtn->setAutoDefault(false);
        advResultsBox = new QGroupBox(advPage);
        advResultsBox->setObjectName(QString::fromUtf8("advResultsBox"));
        advResultsBox->setGeometry(QRect(10, 506, 711, 130));
        advResultsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        advResultsWidget = new QTableWidget(advResultsBox);
        if (advResultsWidget->columnCount() < 4)
            advResultsWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        advResultsWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        advResultsWidget->setObjectName(QString::fromUtf8("advResultsWidget"));
        advResultsWidget->setGeometry(QRect(12, 20, 688, 100));
        advResultsWidget->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        advResultsWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        advResultsWidget->setAlternatingRowColors(true);
        advResultsWidget->setShowGrid(false);
        advResultsWidget->setGridStyle(Qt::SolidLine);
        advResultsWidget->setWordWrap(true);
        advResultsWidget->setRowCount(0);
        advResultsWidget->setColumnCount(4);
        advResultsWidget->horizontalHeader()->setMinimumSectionSize(50);
        advResultsWidget->verticalHeader()->setVisible(false);
        advResultsWidget->verticalHeader()->setDefaultSectionSize(20);
        advConfigProtectionBox = new YubiAccBox(advPage);
        advConfigProtectionBox->setObjectName(QString::fromUtf8("advConfigProtectionBox"));
        advConfigProtectionBox->setGeometry(QRect(370, 132, 350, 117));
        OathPage->addWidget(advPage);
        QWidget::setTabOrder(quickBtn, advBtn);
        QWidget::setTabOrder(advBtn, quickConfigSlot1Radio);
        QWidget::setTabOrder(quickConfigSlot1Radio, quickConfigSlot2Radio);
        QWidget::setTabOrder(quickConfigSlot2Radio, quickPubIdCheck);
        QWidget::setTabOrder(quickPubIdCheck, quickMUITxt);
        QWidget::setTabOrder(quickMUITxt, quickMUIGenerateBtn);
        QWidget::setTabOrder(quickMUIGenerateBtn, quickHotpLen6Radio);
        QWidget::setTabOrder(quickHotpLen6Radio, quickHotpLen8Radio);
        QWidget::setTabOrder(quickHotpLen8Radio, quickHideParams);
        QWidget::setTabOrder(quickHideParams, quickSecretKeyTxt);
        QWidget::setTabOrder(quickSecretKeyTxt, quickWriteConfigBtn);
        QWidget::setTabOrder(quickWriteConfigBtn, quickResetBtn);
        QWidget::setTabOrder(quickResetBtn, quickBackBtn);
        QWidget::setTabOrder(quickBackBtn, quickConfigHelpBtn);
        QWidget::setTabOrder(quickConfigHelpBtn, quickPubIdHelpBtn);
        QWidget::setTabOrder(quickPubIdHelpBtn, quickHotpLenHelpBtn);
        QWidget::setTabOrder(quickHotpLenHelpBtn, quickSecretKeyHelpBtn);
        QWidget::setTabOrder(quickSecretKeyHelpBtn, advConfigSlot1Radio);
        QWidget::setTabOrder(advConfigSlot1Radio, advConfigSlot2Radio);
        QWidget::setTabOrder(advConfigSlot2Radio, advProgramMulKeysBox);
        QWidget::setTabOrder(advProgramMulKeysBox, advAutoProgramKeysCheck);
        QWidget::setTabOrder(advAutoProgramKeysCheck, advConfigParamsCombo);
        QWidget::setTabOrder(advConfigParamsCombo, advPubIdCheck);
        QWidget::setTabOrder(advPubIdCheck, advPubIdFormatCombo);
        QWidget::setTabOrder(advPubIdFormatCombo, advOMPTxt);
        QWidget::setTabOrder(advOMPTxt, advTTTxt);
        QWidget::setTabOrder(advTTTxt, advMUITxt);
        QWidget::setTabOrder(advMUITxt, advMUIGenerateBtn);
        QWidget::setTabOrder(advMUIGenerateBtn, advHotpLen6Radio);
        QWidget::setTabOrder(advHotpLen6Radio, advHotpLen8Radio);
        QWidget::setTabOrder(advHotpLen8Radio, advMovingFactorSeedCombo);
        QWidget::setTabOrder(advMovingFactorSeedCombo, advMovingFactorSeedTxt);
        QWidget::setTabOrder(advMovingFactorSeedTxt, advSecretKeyTxt);
        QWidget::setTabOrder(advSecretKeyTxt, advSecretKeyGenerateBtn);
        QWidget::setTabOrder(advSecretKeyGenerateBtn, advWriteConfigBtn);
        QWidget::setTabOrder(advWriteConfigBtn, advStopBtn);
        QWidget::setTabOrder(advStopBtn, advResetBtn);
        QWidget::setTabOrder(advResetBtn, advBackBtn);
        QWidget::setTabOrder(advBackBtn, advResultsWidget);
        QWidget::setTabOrder(advResultsWidget, advConfigHelpBtn);
        QWidget::setTabOrder(advConfigHelpBtn, advParamGenSchemeHelpBtn);
        QWidget::setTabOrder(advParamGenSchemeHelpBtn, advPubIdHelpBtn);
        QWidget::setTabOrder(advPubIdHelpBtn, advHotpLenHelpBtn);
        QWidget::setTabOrder(advHotpLenHelpBtn, advHotpParamsHelpBtn);
        QWidget::setTabOrder(advHotpParamsHelpBtn, advSecretKeyHelpBtn);

        retranslateUi(OathPage);

        OathPage->setCurrentIndex(2);
        quickBtn->setDefault(false);
        advBtn->setDefault(false);
        quickConfigHelpBtn->setDefault(false);
        quickHotpLenHelpBtn->setDefault(false);
        quickPubIdHelpBtn->setDefault(false);
        quickSecretKeyHelpBtn->setDefault(false);
        quickMUIGenerateBtn->setDefault(false);
        quickWriteConfigBtn->setDefault(false);
        quickBackBtn->setDefault(false);
        quickResetBtn->setDefault(false);
        advConfigHelpBtn->setDefault(false);
        advSecretKeyHelpBtn->setDefault(false);
        advSecretKeyGenerateBtn->setDefault(false);
        advMUIGenerateBtn->setDefault(false);
        advPubIdHelpBtn->setDefault(false);
        advHotpParamsHelpBtn->setDefault(false);
        advHotpLenHelpBtn->setDefault(false);
        advWriteConfigBtn->setDefault(false);
        advStopBtn->setDefault(false);
        advBackBtn->setDefault(false);
        advResetBtn->setDefault(false);
        advExportConfigBtn->setDefault(false);
        advParamGenSchemeHelpBtn->setDefault(false);


        QMetaObject::connectSlotsByName(OathPage);
    } // setupUi

    void retranslateUi(QStackedWidget *OathPage)
    {
        OathPage->setWindowTitle(QApplication::translate("OathPage", "StackedWidget", nullptr));
        baseHeadingLbl->setText(QApplication::translate("OathPage", "Program in OATH-HOTP mode", nullptr));
        baseActionsBox->setTitle(QString());
        quickBtn->setText(QApplication::translate("OathPage", "Quick", nullptr));
        advBtn->setText(QApplication::translate("OathPage", "Advanced", nullptr));
        quickDescLbl->setText(QApplication::translate("OathPage", "Quickly program a YubiKey in OATH-HOTP mode", nullptr));
        advancedDescLbl->setText(QApplication::translate("OathPage", "Allows you to program one or more YubiKeys in OATH-HOTP mode with greater control over the configuration values", nullptr));
        quickHeadingLbl->setText(QApplication::translate("OathPage", "Program in OATH-HOTP mode - Quick", nullptr));
        quickConfigBox->setTitle(QApplication::translate("OathPage", "Configuration Slot", nullptr));
        quickConfigDescLbl->setText(QApplication::translate("OathPage", "Select the configuration slot to be programmed", nullptr));
        quickConfigSlot1Radio->setText(QApplication::translate("OathPage", "Configuration Slot 1", nullptr));
        quickConfigSlot2Radio->setText(QApplication::translate("OathPage", "Configuration Slot 2", nullptr));
        quickConfigHelpBtn->setText(QString());
        quickKeyParamsBox->setTitle(QApplication::translate("OathPage", "OATH-HOTP Parameters (auto generated)", nullptr));
        quickHotpLenHelpBtn->setText(QString());
        quickPubIdHelpBtn->setText(QString());
        quickSecretKeyHelpBtn->setText(QString());
        quickHotpLenLbl->setText(QApplication::translate("OathPage", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Verdana'; font-weight:600; font-style:normal;\">\n"
"<table border=\"0\" style=\"-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;\">\n"
"<tr>\n"
"<td style=\"border: none;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:400;\">HOTP Length</span></p></td></tr></table></body></html>", nullptr));
        quickMUITxt->setInputMask(QApplication::translate("OathPage", "00 00 00 00; ", nullptr));
        quickMUITxt->setText(QString());
        quickSecretKeyTxt->setInputMask(QApplication::translate("OathPage", "hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh; ", nullptr));
        quickSecretKeyTxt->setText(QString());
        quickHideParams->setText(QApplication::translate("OathPage", "Hide secret", nullptr));
        quickHotpLen6Radio->setText(QApplication::translate("OathPage", "6 Digits", nullptr));
        quickHotpLen8Radio->setText(QApplication::translate("OathPage", "8 Digits", nullptr));
        quickSecretKeyLbl->setText(QApplication::translate("OathPage", "Secret Key (20 bytes Hex)", nullptr));
        quickPubIdCheck->setText(QApplication::translate("OathPage", "OATH Token Identifier (6 bytes)", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickMUIGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickMUIGenerateBtn->setText(QApplication::translate("OathPage", "Generate MUI", nullptr));
        quickPrefixTxt->setText(QString());
        quickActionsBox->setTitle(QApplication::translate("OathPage", "Actions", nullptr));
        quickWriteConfigBtn->setText(QApplication::translate("OathPage", "Write Configuration", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickBackBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickBackBtn->setText(QApplication::translate("OathPage", "Back", nullptr));
        quickActionsDescLbl->setText(QApplication::translate("OathPage", "Press Write Configuration button to program your YubiKey's selected configuration slot", nullptr));
#ifndef QT_NO_WHATSTHIS
        quickResetBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        quickResetBtn->setText(QApplication::translate("OathPage", "Regenerate", nullptr));
        advHeadingLbl->setText(QApplication::translate("OathPage", "Program in OATH-HOTP mode - Advanced", nullptr));
        advConfigBox->setTitle(QApplication::translate("OathPage", "Configuration Slot", nullptr));
        advConfigDescLbl->setText(QApplication::translate("OathPage", "Select the configuration slot to be programmed", nullptr));
        advConfigSlot1Radio->setText(QApplication::translate("OathPage", "Configuration Slot 1", nullptr));
        advConfigSlot2Radio->setText(QApplication::translate("OathPage", "Configuration Slot 2", nullptr));
        advConfigHelpBtn->setText(QString());
        advKeyParamsBox->setTitle(QApplication::translate("OathPage", "OATH-HOTP Parameters", nullptr));
        advSecretKeyHelpBtn->setText(QString());
        advSecretKeyTxt->setInputMask(QApplication::translate("OathPage", "hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh hh; ", nullptr));
        advSecretKeyTxt->setText(QApplication::translate("OathPage", "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00", nullptr));
#ifndef QT_NO_WHATSTHIS
        advSecretKeyGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advSecretKeyGenerateBtn->setText(QApplication::translate("OathPage", "Generate", nullptr));
        advPubIdFormatCombo->setItemText(0, QApplication::translate("OathPage", "All numeric", nullptr));
        advPubIdFormatCombo->setItemText(1, QApplication::translate("OathPage", "OMP Modhex, rest numeric", nullptr));
        advPubIdFormatCombo->setItemText(2, QApplication::translate("OathPage", "OMP + TT Modhex, rest numeric", nullptr));
        advPubIdFormatCombo->setItemText(3, QApplication::translate("OathPage", "All Modhex", nullptr));

        advMUITxt->setInputMask(QApplication::translate("OathPage", "nn nn nn nn; ", nullptr));
        advMUITxt->setText(QApplication::translate("OathPage", "00 00 00 00", nullptr));
        advTTTxt->setInputMask(QApplication::translate("OathPage", "nn; ", nullptr));
        advTTTxt->setText(QApplication::translate("OathPage", "00", nullptr));
        advOMPTxt->setInputMask(QApplication::translate("OathPage", "nn; ", nullptr));
        advOMPTxt->setText(QApplication::translate("OathPage", "00", nullptr));
#ifndef QT_NO_WHATSTHIS
        advMUIGenerateBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advMUIGenerateBtn->setText(QApplication::translate("OathPage", "Generate MUI", nullptr));
        advSecretKeyLbl->setText(QApplication::translate("OathPage", "Secret Key (20 bytes Hex)", nullptr));
        advPubIdCheck->setText(QApplication::translate("OathPage", "OATH Token Identifier (6 bytes)", nullptr));
        advHotpLenLbl->setText(QApplication::translate("OathPage", "HOTP Length", nullptr));
        advHotpLen8Radio->setText(QApplication::translate("OathPage", "8 Digits", nullptr));
        advHotpLen6Radio->setText(QApplication::translate("OathPage", "6 Digits", nullptr));
        advMovingFactorSeedLbl->setText(QApplication::translate("OathPage", "Moving Factor Seed", nullptr));
        advMovingFactorSeedCombo->setItemText(0, QApplication::translate("OathPage", "Fixed zero", nullptr));
        advMovingFactorSeedCombo->setItemText(1, QApplication::translate("OathPage", "Fixed", nullptr));
        advMovingFactorSeedCombo->setItemText(2, QApplication::translate("OathPage", "Randomize", nullptr));

        advMovingFactorSeedTxt->setInputMask(QApplication::translate("OathPage", "00000000; ", nullptr));
        advMovingFactorSeedTxt->setText(QApplication::translate("OathPage", "0", nullptr));
        advPubIdHelpBtn->setText(QString());
        advHotpParamsHelpBtn->setText(QString());
        advPubIdDescLbl->setText(QApplication::translate("OathPage", "OMP (1) + TT (1) + MUI (4)", nullptr));
        advHotpLenHelpBtn->setText(QString());
        advActionsBox->setTitle(QApplication::translate("OathPage", "Actions", nullptr));
        advWriteConfigBtn->setText(QApplication::translate("OathPage", "Write Configuration", nullptr));
#ifndef QT_NO_WHATSTHIS
        advStopBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advStopBtn->setText(QApplication::translate("OathPage", "Stop", nullptr));
        advActionsDescLbl->setText(QApplication::translate("OathPage", "Press Write Configuration button to program your YubiKey's selected configuration slot", nullptr));
#ifndef QT_NO_WHATSTHIS
        advBackBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advBackBtn->setText(QApplication::translate("OathPage", "Back", nullptr));
#ifndef QT_NO_WHATSTHIS
        advResetBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advResetBtn->setText(QApplication::translate("OathPage", "Reset", nullptr));
#ifndef QT_NO_WHATSTHIS
        advExportConfigBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        advExportConfigBtn->setText(QApplication::translate("OathPage", "Export", nullptr));
        advProgramMulKeysBox->setTitle(QApplication::translate("OathPage", "Program Multiple YubiKeys", nullptr));
        advAutoProgramKeysCheck->setText(QApplication::translate("OathPage", "Automatically program YubiKeys when inserted", nullptr));
        advConfigParamsCombo->setItemText(0, QApplication::translate("OathPage", "Increment Identities; Randomize Secret", nullptr));
        advConfigParamsCombo->setItemText(1, QApplication::translate("OathPage", "Randomize all parameters", nullptr));

        advParamGenSchemeLbl->setText(QApplication::translate("OathPage", "Parameter Generation Scheme", nullptr));
        advParamGenSchemeHelpBtn->setText(QString());
        advResultsBox->setTitle(QApplication::translate("OathPage", "Results", nullptr));
        QTableWidgetItem *___qtablewidgetitem = advResultsWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("OathPage", "#", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = advResultsWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("OathPage", "OATH Token Identifier", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = advResultsWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("OathPage", "Status", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = advResultsWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("OathPage", "Timestamp", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OathPage: public Ui_OathPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OATHPAGE_H
