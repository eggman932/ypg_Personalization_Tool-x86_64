/********************************************************************************
** Form generated from reading UI file 'toolpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TOOLPAGE_H
#define UI_TOOLPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ToolPage
{
public:
    QWidget *basePage;
    QLabel *baseHeadingLbl;
    QGroupBox *baseActionsBox;
    QPushButton *converterBtn;
    QLabel *converterDescLbl;
    QPushButton *chalRespBtn;
    QLabel *chalRespDescLbl;
    QPushButton *ndefBtn;
    QLabel *ndefDescLbl;
    QPushButton *zapBtn;
    QLabel *zapDescLbl;
    QWidget *importBox;
    QPushButton *importBtn;
    QLabel *importDescLbl;
    QWidget *converterPage;
    QLabel *converterHeadingLbl;
    QGroupBox *converterBox;
    QLineEdit *converterModhexTxt;
    QLabel *converterHexLbl;
    QLabel *converterModhexLbl;
    QLineEdit *converterHexTxt;
    QPushButton *converterHexCopyBtn;
    QPushButton *converterModhexCopyBtn;
    QLabel *converterDecLbl;
    QLineEdit *converterDecTxt;
    QPushButton *converterDecCopyBtn;
    QLabel *converterHexLenLbl;
    QLabel *converterModhexLenLbl;
    QLabel *converterDecErrLbl;
    QGroupBox *converterActionsBox;
    QPushButton *converterResetBtn;
    QPushButton *converterConvertBtn;
    QPushButton *converterBackBtn;
    QWidget *chalRespPage;
    QLabel *chalRespHeadingLbl;
    QGroupBox *chalRespInput;
    QWidget *typeWidget;
    QLabel *chalRespTypeLabel;
    QRadioButton *chalRespHmacRadio;
    QRadioButton *chalRespYubicoRadio;
    QWidget *slotWidget;
    QLabel *chalRespSlotLabel;
    QRadioButton *chalRespSlot1Radio;
    QRadioButton *chalRespSlot2Radio;
    QLabel *chalRespChallengeLabel;
    QLineEdit *chalRespChallenge;
    QLabel *chalRespResponseLabel;
    QLineEdit *chalRespResponse;
    QGroupBox *chalRespActions;
    QPushButton *chalRespPerformBtn;
    QPushButton *chalRespBackBtn;
    QPushButton *chalRespResetBtn;
    QWidget *ndefPage;
    QLabel *ndefHeadingLbl;
    QGroupBox *ndefActions;
    QPushButton *ndefProgramBtn;
    QPushButton *ndefBackBtn;
    QPushButton *ndefResetBtn;
    QGroupBox *ndefTypeGroupBox;
    QLabel *ndefTypeLabel;
    QRadioButton *ndefUriRadio;
    QRadioButton *ndefTextRadio;
    QLineEdit *ndefEdit;
    QLineEdit *ndefTextLangEdit;
    QLabel *ndexLanguageLabel;
    QLabel *ndefEditLabel;
    QWidget *ndefAccCodeWidget;
    QCheckBox *ndefAccCodeCheckbox;
    QLineEdit *ndefAccCodeEdit;
    QCheckBox *ndefUseSerial;
    QWidget *ndefSlotWidget;
    QLabel *ndefSlotLabel;
    QRadioButton *ndefSlot1Radio;
    QRadioButton *ndefSlot2Radio;
    QWidget *zapPage;
    QWidget *zapSlotWidget;
    QLabel *zapSlotLabel;
    QRadioButton *zapSlot1Radio;
    QRadioButton *zapSlot2Radio;
    QLabel *zapHeadingLbl;
    QGroupBox *zapActions;
    QPushButton *zapPerformBtn;
    QPushButton *zapBackBtn;
    QWidget *zapAccCodeWidget;
    QCheckBox *zapAccCodeCheckbox;
    QLineEdit *zapAccCodeEdit;
    QCheckBox *zapUseSerial;
    QWidget *importPage;
    QLabel *importHeadingLbl;
    QGroupBox *importActions;
    QPushButton *importPerformBtn;
    QPushButton *importBackBtn;
    QLabel *importLabel;
    QLabel *importInfoLbl;

    void setupUi(QStackedWidget *ToolPage)
    {
        if (ToolPage->objectName().isEmpty())
            ToolPage->setObjectName(QString::fromUtf8("ToolPage"));
        ToolPage->resize(730, 650);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ToolPage->sizePolicy().hasHeightForWidth());
        ToolPage->setSizePolicy(sizePolicy);
        ToolPage->setMaximumSize(QSize(730, 650));
        ToolPage->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"color: rgb(0, 0, 0);"));
        basePage = new QWidget();
        basePage->setObjectName(QString::fromUtf8("basePage"));
        baseHeadingLbl = new QLabel(basePage);
        baseHeadingLbl->setObjectName(QString::fromUtf8("baseHeadingLbl"));
        baseHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        baseHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        baseHeadingLbl->setAlignment(Qt::AlignCenter);
        baseActionsBox = new QGroupBox(basePage);
        baseActionsBox->setObjectName(QString::fromUtf8("baseActionsBox"));
        baseActionsBox->setGeometry(QRect(10, 50, 711, 421));
        baseActionsBox->setStyleSheet(QString::fromUtf8("border-color: rgb(0, 0, 0);"));
        baseActionsBox->setAlignment(Qt::AlignCenter);
        converterBtn = new QPushButton(baseActionsBox);
        converterBtn->setObjectName(QString::fromUtf8("converterBtn"));
        converterBtn->setGeometry(QRect(20, 20, 191, 25));
        sizePolicy.setHeightForWidth(converterBtn->sizePolicy().hasHeightForWidth());
        converterBtn->setSizePolicy(sizePolicy);
        converterBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        converterBtn->setAutoExclusive(false);
        converterBtn->setFlat(false);
        converterDescLbl = new QLabel(baseActionsBox);
        converterDescLbl->setObjectName(QString::fromUtf8("converterDescLbl"));
        converterDescLbl->setGeometry(QRect(20, 45, 671, 20));
        converterDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        chalRespBtn = new QPushButton(baseActionsBox);
        chalRespBtn->setObjectName(QString::fromUtf8("chalRespBtn"));
        chalRespBtn->setGeometry(QRect(20, 100, 191, 25));
        sizePolicy.setHeightForWidth(chalRespBtn->sizePolicy().hasHeightForWidth());
        chalRespBtn->setSizePolicy(sizePolicy);
        chalRespBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        chalRespBtn->setAutoExclusive(false);
        chalRespBtn->setFlat(false);
        chalRespDescLbl = new QLabel(baseActionsBox);
        chalRespDescLbl->setObjectName(QString::fromUtf8("chalRespDescLbl"));
        chalRespDescLbl->setGeometry(QRect(20, 125, 671, 20));
        chalRespDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ndefBtn = new QPushButton(baseActionsBox);
        ndefBtn->setObjectName(QString::fromUtf8("ndefBtn"));
        ndefBtn->setGeometry(QRect(20, 180, 191, 25));
        sizePolicy.setHeightForWidth(ndefBtn->sizePolicy().hasHeightForWidth());
        ndefBtn->setSizePolicy(sizePolicy);
        ndefBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        ndefBtn->setAutoExclusive(false);
        ndefBtn->setFlat(false);
        ndefDescLbl = new QLabel(baseActionsBox);
        ndefDescLbl->setObjectName(QString::fromUtf8("ndefDescLbl"));
        ndefDescLbl->setGeometry(QRect(20, 205, 671, 20));
        ndefDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        zapBtn = new QPushButton(baseActionsBox);
        zapBtn->setObjectName(QString::fromUtf8("zapBtn"));
        zapBtn->setGeometry(QRect(20, 260, 191, 25));
        sizePolicy.setHeightForWidth(zapBtn->sizePolicy().hasHeightForWidth());
        zapBtn->setSizePolicy(sizePolicy);
        zapBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        zapBtn->setAutoExclusive(false);
        zapBtn->setFlat(false);
        zapDescLbl = new QLabel(baseActionsBox);
        zapDescLbl->setObjectName(QString::fromUtf8("zapDescLbl"));
        zapDescLbl->setGeometry(QRect(20, 285, 671, 20));
        zapDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        importBox = new QWidget(baseActionsBox);
        importBox->setObjectName(QString::fromUtf8("importBox"));
        importBox->setGeometry(QRect(20, 340, 650, 80));
        importBtn = new QPushButton(importBox);
        importBtn->setObjectName(QString::fromUtf8("importBtn"));
        importBtn->setGeometry(QRect(0, 0, 191, 25));
        sizePolicy.setHeightForWidth(importBtn->sizePolicy().hasHeightForWidth());
        importBtn->setSizePolicy(sizePolicy);
        importBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        importBtn->setAutoExclusive(false);
        importBtn->setFlat(false);
        importDescLbl = new QLabel(importBox);
        importDescLbl->setObjectName(QString::fromUtf8("importDescLbl"));
        importDescLbl->setGeometry(QRect(0, 25, 671, 20));
        importDescLbl->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ToolPage->addWidget(basePage);
        converterPage = new QWidget();
        converterPage->setObjectName(QString::fromUtf8("converterPage"));
        converterHeadingLbl = new QLabel(converterPage);
        converterHeadingLbl->setObjectName(QString::fromUtf8("converterHeadingLbl"));
        converterHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        converterHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        converterHeadingLbl->setAlignment(Qt::AlignCenter);
        converterBox = new QGroupBox(converterPage);
        converterBox->setObjectName(QString::fromUtf8("converterBox"));
        converterBox->setGeometry(QRect(10, 50, 711, 125));
        converterBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        converterModhexTxt = new QLineEdit(converterBox);
        converterModhexTxt->setObjectName(QString::fromUtf8("converterModhexTxt"));
        converterModhexTxt->setGeometry(QRect(180, 60, 381, 20));
        sizePolicy.setHeightForWidth(converterModhexTxt->sizePolicy().hasHeightForWidth());
        converterModhexTxt->setSizePolicy(sizePolicy);
        converterModhexTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        converterModhexTxt->setMaxLength(47);
        converterModhexTxt->setCursorPosition(47);
        converterHexLbl = new QLabel(converterBox);
        converterHexLbl->setObjectName(QString::fromUtf8("converterHexLbl"));
        converterHexLbl->setGeometry(QRect(10, 30, 91, 20));
        converterHexLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        converterModhexLbl = new QLabel(converterBox);
        converterModhexLbl->setObjectName(QString::fromUtf8("converterModhexLbl"));
        converterModhexLbl->setGeometry(QRect(10, 60, 91, 20));
        converterModhexLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        converterHexTxt = new QLineEdit(converterBox);
        converterHexTxt->setObjectName(QString::fromUtf8("converterHexTxt"));
        converterHexTxt->setGeometry(QRect(180, 30, 381, 20));
        sizePolicy.setHeightForWidth(converterHexTxt->sizePolicy().hasHeightForWidth());
        converterHexTxt->setSizePolicy(sizePolicy);
        converterHexTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        converterHexTxt->setMaxLength(47);
        converterHexTxt->setCursorPosition(47);
        converterHexCopyBtn = new QPushButton(converterBox);
        converterHexCopyBtn->setObjectName(QString::fromUtf8("converterHexCopyBtn"));
        converterHexCopyBtn->setEnabled(false);
        converterHexCopyBtn->setGeometry(QRect(571, 28, 85, 25));
        converterHexCopyBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        converterHexCopyBtn->setAutoExclusive(false);
        converterHexCopyBtn->setFlat(false);
        converterModhexCopyBtn = new QPushButton(converterBox);
        converterModhexCopyBtn->setObjectName(QString::fromUtf8("converterModhexCopyBtn"));
        converterModhexCopyBtn->setEnabled(false);
        converterModhexCopyBtn->setGeometry(QRect(571, 58, 85, 25));
        converterModhexCopyBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        converterModhexCopyBtn->setAutoExclusive(false);
        converterModhexCopyBtn->setFlat(false);
        converterDecLbl = new QLabel(converterBox);
        converterDecLbl->setObjectName(QString::fromUtf8("converterDecLbl"));
        converterDecLbl->setGeometry(QRect(10, 90, 91, 20));
        converterDecLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;"));
        converterDecTxt = new QLineEdit(converterBox);
        converterDecTxt->setObjectName(QString::fromUtf8("converterDecTxt"));
        converterDecTxt->setGeometry(QRect(180, 90, 381, 20));
        converterDecTxt->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        converterDecTxt->setMaxLength(20);
        converterDecTxt->setCursorPosition(20);
        converterDecCopyBtn = new QPushButton(converterBox);
        converterDecCopyBtn->setObjectName(QString::fromUtf8("converterDecCopyBtn"));
        converterDecCopyBtn->setEnabled(false);
        converterDecCopyBtn->setGeometry(QRect(571, 88, 85, 25));
        converterDecCopyBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        converterDecCopyBtn->setAutoExclusive(false);
        converterDecCopyBtn->setFlat(false);
        converterHexLenLbl = new QLabel(converterBox);
        converterHexLenLbl->setObjectName(QString::fromUtf8("converterHexLenLbl"));
        converterHexLenLbl->setGeometry(QRect(110, 30, 61, 20));
        converterHexLenLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)"));
        converterModhexLenLbl = new QLabel(converterBox);
        converterModhexLenLbl->setObjectName(QString::fromUtf8("converterModhexLenLbl"));
        converterModhexLenLbl->setGeometry(QRect(110, 60, 61, 20));
        converterModhexLenLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108)"));
        converterDecErrLbl = new QLabel(converterBox);
        converterDecErrLbl->setObjectName(QString::fromUtf8("converterDecErrLbl"));
        converterDecErrLbl->setGeometry(QRect(110, 90, 61, 20));
        converterDecErrLbl->setStyleSheet(QString::fromUtf8("font-weight:normal;\n"
"color:rgb(221, 97, 99);"));
        converterActionsBox = new QGroupBox(converterPage);
        converterActionsBox->setObjectName(QString::fromUtf8("converterActionsBox"));
        converterActionsBox->setGeometry(QRect(10, 185, 711, 60));
        converterActionsBox->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        converterResetBtn = new QPushButton(converterActionsBox);
        converterResetBtn->setObjectName(QString::fromUtf8("converterResetBtn"));
        converterResetBtn->setEnabled(true);
        converterResetBtn->setGeometry(QRect(110, 25, 85, 25));
        converterResetBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        converterResetBtn->setAutoExclusive(false);
        converterResetBtn->setFlat(false);
        converterConvertBtn = new QPushButton(converterActionsBox);
        converterConvertBtn->setObjectName(QString::fromUtf8("converterConvertBtn"));
        converterConvertBtn->setGeometry(QRect(10, 25, 85, 25));
        converterConvertBtn->setStyleSheet(QString::fromUtf8("font: 12px;\n"
"font-weight: bold;"));
        converterConvertBtn->setAutoExclusive(false);
        converterConvertBtn->setFlat(false);
        converterBackBtn = new QPushButton(converterActionsBox);
        converterBackBtn->setObjectName(QString::fromUtf8("converterBackBtn"));
        converterBackBtn->setGeometry(QRect(210, 25, 85, 25));
        ToolPage->addWidget(converterPage);
        chalRespPage = new QWidget();
        chalRespPage->setObjectName(QString::fromUtf8("chalRespPage"));
        chalRespHeadingLbl = new QLabel(chalRespPage);
        chalRespHeadingLbl->setObjectName(QString::fromUtf8("chalRespHeadingLbl"));
        chalRespHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        chalRespHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        chalRespHeadingLbl->setAlignment(Qt::AlignCenter);
        chalRespInput = new QGroupBox(chalRespPage);
        chalRespInput->setObjectName(QString::fromUtf8("chalRespInput"));
        chalRespInput->setGeometry(QRect(10, 50, 711, 225));
        typeWidget = new QWidget(chalRespInput);
        typeWidget->setObjectName(QString::fromUtf8("typeWidget"));
        typeWidget->setGeometry(QRect(0, 70, 361, 50));
        chalRespTypeLabel = new QLabel(typeWidget);
        chalRespTypeLabel->setObjectName(QString::fromUtf8("chalRespTypeLabel"));
        chalRespTypeLabel->setGeometry(QRect(10, 0, 321, 16));
        chalRespTypeLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        chalRespHmacRadio = new QRadioButton(typeWidget);
        chalRespHmacRadio->setObjectName(QString::fromUtf8("chalRespHmacRadio"));
        chalRespHmacRadio->setGeometry(QRect(10, 20, 151, 19));
        chalRespHmacRadio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        chalRespHmacRadio->setCheckable(true);
        chalRespHmacRadio->setChecked(false);
        chalRespYubicoRadio = new QRadioButton(typeWidget);
        chalRespYubicoRadio->setObjectName(QString::fromUtf8("chalRespYubicoRadio"));
        chalRespYubicoRadio->setGeometry(QRect(200, 20, 151, 19));
        chalRespYubicoRadio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        slotWidget = new QWidget(chalRespInput);
        slotWidget->setObjectName(QString::fromUtf8("slotWidget"));
        slotWidget->setGeometry(QRect(0, 0, 361, 60));
        chalRespSlotLabel = new QLabel(slotWidget);
        chalRespSlotLabel->setObjectName(QString::fromUtf8("chalRespSlotLabel"));
        chalRespSlotLabel->setGeometry(QRect(10, 10, 321, 16));
        chalRespSlotLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        chalRespSlot1Radio = new QRadioButton(slotWidget);
        chalRespSlot1Radio->setObjectName(QString::fromUtf8("chalRespSlot1Radio"));
        chalRespSlot1Radio->setGeometry(QRect(10, 30, 151, 19));
        chalRespSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        chalRespSlot1Radio->setCheckable(true);
        chalRespSlot1Radio->setChecked(false);
        chalRespSlot2Radio = new QRadioButton(slotWidget);
        chalRespSlot2Radio->setObjectName(QString::fromUtf8("chalRespSlot2Radio"));
        chalRespSlot2Radio->setGeometry(QRect(200, 30, 151, 19));
        chalRespSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        chalRespChallengeLabel = new QLabel(chalRespInput);
        chalRespChallengeLabel->setObjectName(QString::fromUtf8("chalRespChallengeLabel"));
        chalRespChallengeLabel->setGeometry(QRect(10, 130, 321, 16));
        chalRespChallengeLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"          color: rgb(118, 116, 108);"));
        chalRespChallenge = new QLineEdit(chalRespInput);
        chalRespChallenge->setObjectName(QString::fromUtf8("chalRespChallenge"));
        chalRespChallenge->setGeometry(QRect(10, 150, 361, 20));
        sizePolicy.setHeightForWidth(chalRespChallenge->sizePolicy().hasHeightForWidth());
        chalRespChallenge->setSizePolicy(sizePolicy);
        chalRespChallenge->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        chalRespChallenge->setMaxLength(64);
        chalRespChallenge->setCursorPosition(0);
        chalRespResponseLabel = new QLabel(chalRespInput);
        chalRespResponseLabel->setObjectName(QString::fromUtf8("chalRespResponseLabel"));
        chalRespResponseLabel->setGeometry(QRect(10, 175, 321, 16));
        chalRespResponseLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"          color: rgb(118, 116, 108);"));
        chalRespResponse = new QLineEdit(chalRespInput);
        chalRespResponse->setObjectName(QString::fromUtf8("chalRespResponse"));
        chalRespResponse->setGeometry(QRect(10, 195, 361, 20));
        sizePolicy.setHeightForWidth(chalRespResponse->sizePolicy().hasHeightForWidth());
        chalRespResponse->setSizePolicy(sizePolicy);
        chalRespResponse->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        chalRespResponse->setMaxLength(64);
        chalRespResponse->setReadOnly(true);
        chalRespActions = new QGroupBox(chalRespPage);
        chalRespActions->setObjectName(QString::fromUtf8("chalRespActions"));
        chalRespActions->setGeometry(QRect(10, 295, 711, 50));
        chalRespActions->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        chalRespPerformBtn = new QPushButton(chalRespActions);
        chalRespPerformBtn->setObjectName(QString::fromUtf8("chalRespPerformBtn"));
        chalRespPerformBtn->setGeometry(QRect(10, 10, 85, 25));
        chalRespBackBtn = new QPushButton(chalRespActions);
        chalRespBackBtn->setObjectName(QString::fromUtf8("chalRespBackBtn"));
        chalRespBackBtn->setGeometry(QRect(210, 10, 85, 25));
        chalRespResetBtn = new QPushButton(chalRespActions);
        chalRespResetBtn->setObjectName(QString::fromUtf8("chalRespResetBtn"));
        chalRespResetBtn->setGeometry(QRect(110, 10, 85, 25));
        ToolPage->addWidget(chalRespPage);
        ndefPage = new QWidget();
        ndefPage->setObjectName(QString::fromUtf8("ndefPage"));
        ndefHeadingLbl = new QLabel(ndefPage);
        ndefHeadingLbl->setObjectName(QString::fromUtf8("ndefHeadingLbl"));
        ndefHeadingLbl->setGeometry(QRect(0, 0, 710, 22));
        ndefHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        ndefHeadingLbl->setAlignment(Qt::AlignCenter);
        ndefActions = new QGroupBox(ndefPage);
        ndefActions->setObjectName(QString::fromUtf8("ndefActions"));
        ndefActions->setGeometry(QRect(10, 300, 711, 50));
        ndefActions->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        ndefProgramBtn = new QPushButton(ndefActions);
        ndefProgramBtn->setObjectName(QString::fromUtf8("ndefProgramBtn"));
        ndefProgramBtn->setGeometry(QRect(10, 10, 85, 25));
        ndefBackBtn = new QPushButton(ndefActions);
        ndefBackBtn->setObjectName(QString::fromUtf8("ndefBackBtn"));
        ndefBackBtn->setGeometry(QRect(210, 10, 85, 25));
        ndefResetBtn = new QPushButton(ndefActions);
        ndefResetBtn->setObjectName(QString::fromUtf8("ndefResetBtn"));
        ndefResetBtn->setGeometry(QRect(110, 10, 85, 25));
        ndefTypeGroupBox = new QGroupBox(ndefPage);
        ndefTypeGroupBox->setObjectName(QString::fromUtf8("ndefTypeGroupBox"));
        ndefTypeGroupBox->setGeometry(QRect(10, 50, 711, 240));
        ndefTypeLabel = new QLabel(ndefTypeGroupBox);
        ndefTypeLabel->setObjectName(QString::fromUtf8("ndefTypeLabel"));
        ndefTypeLabel->setGeometry(QRect(10, 65, 321, 16));
        ndefTypeLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        ndefUriRadio = new QRadioButton(ndefTypeGroupBox);
        ndefUriRadio->setObjectName(QString::fromUtf8("ndefUriRadio"));
        ndefUriRadio->setGeometry(QRect(10, 85, 221, 17));
        ndefUriRadio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        ndefUriRadio->setCheckable(true);
        ndefUriRadio->setChecked(true);
        ndefTextRadio = new QRadioButton(ndefTypeGroupBox);
        ndefTextRadio->setObjectName(QString::fromUtf8("ndefTextRadio"));
        ndefTextRadio->setGeometry(QRect(10, 105, 151, 17));
        ndefTextRadio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        ndefEdit = new QLineEdit(ndefTypeGroupBox);
        ndefEdit->setObjectName(QString::fromUtf8("ndefEdit"));
        ndefEdit->setGeometry(QRect(10, 210, 391, 20));
        ndefEdit->setMaxLength(80);
        ndefTextLangEdit = new QLineEdit(ndefTypeGroupBox);
        ndefTextLangEdit->setObjectName(QString::fromUtf8("ndefTextLangEdit"));
        ndefTextLangEdit->setEnabled(false);
        ndefTextLangEdit->setGeometry(QRect(10, 145, 113, 26));
        ndexLanguageLabel = new QLabel(ndefTypeGroupBox);
        ndexLanguageLabel->setObjectName(QString::fromUtf8("ndexLanguageLabel"));
        ndexLanguageLabel->setGeometry(QRect(10, 125, 321, 16));
        ndexLanguageLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        ndefEditLabel = new QLabel(ndefTypeGroupBox);
        ndefEditLabel->setObjectName(QString::fromUtf8("ndefEditLabel"));
        ndefEditLabel->setGeometry(QRect(10, 190, 321, 16));
        ndefEditLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        ndefAccCodeWidget = new QWidget(ndefTypeGroupBox);
        ndefAccCodeWidget->setObjectName(QString::fromUtf8("ndefAccCodeWidget"));
        ndefAccCodeWidget->setGeometry(QRect(530, 10, 150, 100));
        ndefAccCodeCheckbox = new QCheckBox(ndefAccCodeWidget);
        ndefAccCodeCheckbox->setObjectName(QString::fromUtf8("ndefAccCodeCheckbox"));
        ndefAccCodeCheckbox->setGeometry(QRect(10, 10, 125, 23));
        ndefAccCodeEdit = new QLineEdit(ndefAccCodeWidget);
        ndefAccCodeEdit->setObjectName(QString::fromUtf8("ndefAccCodeEdit"));
        ndefAccCodeEdit->setGeometry(QRect(10, 40, 125, 20));
        ndefUseSerial = new QCheckBox(ndefAccCodeWidget);
        ndefUseSerial->setObjectName(QString::fromUtf8("ndefUseSerial"));
        ndefUseSerial->setEnabled(false);
        ndefUseSerial->setGeometry(QRect(10, 65, 150, 23));
        ndefUseSerial->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"       color: rgb(0, 0, 0);"));
        ndefSlotWidget = new QWidget(ndefTypeGroupBox);
        ndefSlotWidget->setObjectName(QString::fromUtf8("ndefSlotWidget"));
        ndefSlotWidget->setGeometry(QRect(10, 10, 361, 50));
        ndefSlotLabel = new QLabel(ndefSlotWidget);
        ndefSlotLabel->setObjectName(QString::fromUtf8("ndefSlotLabel"));
        ndefSlotLabel->setGeometry(QRect(0, 0, 321, 16));
        ndefSlotLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        ndefSlot1Radio = new QRadioButton(ndefSlotWidget);
        ndefSlot1Radio->setObjectName(QString::fromUtf8("ndefSlot1Radio"));
        ndefSlot1Radio->setGeometry(QRect(0, 20, 151, 19));
        ndefSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        ndefSlot1Radio->setCheckable(true);
        ndefSlot1Radio->setChecked(false);
        ndefSlot2Radio = new QRadioButton(ndefSlotWidget);
        ndefSlot2Radio->setObjectName(QString::fromUtf8("ndefSlot2Radio"));
        ndefSlot2Radio->setGeometry(QRect(190, 20, 151, 19));
        ndefSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        ToolPage->addWidget(ndefPage);
        zapPage = new QWidget();
        zapPage->setObjectName(QString::fromUtf8("zapPage"));
        zapSlotWidget = new QWidget(zapPage);
        zapSlotWidget->setObjectName(QString::fromUtf8("zapSlotWidget"));
        zapSlotWidget->setGeometry(QRect(10, 50, 361, 75));
        zapSlotLabel = new QLabel(zapSlotWidget);
        zapSlotLabel->setObjectName(QString::fromUtf8("zapSlotLabel"));
        zapSlotLabel->setGeometry(QRect(10, 10, 321, 16));
        zapSlotLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        zapSlot1Radio = new QRadioButton(zapSlotWidget);
        zapSlot1Radio->setObjectName(QString::fromUtf8("zapSlot1Radio"));
        zapSlot1Radio->setGeometry(QRect(10, 40, 151, 19));
        zapSlot1Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        zapSlot1Radio->setCheckable(true);
        zapSlot1Radio->setChecked(false);
        zapSlot2Radio = new QRadioButton(zapSlotWidget);
        zapSlot2Radio->setObjectName(QString::fromUtf8("zapSlot2Radio"));
        zapSlot2Radio->setGeometry(QRect(200, 40, 151, 19));
        zapSlot2Radio->setStyleSheet(QString::fromUtf8("font-weight: normal;"));
        zapHeadingLbl = new QLabel(zapPage);
        zapHeadingLbl->setObjectName(QString::fromUtf8("zapHeadingLbl"));
        zapHeadingLbl->setGeometry(QRect(10, 0, 710, 22));
        zapHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        zapHeadingLbl->setAlignment(Qt::AlignCenter);
        zapActions = new QGroupBox(zapPage);
        zapActions->setObjectName(QString::fromUtf8("zapActions"));
        zapActions->setGeometry(QRect(10, 125, 711, 50));
        zapActions->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        zapPerformBtn = new QPushButton(zapActions);
        zapPerformBtn->setObjectName(QString::fromUtf8("zapPerformBtn"));
        zapPerformBtn->setGeometry(QRect(10, 10, 85, 25));
        zapBackBtn = new QPushButton(zapActions);
        zapBackBtn->setObjectName(QString::fromUtf8("zapBackBtn"));
        zapBackBtn->setGeometry(QRect(110, 10, 85, 25));
        zapAccCodeWidget = new QWidget(zapPage);
        zapAccCodeWidget->setObjectName(QString::fromUtf8("zapAccCodeWidget"));
        zapAccCodeWidget->setGeometry(QRect(500, 50, 150, 100));
        zapAccCodeCheckbox = new QCheckBox(zapAccCodeWidget);
        zapAccCodeCheckbox->setObjectName(QString::fromUtf8("zapAccCodeCheckbox"));
        zapAccCodeCheckbox->setGeometry(QRect(10, 10, 125, 23));
        zapAccCodeEdit = new QLineEdit(zapAccCodeWidget);
        zapAccCodeEdit->setObjectName(QString::fromUtf8("zapAccCodeEdit"));
        zapAccCodeEdit->setGeometry(QRect(10, 40, 125, 20));
        zapUseSerial = new QCheckBox(zapAccCodeWidget);
        zapUseSerial->setObjectName(QString::fromUtf8("zapUseSerial"));
        zapUseSerial->setEnabled(false);
        zapUseSerial->setGeometry(QRect(10, 65, 150, 23));
        zapUseSerial->setStyleSheet(QString::fromUtf8("font: 11px \"Verdana\";\n"
"       color: rgb(0, 0, 0);"));
        ToolPage->addWidget(zapPage);
        importPage = new QWidget();
        importPage->setObjectName(QString::fromUtf8("importPage"));
        importHeadingLbl = new QLabel(importPage);
        importHeadingLbl->setObjectName(QString::fromUtf8("importHeadingLbl"));
        importHeadingLbl->setGeometry(QRect(0, 0, 710, 22));
        importHeadingLbl->setStyleSheet(QString::fromUtf8("font: 18px \"Verdana\";\n"
"font-weight: bold;\n"
"color: rgb(140, 192, 65);"));
        importHeadingLbl->setAlignment(Qt::AlignCenter);
        importActions = new QGroupBox(importPage);
        importActions->setObjectName(QString::fromUtf8("importActions"));
        importActions->setGeometry(QRect(10, 70, 711, 50));
        importActions->setStyleSheet(QString::fromUtf8("font-weight: bold;"));
        importPerformBtn = new QPushButton(importActions);
        importPerformBtn->setObjectName(QString::fromUtf8("importPerformBtn"));
        importPerformBtn->setGeometry(QRect(10, 10, 85, 25));
        importBackBtn = new QPushButton(importActions);
        importBackBtn->setObjectName(QString::fromUtf8("importBackBtn"));
        importBackBtn->setGeometry(QRect(110, 10, 85, 25));
        importLabel = new QLabel(importPage);
        importLabel->setObjectName(QString::fromUtf8("importLabel"));
        importLabel->setGeometry(QRect(10, 50, 600, 16));
        importLabel->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        importInfoLbl = new QLabel(importPage);
        importInfoLbl->setObjectName(QString::fromUtf8("importInfoLbl"));
        importInfoLbl->setGeometry(QRect(10, 115, 600, 16));
        importInfoLbl->setStyleSheet(QString::fromUtf8("font-weight: normal;\n"
"color: rgb(118, 116, 108);"));
        ToolPage->addWidget(importPage);
        QWidget::setTabOrder(converterHexTxt, converterModhexTxt);
        QWidget::setTabOrder(converterModhexTxt, converterDecTxt);
        QWidget::setTabOrder(converterDecTxt, converterHexCopyBtn);
        QWidget::setTabOrder(converterHexCopyBtn, converterModhexCopyBtn);
        QWidget::setTabOrder(converterModhexCopyBtn, converterDecCopyBtn);
        QWidget::setTabOrder(converterDecCopyBtn, converterConvertBtn);
        QWidget::setTabOrder(converterConvertBtn, converterResetBtn);
        QWidget::setTabOrder(converterResetBtn, converterBtn);

        retranslateUi(ToolPage);

        ToolPage->setCurrentIndex(3);
        converterBtn->setDefault(false);
        chalRespBtn->setDefault(false);
        ndefBtn->setDefault(false);
        zapBtn->setDefault(false);
        importBtn->setDefault(false);
        converterHexCopyBtn->setDefault(false);
        converterModhexCopyBtn->setDefault(false);
        converterDecCopyBtn->setDefault(false);
        converterResetBtn->setDefault(false);
        converterConvertBtn->setDefault(false);


        QMetaObject::connectSlotsByName(ToolPage);
    } // setupUi

    void retranslateUi(QStackedWidget *ToolPage)
    {
        ToolPage->setWindowTitle(QApplication::translate("ToolPage", "StackedWidget", nullptr));
        baseHeadingLbl->setText(QApplication::translate("ToolPage", "Tools", nullptr));
        baseActionsBox->setTitle(QString());
        converterBtn->setText(QApplication::translate("ToolPage", "Number Converter", nullptr));
        converterDescLbl->setText(QApplication::translate("ToolPage", "Convert between different number formats", nullptr));
        chalRespBtn->setText(QApplication::translate("ToolPage", "Challenge-Response", nullptr));
        chalRespDescLbl->setText(QApplication::translate("ToolPage", "Test Challenge-Response functionality of YubiKey", nullptr));
        ndefBtn->setText(QApplication::translate("ToolPage", "NDEF Programming", nullptr));
        ndefDescLbl->setText(QApplication::translate("ToolPage", "Program the static NDEF string of a Yubikey NEO", nullptr));
        zapBtn->setText(QApplication::translate("ToolPage", "Delete Configuration", nullptr));
        zapDescLbl->setText(QApplication::translate("ToolPage", "Delete the configuration stored in the YubiKey", nullptr));
        importBtn->setText(QApplication::translate("ToolPage", "Import Configuration", nullptr));
        importDescLbl->setText(QApplication::translate("ToolPage", "Import a configuration in ycfg format", nullptr));
        converterHeadingLbl->setText(QApplication::translate("ToolPage", "Number Converter", nullptr));
        converterBox->setTitle(QString());
        converterModhexTxt->setInputMask(QApplication::translate("ToolPage", "nn nn nn nn nn nn nn nn nn nn nn nn nn nn nn nn", nullptr));
        converterModhexTxt->setText(QString());
        converterHexLbl->setText(QApplication::translate("ToolPage", "Hexadecimal", nullptr));
        converterModhexLbl->setText(QApplication::translate("ToolPage", "Modhex", nullptr));
        converterHexTxt->setInputMask(QApplication::translate("ToolPage", "nn nn nn nn nn nn nn nn nn nn nn nn nn nn nn nn", nullptr));
        converterHexTxt->setText(QString());
#ifndef QT_NO_WHATSTHIS
        converterHexCopyBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        converterHexCopyBtn->setText(QApplication::translate("ToolPage", "Copy", nullptr));
#ifndef QT_NO_WHATSTHIS
        converterModhexCopyBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        converterModhexCopyBtn->setText(QApplication::translate("ToolPage", "Copy", nullptr));
        converterDecLbl->setText(QApplication::translate("ToolPage", "Decimal", nullptr));
        converterDecTxt->setInputMask(QApplication::translate("ToolPage", "00000000000000000000", nullptr));
        converterDecTxt->setText(QApplication::translate("ToolPage", "0", nullptr));
#ifndef QT_NO_WHATSTHIS
        converterDecCopyBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        converterDecCopyBtn->setText(QApplication::translate("ToolPage", "Copy", nullptr));
        converterHexLenLbl->setText(QApplication::translate("ToolPage", "(0 chars)", nullptr));
        converterModhexLenLbl->setText(QApplication::translate("ToolPage", "(0 chars)", nullptr));
        converterDecErrLbl->setText(QString());
        converterActionsBox->setTitle(QApplication::translate("ToolPage", "Actions", nullptr));
#ifndef QT_NO_WHATSTHIS
        converterResetBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        converterResetBtn->setText(QApplication::translate("ToolPage", "Reset", nullptr));
#ifndef QT_NO_WHATSTHIS
        converterConvertBtn->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        converterConvertBtn->setText(QApplication::translate("ToolPage", "Convert", nullptr));
        converterBackBtn->setText(QApplication::translate("ToolPage", "Back", nullptr));
        chalRespHeadingLbl->setText(QApplication::translate("ToolPage", "Challenge-Response Tester", nullptr));
        chalRespTypeLabel->setText(QApplication::translate("ToolPage", "Select the challenge-response type", nullptr));
        chalRespHmacRadio->setText(QApplication::translate("ToolPage", "HMAC-SHA1", nullptr));
        chalRespYubicoRadio->setText(QApplication::translate("ToolPage", "Yubico OTP", nullptr));
        chalRespSlotLabel->setText(QApplication::translate("ToolPage", "Select the configuration slot to be used", nullptr));
        chalRespSlot1Radio->setText(QApplication::translate("ToolPage", "Configuration Slot 1", nullptr));
        chalRespSlot2Radio->setText(QApplication::translate("ToolPage", "Configuration Slot 2", nullptr));
        chalRespChallengeLabel->setText(QApplication::translate("ToolPage", "Input challenge, max 64 characters", nullptr));
        chalRespResponseLabel->setText(QApplication::translate("ToolPage", "Response:", nullptr));
        chalRespPerformBtn->setText(QApplication::translate("ToolPage", "Perform", nullptr));
        chalRespBackBtn->setText(QApplication::translate("ToolPage", "Back", nullptr));
        chalRespResetBtn->setText(QApplication::translate("ToolPage", "Reset", nullptr));
        ndefHeadingLbl->setText(QApplication::translate("ToolPage", "NDEF Programming", nullptr));
        ndefProgramBtn->setText(QApplication::translate("ToolPage", "Program", nullptr));
        ndefBackBtn->setText(QApplication::translate("ToolPage", "Back", nullptr));
        ndefResetBtn->setText(QApplication::translate("ToolPage", "Reset", nullptr));
        ndefTypeLabel->setText(QApplication::translate("ToolPage", "Select the NDEF type", nullptr));
        ndefUriRadio->setText(QApplication::translate("ToolPage", "URI", nullptr));
        ndefTextRadio->setText(QApplication::translate("ToolPage", "Text", nullptr));
        ndefEdit->setText(QApplication::translate("ToolPage", "https://my.yubico.com/neo/", nullptr));
        ndefTextLangEdit->setText(QApplication::translate("ToolPage", "en-US", nullptr));
        ndexLanguageLabel->setText(QApplication::translate("ToolPage", "NDEF text language (IANA language code)", nullptr));
        ndefEditLabel->setText(QApplication::translate("ToolPage", "NDEF payload, OTP will be appended on the end", nullptr));
        ndefAccCodeCheckbox->setText(QApplication::translate("ToolPage", "Use Access Code", nullptr));
        ndefAccCodeEdit->setInputMask(QApplication::translate("ToolPage", "hh hh hh hh hh hh", nullptr));
        ndefAccCodeEdit->setText(QApplication::translate("ToolPage", "00 00 00 00 00 00", nullptr));
        ndefUseSerial->setText(QApplication::translate("ToolPage", "Use Serial Number", nullptr));
        ndefSlotLabel->setText(QApplication::translate("ToolPage", "Select the configuration slot to be used", nullptr));
        ndefSlot1Radio->setText(QApplication::translate("ToolPage", "Configuration Slot 1", nullptr));
        ndefSlot2Radio->setText(QApplication::translate("ToolPage", "Configuration Slot 2", nullptr));
        zapSlotLabel->setText(QApplication::translate("ToolPage", "Select the configuration slot to be deleted", nullptr));
        zapSlot1Radio->setText(QApplication::translate("ToolPage", "Configuration Slot 1", nullptr));
        zapSlot2Radio->setText(QApplication::translate("ToolPage", "Configuration Slot 2", nullptr));
        zapHeadingLbl->setText(QApplication::translate("ToolPage", "Delete Configuration", nullptr));
        zapPerformBtn->setText(QApplication::translate("ToolPage", "Delete", nullptr));
        zapBackBtn->setText(QApplication::translate("ToolPage", "Back", nullptr));
        zapAccCodeCheckbox->setText(QApplication::translate("ToolPage", "Use Access Code", nullptr));
        zapAccCodeEdit->setInputMask(QApplication::translate("ToolPage", "hh hh hh hh hh hh", nullptr));
        zapAccCodeEdit->setText(QApplication::translate("ToolPage", "00 00 00 00 00 00", nullptr));
        zapUseSerial->setText(QApplication::translate("ToolPage", "Use Serial Number", nullptr));
        importHeadingLbl->setText(QApplication::translate("ToolPage", "Import Configuration", nullptr));
        importPerformBtn->setText(QApplication::translate("ToolPage", "Import", nullptr));
        importBackBtn->setText(QApplication::translate("ToolPage", "Back", nullptr));
        importLabel->setText(QApplication::translate("ToolPage", "When you import and select a file all settings will be overwritten", nullptr));
        importInfoLbl->setText(QApplication::translate("ToolPage", "Import is only available with a YubiKey inserted", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ToolPage: public Ui_ToolPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TOOLPAGE_H
